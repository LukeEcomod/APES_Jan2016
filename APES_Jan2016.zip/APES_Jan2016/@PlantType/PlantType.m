classdef PlantType
    % PlantType defines APES PlantType -object;
    % PlantType can be a plant functional type, a species or age-class of a given species
    % Contains physical and ecophysiological parameter values & state variables
    %
    % Samuli Launiainen, Luke 2012-2015
    % LAST EDIT: 19.02.2015
    
    properties (SetAccess = public, GetAccess = public)
        
        Species; %species name
        
        %Sub-models in use
        StomaModel='Medlyn'; %stomatal model in use
        RootUptakeModel='Volpe'; %root uptake model in use
        PhenoModel=[]; %phenology model ('Hari', 'DegreeDays','Bergh')
        
        %Switches: 'y'=includes, 'n'=omits
        Switch_LAI='y';
        Switch_Pheno='y'; %Seasonal cycle of photosynthetic parameters
        Switch_Stoma_PsiL='y'; %1 adjusts stomatal model parameters for PsiL
        %NOTE:
        %   Temperature sensitivity of Farquhar-parameters are accounted for if parameters Vcmax_T, Jmax_T & Rd_T are defined
        %	in initialization of PlantType.
        %   Same for PsiL -sensitivity of Farquhar-parameters & Rd.
        
        % physical attributes of species or cohort
        z; % vertical grid (m)
        dz; % vertical grid size (m)
        hmax; %canopy height (m)
        LAImax; %maximum one-sided leaf area index (m2/m2)
        LAImin; %minimum one-sided leaf area index (m2/m2)
        
        WAI; %woody area index (m2/m2)
        LAI; %leaf area index (m2/m2); State variable
        PAI; %plant area index (m2/m2) = LAI + WAI; State variable
        lad; %leaf-area density (m2/m3); State variable
        wad; %woody-area density (m2/m3)
        pad; %plant-area density (m2/m3) = lad + wad; State variable
        
        %these are not used currently
        %         SLA; % specific leaf area, dry mass / area (g/m2 leaf)
        %         Mleaf; %leaf biomass (kgm-2)
        %         Mbranch; %branch biomass (kgm-2)
        %         Mtrunk; %trunk biomass (kgm-2)
        
        lt; %characteristic leaf dimension (m)
        emi; %emissivity for thermal radiation
        PARalb; %leaf PAR albedo
        NIRalb; %leaf NIR albedo
        
        % root zone properties
        RootDepth; %depth of rooting zone: not used now; include option to 'force' all roots within soil surface and RootDepth
        RAI; %total fine root area index (m2/m2)
        rad; % vertical fine root area distribution (m2/m3)
        rootradius = 2e-3; %m, characteristic radius of fine water-uptaking roots
        RootRadConductivity=5e-8; % s-1, maximum bulk root membrane conductance in radial direction
        %rootmass; %total root mass (kg/m2)
        %RootCondScaling; % scaling parameters for root conductance at low or very high pressure head
        
        %Farquhar model parameters
        Vcmax25opti; % maximum carboxylation velocity (mumolm-2s-1) in full recovery & well-watered conditions
        %Vcmax25; % maximum carboxylation velocity (mumolm-2s-1) in current conditions;
        Vcmax_T=[]; % [3x1]  [Ha(kJ mol-1) Hd(kJ mol-1) Sv(kJ mol-1 K-1)] Vcmax temperature sensitivity parameters
        Vcmax_PsiL=[]; % [2x1] Leaf water potential -dependency [denominator; exponent term]
        
        Jmax25opti; %Jmax (mumolm-2s-1)
        %Jmax25; % Jmax (mumolm-2s-1)
        Jmax_T=[]; %[3x1] [Ha(kJ mol-1) Hd(kJ mol-1) Sv(kJ mol-1 K-1)] Jmax temperature sensitivity parameters
        Jmax_PsiL=[]; % [2x1] Leaf water potential -dependency [denominator; exponent term]
        
        Thetap; % light response curve, curvature parameter
        qeff; % parameter related to quantum efficiency
        
        Rd25opti; % dark respiration rate at 25degC
        Rd_T=[]; %  J mol-1, parameter for Rd sensitivity
        Rd_PsiL=[]; % [2x1] Leaf water potential -dependency [denominator; exponent term]
        
        Kn=0; % leaf nitrogen extinction coefficient for Vcmax scaling: [0 = const. Vcmax, large values indicate rapid decrease with depth]
        %Ncontent; %leaf nitrogen content at top of canopy (units?)
        
        % stomatal control parameters
        StomaType; %1=stomata on one side, 2=stomata on both sides
        go=1e-3; % residual (cuticular) conductance (molm-2(leaf) s-1)
        
        StomaPara; %stomatal model parameters:
        %'BWB': [m_ww beta]; Ball-Berry slope in well-watered conditions (-); PsiL-dependency
        %'Medlyn'; %[2x1] [g1_ww beta]; slope in well-watered conditions; PsiL -dependency
        %'OptiL'; %[3x1] [La_ww(molCO2/molH2O) beta CiCa]; OptiL -model parameters)
        %'Leuning': %[3x1] [m_ww beta Do]; Leuning model slope; PsiL-dependency; scaling VPD
        
        %Interception parametes
        Wmaxrain=0.15; %(mm / unit of LAI), maximum interception capacity of liquid precipitation
        Wmaxsnow=0.30; %(mm / unit of LAI), maximum interception capacity of snowfall
        
        %sapwood respiration, default parameters from Zha et al.
        Q10sapwood=1.9; %sensitivity
        R10sapwood=0.3; %base rate (mumol m-2(sapwood) s-1)
        
        %root respiration (not yet used)
        Q10root=2; %sensitivity
        R10root=[]; %base rate (mumol m-2(sapwood) s-1)
        
        %Seasonal cycle of photosynthetic capacity & LAI dynamics
   
        PhenoState; % S-parameter for stage of development
        PhenoPara; % phenology model parameters
        %'Conifers' [fmin tau T0 Smax]
        %'Deciduous' [fmin DDbudbreak DDsat Doy0_autumn Lenght_autumn]
        
        DegreeDayPara; %[Doy0 Tbase]     
        DDsum;
        LeafGrowthPara;
        LeafSenescencePara;
        
        %state variables
        %LAI; % current LAI (m2/m2)
        RelPhoto_Seasonal=1; % (0...1): relative photocapacity due to seasonal cycle
        %RelPhoto_SoilMoist=1; % (0...1): relative apparent photocapacity due to soil water availability (or PsiL)
        Twood=15; %wood temperature, not currently used
        h_root=-0.1; %m, effective pre-dawn root zone pressure head
        h_leaf; %m, predawn leaf pressure, hydrostatically connected to h_root
    end
    
    methods % class constructor
        function obj=PlantType(SpecName,Switch_LAI, Switch_Pheno, Switch_Stoma_PsiL, z, zs, PT, Root, Photo, Stoma, Respi, Pheno, IniCond )
            disp('Generating PlantType')
            
            N=length(PT.lad); %nr of layers
            
            %Switches
            obj.Species=SpecName;
            obj.Switch_LAI=Switch_LAI;
            obj.Switch_Pheno=Switch_Pheno;
            obj.Switch_Stoma_PsiL=Switch_Stoma_PsiL;
            
            %Structure, physical params. & state variables
            obj.z=z;
            obj.dz=abs(z(2)-z(1));
            obj.hmax=PT.hmax;
            obj.WAI=PT.WAI;
            obj.wad=PT.wad*obj.WAI;
            obj.LAImax=PT.LAImax;
            obj.LAImin=PT.LAImin;
            
            %if Switch_LAI==1, these are recomputed later in initialization
            obj.LAI=PT.LAImax;
            obj.PAI=obj.LAImax+obj.WAI;
            obj.lad=PT.lad*obj.LAI;
            obj.pad=obj.lad + obj.wad;
            
            %leaf/shoot physical properties
            obj.lt=PT.lt;
            obj.PARalb=PT.PARalb;
            obj.NIRalb=PT.NIRalb;
            obj.emi=PT.emi;
            
            %interception capacities
            obj.Wmaxrain=PT.Wmaxrain;
            obj.Wmaxsnow=PT.Wmaxsnow;
            
            % root properties
            obj.RootDepth=Root.RootDepth;
            
            if ~isempty(Root.RAI)
                obj.RAI=Root.RAI;
            else
                obj.RAI=3*obj.LAImax;
            end
            
            obj.rad=zeros(length(zs),1);
            f=find(zs>-obj.RootDepth);
            [~, R]=PlantType.RootDistribution(Root.beta,zs(f));
            obj.rad(f)=obj.RAI*R; clear R f
            %plot(obj.rad,zs),pause, close
            
            %use default parameters if nothing is given
            if ~isempty(Root.FineRootRadius)
                obj.rootradius=Root.FineRootRadius;
            end
            if ~isempty(Root.RadialConductivity)
                obj.RootRadConductivity=Root.RadialConductivity;
            end
            
            %Photosynthetic parameters
            
            if ~isempty(Photo.Kn),
                obj.Kn=Photo.Kn;  % leaf nitrogen extinction coefficient for Vcmax scaling: [0 = const. Vcmax, large values indicate rapid decrease]
            end
            
            obj.Vcmax25opti=Photo.Vcmax25opti;
            obj.Vcmax_T=Photo.Vcmax_T; %temperature dep.; if [] given then omits T -limitations
            obj.Vcmax_PsiL=Photo.Vcmax_PsiL; %PsiL dep. if [] given then omits PsiL -limitations
            
            obj.Jmax25opti=Photo.Jmax25opti;
            obj.Jmax_T=Photo.Jmax_T; %temperature dep.
            obj.Jmax_PsiL=Photo.Jmax_PsiL; %PsiL dep.
            
            obj.Thetap=Photo.Theta;
            obj.qeff=Photo.qeff;
            
            obj.Rd25opti=Photo.Rd25opti;
            obj.Rd_T=Photo.Rd_T; %temperature dep.
            obj.Rd_PsiL=Photo.Rd_PsiL;
            
            %use default parameters if nothing is given
            if ~isempty(Respi.Sapwood),
                obj.Q10sapwood=Respi.Sapwood(1);
                obj.R10sapwood=Respi.Sapwood(2); %base rate (mumol m-2(sapwood) s-1)
            end
            
            if ~isempty(Respi.Root),
                obj.Q10root=Respi.Root(1);
                obj.R10root=Respi.Root(2); %base rate (mumol m-2(ground) s-1)
            end
            
            %Stomatal control parameters            obj.StomaModel=Photo.Para{1}; %'Medlyn';'BWB';'OptiL';'Leuning'
            
            obj.StomaModel=Stoma.Para{1}; %'Medlyn';'BWB';'OptiL';'Leuning'
            obj.StomaPara=cell2mat(Stoma.Para(2:end))'; %StomaPara(1)=slope, StomaPara(2)=PsiL-sensitivity, StomaPara(2)=CiCa or ref_VPD
            
            %initial conditions
            obj.h_root=IniCond.h_root; %m, effective pre-dawn root zone pressure head
            obj.h_leaf=ones(N,1)*obj.h_root -z; %m, predawn leaf pressure, hydrostatically connected to h_root
            %obj.RelPhoto_SoilMoist = 1;
            
            %degree-day model initialization
            obj.DegreeDayPara=Pheno.DegreeDayPara; %[Doy_start Tbase];
            obj.DDsum=IniCond.DDsum;
            
            %if Seasonal cycle of Farquhar-parameters is accounted, compute initial state of machinery
            if strcmpi(obj.Switch_Pheno,'y'),
                obj.PhenoModel=Pheno.PhenoPara{1};
                obj.PhenoPara=cell2mat(Pheno.PhenoPara(2:end))'; %parameters, correspond to 'PhenoModel'
                obj.PhenoState=IniCond.S; %stage of development
                [fPS,~]=obj.Phenology(IniCond.Doy,IniCond.Tair);
                obj.RelPhoto_Seasonal=fPS; %seasonal photocapa
                
                clear fPS
            end
            %if LAI-dynamics is included, 
            if strcmpi(obj.Switch_LAI,'y'),
                obj.LeafGrowthPara=Pheno.LeafGrowthPara; %[DD_sum(budbreak); DDsum(leaf maturation)]
                obj.LeafSenescencePara=Pheno.LeafSenescencePara; %[SenescStartDay; SenescDuration]
                [lai0,pai0,lad0,pad0] = obj.LeafAreaDynamics(IniCond.Doy);
                obj.LAI=lai0; obj.PAI=pai0;
                obj.lad=lad0; obj.pad=pad0;
                clear lai0 pai0 lad0 pad0
            end
        end
        
    end
    
    %% *************************************************************************************************************
    methods % functions for photosynthesis and stomatal control
        
        function [gs_v,An,Rd,Ci,Cs,Lf]=Medlyn_gs(obj,Qp,T,D,Ca,gb_c)
            %Calculates photosynthesis and stomatal conductance using Medlyn et al. (2011)
            %"Unified stomatal model"
            %
            %INPUT: Qp - absorbed PAR at leaves (umol m-2 s-1)
            %       T  - leaf temperature (deg C)
            %       D -  vapor pressure deficit (kPa)
            %       Ca - ambient CO2 mixing ratio (ppm)
            %       gb_c - laminar boundary layer conductance for CO2 (mol m-2 s-1)
            %       g1 - Medlyn model slope parameter (units?)
            %OUTPUT:gs_v - stomatal conductance for H2O (mol m-2 s-1)
            %       An - assimilation rate (umol m-2 s-1)
            %       Rd - dark respiration (umol m-2 s-1)
            %       Ci - leaf internal CO2 mixing ratio (ppm)
            %       Cs - leaf surface CO2 mixing ratio (ppm)
            %       Lf - dummy: 1 if An light-limited, 0 otherwise
            %REF: Medlyn et al. (2011) Global Change Biology (2011) 17, 2134�2144
            %
            % S. Launiainen 7/2013 - 2/2015 (last edit 10.2.2015)
            
            %check inputs
            D(D<0)=0;
            Qp(Qp<0)=0;
            
            %------- compute slope parameter g1 as function of PsiL-----
            PsiL=obj.h_leaf/100; %converts leaf water potential from m to MPa
            PsiL(PsiL<-3)=-3; %ensure PsiL stays within plausible limits
            
            gcut=obj.go;
            g1=obj.StomaPara(1);
            
            if obj.Switch_Stoma_PsiL==1,
                beta=obj.StomaPara(2);
                g1 = g1.*exp(beta.*PsiL);
                clear beta PsiL
            end
            
            %-------------------- Initial Guess for Ci and Solve for An, gs, and Ci
            Ca=1e6*Ca; %ppm
            Ci=0.8*Ca;
            Cs=Ca;
            
            err=1000;
            cnt=0;
            
            while max(max(err))>0.01 && cnt<100
                
                [An,Rd,Gamma_star,Lf] = Farquhar(obj,Qp,T,Ci); % call farquhar
                A=An-Rd; %net assimilation
                A(A<0)=An(A<0);
                %gs=obj.go+ (1 + g1./(D.^0.5)).*A./Ca; %original Medlyn formulation, for CO2
                gs= gcut + (1 + g1./(D.^0.5)).*A./(Cs -Gamma_star); %for CO2
                gs=max(gcut,gs);
                
                % solve for new Ci
                
                Cs=max(Ca-A./gb_c, 0.5*Ca); % supply through boundary layer
                Ci2=max(Cs-A./gs,0.5*Ca); % supply through stomata
                err=abs(Ci-Ci2);
                Ci=Ci2;
                cnt=cnt+1;
                
            end
            
            gs_v=1.6*gs; % stomatal conductance for H2O
            
            % if photo is less than dark respiration, assume stomata closed
            gs_v(An-Rd<0)=1.6*gcut;
            Ci(An-Rd<0)=Ca(An-Rd<0);
            
        end
        
        function [gs_v,An,Rd,Ci,Cs]=BWB(obj,Qp,T,RH,Ca,gb_c)
            %Calculates photosynthesis and stomatal conductance using Ball-Woodrow-Berry -model (1986)
            %
            %INPUT: Qp - absorbed PAR at leaves (umol m-2 s-1)
            %       T  - leaf temperature (deg C)
            %       RH -  relative humidity at leaf temperature
            %       Ca - ambient CO2 mixing ratio (ppm)
            %       gb_c - laminar boundary layer conductance for CO2 (mol m-2 s-1)
            %       m1 - BWB slope parameter (-)
            %OUTPUT:gs_v - stomatal conductance for H2O (mol m-2 s-1)
            %       An - assimilation rate (umol m-2 s-1)
            %       Rd - dark respiration (umol m-2 s-1)
            %       Ci - leaf internal CO2 mixing ratio (ppm)
            %       Cs - leaf surface CO2 mixing ratio (ppm)
            %
            % Gaby Katul & S. Launiainen 2009-2011
            %
            % NOTE: For speed, add analytical solution of Baldocchi xxxx
            
            Qp(Qp<0)=0;
            RH(RH>100)=100;
            RH(RH<0)=0;
            
            %------- compute slope parameter m1 as function of PsiL-----
            PsiL=obj.h_leaf/100; %converts leaf water potential from m to MPa
            PsiL(PsiL<-3)=-3; %ensure PsiL stays within plausible limits
            
            gcut = obj.go; % residual conductance
            m1=obj.StomaPara(1); %slope param in well-watered conditions
            
            if obj.Switch_Stoma_PsiL==1,
                beta=obj.StomaPara(2);
                m1 = m1.*exp(beta.*PsiL);
                clear beta PsiL
            end
            
            %-------------------- Initial Guess for Ci and Solve for An, gs, and Ci
            Ca=1e6*Ca; %ppm
            Ci=0.8*Ca;
            Cs=Ca;
            
            err=1000;
            cnt=0;
            while max(max(err))>0.01 && cnt<200
                
                [An,Rd,Gamma_star] = Farquhar(obj,Qp,T,Ci); % call farquhar
                
                A=An-Rd;%net assimilation
                A(A<0)=0;
                
                gs=gcut+m1.*A./((Cs-Gamma_star)).*(RH/100);
                
                gs=max(gcut,gs);
                
                % solve for new Ci
                Cs=max(Ca-A./gb_c, 0.5*Ca); % supply through boundary layer
                Ci2=max(Cs-A./gs,0.5*Ca); % supply through stomata
                
                err=abs(Ci-Ci2);
                Ci=Ci2;
                cnt=cnt+1;
            end
            gs_v=1.6*gs; % stomatal conductance
            gs_v(An-Rd<0 | An<0)=1.6*gcut; % if photo is less than dark respiration, assume that stomata are closed
        end
        
        
        %      *************************************************************************************************************
        
        function [gs_v,An,Rd,Ci,Cs]=LEUNING(obj,Qp,T,D,Ca,gb_c)
            %Calculates photosynthesis and stomatal conductance using Leuning (1995)-model, a variant of BWB-model
            %
            %INPUT: Qp - absorbed PAR at leaves (umol m-2 s-1)
            %       T  - leaf temperature (deg C)
            %       D -  vapor pressure deficit (kPa)
            %       Ca - ambient CO2 mixing ratio (ppm)
            %       gb_c - laminar boundary layer conductance for CO2 (mol m-2 s-1)
            %       m1 - BWB slope parameter (-)
            %OUTPUT:gs_v - stomatal conductance for H2O (mol m-2 s-1)
            %       An - assimilation rate (umol m-2 s-1)
            %       Rd - dark respiration (umol m-2 s-1)
            %       Ci - leaf internal CO2 mixing ratio (ppm)
            %       Cs - leaf surface CO2 mixing ratio (ppm)
            %
            % Gaby Katul & S. Launiainen 2009-2011
            %
            % NOTE: For speed, add analytical solution of Baldocchi xxxx
            
            
            D(D<0)=0;
            Qp(Qp<0)=0;
            
            %------- compute slope parameter m1 as function of PsiL-----
            PsiL=obj.h_leaf/100; %converts leaf water potential from m to MPa
            PsiL(PsiL<-3)=-3; %ensure PsiL stays within plausible limits
            
            gcut = obj.go; % residual conductance
            m1=obj.StomaPara(1); %slope param in well-watered conditions
            Do=obj.StomaPara(3); %scaling VPD (kPa)
            
            if obj.Switch_Stoma_PsiL==1,
                beta=obj.StomaPara(2);
                m1 = m1.*exp(beta.*PsiL);
                clear m1_ww beta PsiL
            end
            
            %-------------------- Initial Guess for Ci and Solve for An, gs, and Ci
            
            Ca=1e6*Ca; %ppm
            Ci=0.8*Ca;
            Cs=Ca;
            D=max(eps,D); %ensure D is positive
            
            err=1000;
            cnt=0;
            
            while max(max(err))>0.01 && cnt<200
                
                [An,Rd,Gamma_star] = Farquhar(obj,Qp,T,Ci); % call farquhar
                A=An-Rd;%net assimilation
                A(A<0)=0;
                
                %gs=obj.go+m1.*abs(An)./((Cs-Gamma_star)).*(RH/100);
                gs=gcut+m1.*abs(A)./((Cs-Gamma_star)).*(1./(1+D./Do)); %umol m-2 s-1
                
                gs=max(gcut,gs);
                
                % solve for new Ci
                Cs=max(Ca-A./gb_c, 0.5*Ca); % supply through boundary layer
                Ci2=max(Cs-A./gs,0.5*Ca); % supply through stomata
                
                err=abs(Ci-Ci2);
                Ci=Ci2;
                cnt=cnt+1;
                
            end
            gs_v=1.6*gs; % stomatal conductance
            gs_v(An-Rd<0)=1.6*gcut; % if photo is less than dark respiration, assume that stomata are closed
            
        end
        
        
        
        % ********************************************************************************************************
        
        function [gs_v,An,Rd,Ci,Cs]=OptiL(obj,Qp,Tleaf,Dleaf,Ca,gb_c)
            %-- Linearized optimality model for combined Photosynthesis - Stomatal conductance
            %
            %INPUT: Qp - absorbed PAR at leaves (umol m-2 s-1)
            %       Tleaf  - leaf temperature (degC)
            %       Dleaf -  vapor pressure gradient e_sat(Tleaf) - e(amb)(mol/mol )
            %       Ca - ambient CO2 mixing ratio (mol/mol)
            %       gb_c - laminar boundary layer conductance for CO2 (mol m-2 s-1)
            %OUTPUT:gs_v - stomatal conductance for H2O (mol m-2 s-1)
            %       An - assimilation rate (umol m-2 s-1)
            %       Rd - dark respiration (umol m-2 s-1)
            %       Ci - leaf internal CO2 mixing ratio (ppm)
            %       Cs - leaf surface CO2 mixing ratio (ppm)
            %
            %Gaby Katul & S. Launiainen 2009-2011
            
            Ca=1e6*Ca; %umol/mol
            Dleaf=max(eps, 1e6.*Dleaf); %umol/mol
            Coa=0.21e6;%Oxygen consentration in air, umol/mol
            
            % stomatal parameters
            g0 = obj.go; % residual conductance
            Lambda=obj.StomaPara(1).*CO2/380; %marginal WUE (molCO2/molH2O) in well-watered conditions,
            % CO2-response as in Katul et al. (2010) Ann. Bot. 105, 431-442.
            s = obj.StomaPara(3); %long-term mean Ci/Ca -ratio (-)
            
            %------- compute slope parameter g1 as function of PsiL-----
            PsiL=obj.h_leaf/100; %converts leaf water potential from m to MPa
            PsiL(PsiL<-3)=-3; %ensure PsiL stays within plausible limits
            
            % PsiL (MPa) response as in Manzoni et al., 2011 Funct. Ecol. 25, 456-467, see their Table 2
            if obj.Switch_Stoma_PsiL==1,
                beta=obj.StomaPara(2);  %beta ~-0.56 (conifers, wet & mesic climates), ~ -0.13 (evergreen trees & shrubs), ~-1.2 (wet & mesic forb & grasses);
                Lambda = Lambda.*exp(beta.*PsiL);
                clear  beta PsiL
            end
            
            % photosynthetic parameters
            Theta=obj.Thetap; %0.7; % curvature of light response curve
            alpha=obj.qeff; %quantum yield factor of electron transport here assume that Qp is incident PAR; Kellom�ki & Wang, addjusted for PAR absorptivity ~0.85
            
            %alpha=(1-0.15)/2; %quantum yield factor of electron transport here assume that Qp is incident PAR
            %alpha=0.3; % Kellom�ki & Wang, addjusted for PAR absorptivity ~0.85
            
            % addjust coefficients for temperature, seasonal cycle and soil
            % water content
            
            [Vcmax,Jmax,Rd,Gamma_star,Kc,Ko]=Farquhar_Scaling(obj,Tleaf);
            
            %------------- Assume Photosynthesis is Rubisco limited
            %         a1=Vcmax; a2=Kc.*(1+Coa./Ko);
            %         slopec=a1./(s*Ca+a2);
            slopec=Vcmax./(s*Ca + Kc.*(1+Coa./Ko));
            gs=slopec.*(-1+((Ca-Gamma_star)./(1.6*Dleaf.*Lambda)).^(1/2))+ g0; % Rubisco-limited gs
            Av=slopec.*(Ca-Gamma_star).*( 1-sqrt((1.6*Dleaf.*Lambda)./(Ca-Gamma_star)) );
            Ci=Ca-Av./gs; % Ci
            gsv=gs;
            Civ=Ci;
            
            %------------ Assume Photosynthesis is Light-limited
            
            J= ((alpha*Qp + Jmax) - ( (alpha*Qp + Jmax).^2 - 4*Theta*alpha*Qp.*Jmax ).^0.5)/(2*Theta); % potential rate of electron transport
            
            %       a1=J/4;
            %       a2=2*Tau_star;
            %slopeq=a1./(s*Ca+a2);
            slopeq = J/4./(obj.CiCa_ave*Ca + 2*Gamma_star);
            gs=slopeq.*(-1+((Ca-Gamma_star)./(1.6*Dleaf.*Lambda)).^(1/2))+ g0;
            Aj=slopeq.*(Ca-Gamma_star).*( 1-sqrt((1.6*Dleaf.*Lambda)./(Ca-Gamma_star)) );
            Ci=Ca-Aj./gs; % Ci
            gsj=gs; % Light limited gs
            Cij=Ci;
            
            % now select the smaller of Av, Aj
            An=Av;
            Ci=Civ;
            gs=gsv;
            f=find(Aj<Av);
            An(f)=Aj(f);
            Ci(f)=Cij(f);
            gs(f)=gsj(f); clear f
            f=find(An -Rd <0);
            gs(f)=g0; % if photo is less than dark respiration, assume that stomata are closed
            An(f)=0;  % should one set An=0 then?
            Ci(f)=Cij(f); clear f
            Cs=max(Ca-An./gb_c, 0.5*Ca);
            
            gs_v=1.6*gs; % stomatal conductance for H2O
            
            %lowest node = soil surface - WAS THIS DUE TO SMALL U?
            An(1)=An(2);
            Ci(1)=Ci(2);
            Cs(1)=Cs(2);
            gs_v(1)=gs_v(2);
            
        end
        
        %% ************************************************************************************************************
        
        function [An,Rd,Gamma_star,Lf] = Farquhar(obj,Qp,T,Ci)
            %
            %[An, Rd, Tau_star] = Farquhar(Qp,T,Ci) calculates leaf CO2 assimilation (umol m-2 s-1) and dark respiration (umol m-2 s-1)
            %
            % INPUT:    Qp - incident PAR (umol m-2 s-1) ! if absorbed PAR is given,
            %           then adjust 'alpha' below dividing by absorptivity (0.8-0.85)
            %           T - leaf temperature (deg C)
            %           Ci - internal CO2 mixing ratio (umol mol-1)
            %
            % OUTPUT:   An - leaf assimilation rate (umol m-2 s-1)
            %           Rd - dark respiration (umol m-2 s-1)
            %           Gamma_star - CO2 compensation point (umol mol-1)
            %           Lf - dummy = 1 if light-limited, 0 otherwise
            %
            % An is assumed to be minimum of Rubisco (Av), Electron transport (Aj) or Sucrose
            % transport (As) limited photosynthetic rates. Co-limitation is not concerned
            %
            % References:   De Pury and Farquhar (1997), Plant Cell Environ. 20, 537-557.
            %               Medlyn et al., (1999), Plant Cell Environ. 22, 1475-1495
            %               Campbell & Norman (1998). Introduction to Env. Biophysics.
            
            Lf=zeros(size(Qp));
            Qp(Qp<0)=0;
            
            %Get parameters
            Coa=0.21e6;         %Oxygen consentration in air, umol/mol
            Theta=obj.Thetap;    %curvature of light response curve (0.7)
            alpha=obj.qeff;     %quantum yield factor of electron transpor; Kellom�ki & Wang, addjusted for PAR absorptivity ~0.85 % Medlyn et al., 2009 Plant, Cell Env.
            %alpha=0.85*(1-0.15)/2; %quantum yield factor of electron transport - here assume that Qp is incident par absorbed PAR!
            %alpha=0.2; % Kellom�ki & Wang, addjusted for PAR absorptivity ~0.85 % Medlyn et al., 2009 Plant, Cell Env.
            
            [Vcmax,Jmax,Rd,Gamma_star,Kc,Ko]=Farquhar_Scaling(obj,T);
            
            % -------- Rubisco-limited photosynthesis (umol m-2 s-1)
            Av=Vcmax.*(Ci-Gamma_star)./(Ci + Kc.*(1+Coa./Ko));
            
            % ------- electron transport -limited photosynthesis (umol m-2 s-1)
            J= ((alpha*Qp + Jmax) - ( (alpha*Qp + Jmax).^2 - 4*Theta*alpha*Qp.*Jmax ).^0.5)/(2*Theta); % potential rate of electron transport
            
            Aj= J/4.*(Ci-Gamma_star)./(Ci + 2*Gamma_star);
            
            % ------ Sucrose transport limited photosynthesis (umol m-2 s-1)
            As = Vcmax/2;
            
            % ----- select most limiting rate
            An=min(Av,Aj); % umol m-2(leaf) s-1
            An=min(An,As); % umol m-2(leaf) s-1
            
            Lf(Aj<=Av)=1;
            
        end
        
        %% ****************************************************************************************************************
        function [Vcmax,Jmax,Rd,Gamma_star,Kc,Ko]=Farquhar_Scaling(obj,T)
            % Adjusts Farquhar model parameters for seasonal cycle, temperature and soil water potential using
            % formulation of Medlyn et al., 2002.Plant Cell Environ. 25,
            % 1167-1179.
            % INPUT:
            %   obj - PlantType object
            %   T - leaf temperature (degC)
            %OUTPUT: Nx1-arrays
            %   Vcmax, Jmax,Rd (umol m-2(leaf) s-1)
            %   Gamma_star,Kc,Ko (umol/mol)
            %
            %CALLED from PlantType.Farquhar(); PlantType.OptiL()
            %
            %Samuli Launiainen 2012-2015 (last edit 10.2.2015)
            
            Tk=T+273.15; % actual T in Kelvin
            
            TN=298.15; % reference temperature 298.15 K = 25degC
            R=8.314427; % gas constant
            
            %Compute Temperature adjustments
            
            %------  Vcmax -------------%umol m-2(leaf)s-1
            if ~isempty(obj.Vcmax_T), % if obj.Vcmax_T=[] then omit
                Hav=1e3*obj.Vcmax_T(1); %52.75e3; % J mol-1, activation energy Vcmax
                Hdv=1e3*obj.Vcmax_T(2); %202.3e3; % J mol-1, deactivation energy Vcmax
                Svv=1e3*obj.Vcmax_T(3); %672; % J mol-1 K-1, entropy term Vcmax
                
                C=obj.Vcmax25opti.*(1+exp((Svv.*TN - Hdv)./(R*TN)));
                Vcmax=C.*exp(Hav/(R*TN).*(1-TN./Tk)) ./ (1 + exp((Svv.*Tk -Hdv)./(R*Tk)));
                clear C Hav Hdv Svv
            else
                Vcmax=obj.Vcmax25opti;
            end
            
            %------  Jmax ------------- %umol m-2(leaf)s-1
            if ~isempty(obj.Jmax_T),
                Haj=1e3*obj.Jmax_T(1); % 61.74e3; % J mol-1, activation energy Jmax
                Hdj=1e3*obj.Jmax_T(2); %185.2e3; % J mol-1, deactivation energy Jmax
                Svj=1e3*obj.Jmax_T(3); % 624; % J mol-1 K-1, entropy term Jmax
                
                C=obj.Jmax25opti.*(1+exp((Svj.*TN - Hdj)./(R*TN)));
                Jmax=C.*exp(Haj/(R*TN).*(1-TN./Tk)) ./ (1 + exp((Svj.*Tk -Hdj)./(R*Tk)));
                clear C Haj Hdj Svj
                
            else
                Jmax=obj.Jmax25opti;
            end
            
            %------ Rd----- %umol m-2(leaf)s-1
            if ~isempty(obj.Rd_T),
                Har=1e3*obj.Rd_T(1); %32.5e3;  % J mol-1, parameter for Rd sensitivity
                Rd=obj.Rd25opti.*exp(Har*(Tk-TN)./(TN*R*Tk)); %umol/mol
                clear Har
            else
                Rd=obj.Rd25opti;
            end
            
            % -------- account for within-canopy position and phenological stage (computes Nx1 -vectors)
            
            Lcum=cumsum(flipud(obj.lad)*obj.dz)/obj.LAI; %cumulative normalized LAI from canopy top
            f_position=PlantType.ExponentialScaling(1,Lcum,obj.Kn);
            
            Vcmax = Vcmax*obj.RelPhoto_Seasonal.*f_position;
            Jmax = Jmax*obj.RelPhoto_Seasonal.*f_position;
            Rd = Rd*obj.RelPhoto_Seasonal.*f_position;
            clear Lcum f_position

            %------ adjust biochemistry for PsiL -----------
            
            %applies functional shapes from Kellom�ki and Wang to adjust Vcmax,Jmax and Rd with leaf water potential
            PsiL=obj.h_leaf/100; % MPa
            PsiL(PsiL<-3)=-3; %restricts PsiL>=-3 MPa
            
            if ~isempty(obj.Vcmax_PsiL),
                fPsiL=max(0.2, 1./(1 + (PsiL/obj.Vcmax_PsiL(1)).^obj.Vcmax_PsiL(2))); %0.2 is based on nothing, just ensures photocapacity does not drop to zero
                Vcmax=Vcmax.*fPsiL;
                clear fPsiL
            end
            
            if ~isempty(obj.Jmax_PsiL),
                fPsiL=max(0.2, 1./(1 + (PsiL/obj.Jmax_PsiL(1)).^obj.Jmax_PsiL(2))); %0.2 just ensures photocapacity does not drop to zero
                Jmax=Jmax.*fPsiL;
                clear fPsiL
            end
            
            if ~isempty(obj.Rd_PsiL),
                disp('Rd PsiL')
                fPsiL=max(0.2, 1./(1 + (PsiL/obj.Rd_PsiL(1)).^obj.Rd_PsiL(2))); %minimum 0.2 is based on Stetson-method
                Rd=Jmax.*fPsiL;
                clear fPsiL
            end

            %-------- CO2 Compensation point %umol/mol
            
            %Medlyn et al.,1999 Plant Cell. Environ. 22, 1475-1495
            Gamma_star=36.9 +1.88*(Tk-TN) + 0.036*(Tk-TN).^2; %umol/mol
            
            %------- Kc & Ko %umol/mol
            
            %Medlyn et al.,1999 Plant Cell. Environ. 22, 1475-1495
            Kc=404*exp(59.4*(Tk-TN)./(TN*R*Tk)); %Michaelis-Menten constant for CO2 umol/mol
            Ko=2.48e5*exp(36*(Tk-TN)./(TN*R*Tk)); %Michaelis-Menten constant for oxygen inhibition umol/mol
            
        end
        
        %% ***************************************************************************************************
        function x = WoodyRespiration(obj,T)
            % calculates above-ground woody biomass respiration profile(umol m-3 s-1)
            %
            % UPDATE THIS SO THAT REAL TRUNK AND BRANCH AREAS ARE USED. OR
            % CHANGE TO MASS-BASED; those estimates or Rwoody are more
            % robust?
            % Xha et al. Ann. Bot. give trunk respiration as fraction of GPP
            
            %assume branch respiration scales as wad
            x=obj.R10sapwood.*obj.Q10sapwood.^((T-10)/10).*obj.wad; % woody biomass respiration (molm-3s-1)
        end
        
        %         function x = RootRespiration(obj,T,An)
        %             %calculates root respiration profile (umol m-3 s-1) if separate
        %             %from heterotrophic respiration
        %             %ADD DESCRIPTION HERE!!!
        %         end
        
        %% ****************************************************************************************************
        function Rd=LeafDarkRespiration(obj,T,Qp)
            % dark respiration rate. This is used for wet leaves only, dry
            % leaves are computed in Leaf_Module by Farquhar-model
            %
            %IN: T - leaf temperature(degC)
            %   Qp - Incident Par (umolm-2s-1)
            %OUT: Rd - dark respiration rate (umol m-2(leaf) s-1)
            
            R=8.314427; %  universal gas constant, Jmol-1
            light_addj=1; % scaling down dark respiration in sunlight
            TN=298.15;
            Tk=T+273.15;
            
            %scale for position within canopy & seasonal phenology
            Lcum=cumsum(flipud(obj.lad)*obj.dz)/obj.LAI; %cumulative LAI from canopy top
            f_position=PlantType.ExponentialScaling(1,Lcum,obj.Kn);
            
            Rd25=obj.Rd25opti.*f_position.*obj.RelPhoto_Seasonal;
            
            %scale for PsiL
            if ~isempty(obj.Rd_PsiL),
                PsiL=obj.h_leaf/100; %MPa
                Rd25=Rd25.*max(0.2, 1./(1 + (PsiL/obj.Rd_PsiL(1)).^obj.Rd_PsiL(2)));
                clear PsiL
            end
            
            %scale for T
            if ~isempty(obj.Rd_T),
                Rd=Rd25.*exp(obj.Rd_T(1)*(Tk-TN)./(TN*R*Tk));
            else
                Rd=Rd25;
            end
            Rd(Qp>50)=light_addj*Rd(Qp>50); % decrease Rd in light
            
        end
        
        %% *********************************************************************************************************
        function f = ScalePhotoCapacity_SoilMoisture(obj)
            % calculate relative addjustment to apparent Vcmax and Jmax as a function of root zone
            % water potential. Ref: Kellom�ki & Wang -paper
            b=obj.Photo_SoilMoistscaling;
            hroot=obj.h_root/100; % MPa
            f=(1+ exp(b(1).*b(2)))./(1 + exp(b(1).*(b(2)-hroot)));
            f(f<0.2)=0.2;
        end
        
        %% ***********Phenology and seasonal cycle *****************************************************************
                
        function [fPS,S] = Phenology(obj,DOY,Tave)
            % estimates seasonal cycle of relative photosynthetic capacity
            
            if strcmpi(obj.PhenoModel,'Hari'),
                %Model1: as function of delayed temperature sum S (Hari, M�kel� et al.) USE For conifers
                
                dt = 24; %timestep in hours  
                f0=obj.PhenoPara(1); %minimum relative photocapa
                tau=obj.PhenoPara(2); %time constant for S (hours)
                T0=obj.PhenoPara(3); %base temperature for S (degC)
                Smax=obj.PhenoPara(4); %S value at which maximum capacity is obtained
            
                % new stage of development
                S=obj.PhenoState + (Tave -obj.PhenoState)/tau*dt; %degC
            
                %modifier for photosynthetic capacity (ref. Kolari Pasi, pers. comm. 12/2013)
                fPS = max(f0, min(1,(S-T0)/(Smax-T0)) ); %[-]
            end
            
            if strcmpi(obj.PhenoModel,'DegreeDays'),
                %Model2: degree-day based model assumes:
                %1) linear increase of photocapacity with temperature sum in
                %spring after bud-break; loosely following Linkosalo et al. 2015 (AFM, submitted
                %manuscript)
                %2) linear decrease with time during autumn senescence (starting from Doy when daylength ~12h)
                %and lasting 20days (loosely following phenology observations and
                %Fracheboud et al., 2009 Plant Phys. aspen-paper)
                %
                %Samuli Launiainen, Luke 6.8.2015
                
               
                f0=obj.PhenoPara(1); %minimum relative photocapacity
                
                dd0=obj.PhenoPara(2); %budburst DDsum
                dd1=obj.PhenoPara(3); %full maturation DDsum
                doy0=obj.PhenoPara(4); %day when senescence starts (corresponds to ~12h daylength)
                Sdur=obj.PhenoPara(5); %period for decrease of photocapa, days
                
                %spring recovery
                if obj.DDsum>dd0;
                    fPS=min(f0+(obj.DDsum-dd0)/(dd1-dd0),1);
                else
                    fPS=f0;
                end
                
                %autumn decline
                if DOY>doy0,
                    fPS=max(f0, 1-(DOY-doy0)/Sdur);
                end
                
                S=[];
            end
        end
        
%         function [S, fPS] = PhotoCapa_SeasonalAcclimation(obj,Tave)
%             % calculates seasonal cycle of photosynthetic capacity [-].
%             %Model1: as function of delayed temperature sum S (Hari, M�kel�
%             %et al.) USE For conifers
%             %Model2: as function of degree-day sum
%             %
%             %INPUT:obj - PlantType-object
%             %      Tave - daily mean temperature (degC)
%             %OUTPUT:
%             %       S - stage of development parameter (degC)
%             %       fPS - scaling factor for seasonal
%             %       acclimation of photosynthetic machinery
%             %CALL once per day!!
%             
%             dt = 24; %timestep in hours
%             %S0=obj.PhenoState; %initial stage of development
%             tau=obj.PhenoPara(1); %time constant for S (hours)
%             T0=obj.PhenoPara(2); %base temperature for S (degC)
%             Smax=obj.PhenoPara(3); %S value at which maximum capacity is obtained
%             
%             % new stage of development
%             
%             S=obj.PhenoState + (Tave -obj.PhenoState)/tau*dt; %degC
%             
%             %modifier for photosynthetic capacity (ref. Kolari Pasi, pers. comm. 12/2013)
%             
%             fPS = max(0.1, min(1,(S-T0)/(Smax-T0)) ); %[-]
%             
%         end
%         
%         function fPS=PhotoCapa_SeasonalAcclimation_DegreeDays(obj,DOY)
%             %fPS=PhotoCapa_SeasonalAcclimation_DegreeDays(obj, DOY)computes recovery of birch photocapacity as
%             %function of degree-day sum (dd).
%             %Assumes:
%             %1) linear increase of photocapacity with temperature sum in
%             %spring after bud-break; loosely following Linkosalo et al. 2015 (AFM, submitted
%             %manuscript)
%             %2) linear decrease with time during autumn senescence (starting from Doy when daylength ~12h)
%             %and lasting 20days (loosely following phenology observations and
%             %Fracheboud et al., 2009 Plant Phys. aspen-paper)
%             %
%             %Samuli Launiainen, Luke 6.8.2015
%             %
%             %IN:
%             %   obj - PlantType-object
%             %   DOY - day of year
%             %
%             %OUT:
%             %   fPS - relative photocapa (0...1)
%             %CALL once per day!
%             
%             dd=obj.DDsum; %degree-day sum
%             f0=obj.PhenoPara(1); %minimum relative photocapacity
%             
%             dd0=obj.PhenoPara(2); %budburst DDsum
%             dd1=obj.PhenoPara(3); %full maturation DDsum
%             doy0=obj.PhenoPara(4); %day when senescence starts (corresponds to ~12h daylength)
%             Sdur=obj.PhenoPara(5); %period for decrease of photocapa, days
%             
%             %spring recovery
%             if dd>dd0;
%                 fPS=min(f0+(dd-dd0)/(dd1-dd0),1);
%             else
%                 fPS=f0;
%             end
%             
%             %autumn decline
%             if DOY>doy0,
%                 fPS=max(f0, 1-(DOY-doy0)/Sdur);
%             end
%         end

        function [LAI,PAI,lad,pad] = LeafAreaDynamics(obj,doy)
            %function fLai = LeafAreaDynamics(obj,DD) describes
            %LAI-dynamics as function of degree-day sum or day of year
            
            %INPUT: obj - PlantType object
            %       doy - day of year
            %OUTPUT:
            %   LAI - leaf area index (m2/m2)
            %   PAI - plant area index (m2/m2)
            %   lad - leaf area density (m2/m3)
            %   pad - plant area density (m2/m3)
            %
            %Call once per day!
            
            %LAI = obj.LAI;
            DDbudbreak=obj.LeafGrowthPara(1);
            DDmatur = obj.LeafGrowthPara(2);
            
            SenescStart = obj.LeafSenescencePara(1);
            SenescDuration = obj.LeafSenescencePara(2);
            
            if obj.DDsum<DDbudbreak,
                LAI=obj.LAImin;
            end
            %growth period
            if obj.DDsum>=DDbudbreak && doy<SenescStart,
                LAI=obj.LAImin + (obj.LAImax - obj.LAImin)/(DDmatur - DDbudbreak)*(obj.DDsum - DDbudbreak);
                LAI = min(LAI, obj.LAImax);
            end
            
            %senescence period
            if doy>=SenescStart
                %disp('senescence');
                LAI = obj.LAImax - (obj.LAImax-obj.LAImin)*min((doy-SenescStart)/SenescDuration, 1);
            end
            lad=obj.lad*(LAI/obj.LAI); %scale leaf-area-density
            pad=obj.wad + lad; % new plant area density
            PAI=obj.WAI + LAI; % new plant area index
        end
        
    end
    %% ********** Static functions ********************************************************************
    % These can be run anywhere without instance of PlantType -class object.
    % Call: y=PlantType.ExponentialScaling(y0,Lcum,Kn)
    
    methods(Static)
        
        function dd=DegreeDaySum(DOY,Tave,dd0,para)
            %computes degree-day sum
            %
            %IN:DOY - day of year
            %   Tave - daily mean temperature (degC)
            %   dd0 - initial degree-day sum
            %   para: [doy_start Tbase]
            %OUT:
            %   dd - degree-day sum
            %CALL once per day!
            
            Doy0=para(1);
            Tbase=para(2);
            
            if DOY<Doy0,
                dd=0;
            else
                dd = dd0+ max(0, Tave - Tbase);
            end
        end
        
        function y=ExponentialScaling(y0,Lcum,Kn)
            %exponential degrease of quantity y0 with normalized cumulative leaf area
            %Lcum ([0-1]) from canopy top. Kn is dimensionless extinction
            %coefficient (Kn=0 for depth-constant y=y0)
            y=y0.*flipud(exp(-Kn.*Lcum));
        end
        
        function x=SetPropertyToVector(N,mask,xx)
            x=zeros(N,1).*NaN;
            x(mask>0)=xx;
        end
        
        function [esat]=e_sat(T)
            % Saturation vapor pressure over water surface (Pa)
            % T in degC
            esat = 611.* exp((17.502.*T)./(T + 240.97)); %Pa
        end
        
        function [Y, R] =RootDistribution(beta,d)
            %returns cumulative (Y) and root area density (R) distribution
            %with depth. sum(Y)=1.
            %Uses model of Gale and Grigal, 1987 Can. J. For.Res., 17, 829 - 834.
            %
            %beta is dimensionless factor and d depth (m)
            
            d=abs(d*100); % depth in cm
            
            Y=1-beta.^d; % cumulative distribution (Gale & Grigal 1987)
            R=-beta.^d*log(beta); % root distribution as a function of depth
            
            % addjust cumulative distribution to match soil profile depth
            %R(1:3)=1e-15; Y(1:3)=1e-15; %first 3 layers assume no roots (L&F -layer)
            R=R./sum(R);
            Y=Y./max(Y);
            
            %             figure()
            %             subplot(121); plot(Y,-d,'r-'); xlabel('Y(z)'); ylabel('z (cm)')
            %             subplot(122); plot(R,-d,'g-'); xlabel('R(z)'); ylabel('z (cm)')
            %             pause, close
        end
        
        function [a]=generate_LAD_Weibul(z,LAI,h,b,c)
            %generate_LAD_Weibul.m: This function generates a Weibul-distributed
            %Leaf Area density profile based on a specified leaf area index
            %INPUT: z, LAI, canopy height h, and shape and scale parameters b,c.
            %z is height
            %OUT: lad
            %
            %Reference: Teske, M.E., and H.W. Thistle, 2004, A library of forest canopy
            %structure for use in interception modeling, Forest Ecology and Management,
            %198, 341-350. n.b. their formula is missing brackets for the scale param.
            %
            %Gabriel Katul, 2009
            %-------------------------------------------------------------------------
            %N=length(z);
            dz=z(2)-z(1);
            a=0*z;
            xx=z(z<=h);
            xx=xx/h;
            
            nn=length(xx);
            a(1:nn)=-(c/b)*(((1-xx)/b).^(c-1)).*(exp(-((1-xx)/b).^c))./(1-exp(-(1/b)^c));
            %a=smooth(a,10);
            %a=a';
            a=LAI*(a./(sum(a.*dz)));
        end
        
        function [gb_h,gb_v,gb_c,gb_O3]=leaf_boundarylayerconductance_mixed(U,lt,T,dT)
            %
            % Computes 2-sided leaf boundary layer conductance assuming mixed forced and free
            % convection form two parallel pathways for transport through leaf boundary layer.
            %
            %INPUT: U - mean velocity (m/s)
            %       lt - characteristic dimension of the leaf in parallell to wind
            %       T - ambient temperature (degC)
            %       dT - temperature difference between leaf and air (degC)
            %OUTPUT: boundary-layer conductances (mol m-2 s-1)
            %
            %Reference: Campbell, S.C., and J.M. Norman (1998),
            %An introduction to Environmental Biophysics, Springer, 2nd edition, Ch. 7
            
            %Gaby Katul & Samuli Launiainen
            
            grav=9.81;      %Acceleration due to gravity (m/s2)
            rho=41.6;       %Density of air (mol/m3) at 20oC
            mu=15.1e-6;     %kinematic Viscosity of air at 20oC [m2/s]
            
            D_H=21.4e-6;    %Thermal diffusivity of air 20oC [m2/s]
            D_c=15.7e-6;    %Molecular diffusivity of CO2 in air at 20oC [m2/s]
            D_v=24.0e-6;     %Molecular diffusivity of water vapor in air at 20oC [m2/s]
            D_O3=14.4e-6;   %Molecular diffusivity of O3 in air at 20 oC [m2/s]
            
            Pr=mu/D_H;             %Prandtl number
            Re=lt.*(U+eps)/mu;      %Reynolds number
            Sc_c=mu/D_c;            % Schmidt numbers
            Sc_v=mu/D_v;
            Sc_O3=mu/D_O3;
            
            Gr=grav*lt.^3.*abs(dT)./((T+273.15).*mu.^2); % Grashoff number (ratio of buyoant force times inertial force to the square of viscous force)
            
            %--------- conductance for heat ----------------
            
            gb_hfo=(0.664*rho*D_H*Pr^(1/3))*(Re.^(1/2))./(lt+eps); %laminar forced convection molm-2s-1
            gb_hfr=0.54*rho*D_H*(Gr.*Pr).^(1/4)./(lt+eps); % free convection molm-2s-1
            
            gb_h=2*gb_hfo + 1.5*gb_hfr; % conductors in parallel
            %factor 2 accounts for upper and lower sides of leaf, factor 1.5 is since
            %convection from cooler surface facing up or hotter facing down is ~0.5
            %times that of free convection (Campbell and Norman, 1998)
            
            %---------- conductance for CO2
            gb_cfo=0.664*rho*D_c*Sc_c^(1/3)*(Re.^(1/2))./(lt+eps);
            gb_cfr=0.54*rho*D_c*(Gr*Sc_c).^(1/4)./(lt+eps); % free convection molm-2s-1
            
            gb_c=2*gb_cfo + 1.5*gb_cfr; % conductors in parallel
            %---------- conductance for H2O
            gb_vfo=0.664*rho*D_v*Sc_v^(1/3)*(Re.^(1/2))./(lt+eps);
            gb_vfr=0.54*rho*D_v*(Gr*Sc_v).^(1/4)./(lt+eps); % free convection molm-2s-1
            
            gb_v=2*gb_vfo + 1.5*gb_vfr; % conductors in parallel
            %---------- conductance for O3
            gb_O3fo=0.664*rho*D_O3*Sc_O3^(1/3)*(Re.^(1/2))./(lt+eps); %laminar forced convection molm-2s-1
            gb_O3fr=0.54*rho*D_O3*(Gr*Sc_O3).^(1/4)./(lt+eps); % free convection molm-2s-1
            
            gb_O3=2*gb_O3fo + 1.5*gb_O3fr; % conductors in parallel
            
        end
    end
end

    %         function [Hs,Q,T] = WoodEnergyBalance(obj,dt,z,wai,Rabs,Ta,U)
%             % COMPUTES WOODY BIOMASS ENERGY BALANCE. THIS IS FISHY; does not work well and assumptions are
%             % questionable!
%             N=length(z);
%             %% Physical constants
%             cp=29.3; % J/mol/K molar heat capacity of air at constant pressure
%             
%             b = 5.6697e-8; % W m-2 K-4 Stefan-Boltzmann const
%             ef=0.98;
%             cw=4181; %spec. heat of water J/kg/K
%             cdw=1500; %spec.heat of dry wood J/kg/K
%             
%             
%             F=wai./sum(wai);
%             C=(0.5*cw +cdw)*F*obj.Mbranch; %heat capacity per unit ground area J m-2 K-1
%             
%             lto=0.15; % length scale
%             gr=4*ef*b*(Ta+273.15).^3/cp; % radiative conductance mol m-2 s-1, Campbell & Norman, 1998
%             
%             [ ~,~,gb_h,~]=boundary_layer_conductance (U,lto); % molm-2s-1
%             ghr=gr+gb_h;
%             
%             dzs=z(2)-z(1);
%             To=obj.Twood; % initial temperature
%             Q=zeros(N,1);
%             Hs=zeros(N,1);
%             Fr=zeros(N,1);
%             
%             dts=dt/100;
%             
%             for m=1:10,
%                 for k=1:N,
%                     Q(k)=wai(k)*(Rabs(k) - cp*ghr(k)*(To(k)-Ta(k))); %change in heat storage (Wm-2)
%                 end
%                 
%                 %H(:,m)=cp*gb_h.*(To-Ta).*wai;
%                 %Fr(:,m)=cp*gr.*(To-Ta).*wai;
%                 Hs=Hs + cp*gb_h.*(To-Ta).*wai*dts;
%                 Fr=Fr + cp*gr.*(To-Ta).*wai*dts;
%                 dT=Q./C*dts;
%                 T=To + dT;
%                 To=T;
%             end
%             
%             Hs=Hs/dt;
%             Hs(wai==0)=0;
%             Fr=Fr/dt;
%             
%             Qs=C.*(T-obj.Twood)/dt; %change in heat storage
%             
%             %             A=gb_h./(gr + gb_h);
%             %
%             %             F=Rabs + Qs;
%             %             Hs=A.*F;
%             %             Hs(C==0)=0;
%             %             Frs=(1-A).*F;
%             
%             %             figure(888);
%             %             subplot(221); plot(Rabs,z,'r-');title('Rabs')
%             %             subplot(222); plot(obj.Twood,z,'k-',T,z,'r-',Ta,z,'g-');title('T')
%             %             subplot(223); plot(C,z,'r-');title('C')
%             %             subplot(224); plot(Hs,z,'r-',Qs,z,'b-',Fr,z,'g-');title('H,Q&Fr')
%             
%             
%             
%             %             RR=nansum(Rabs)
%             %             QQ=nansum(Qs)
%             %             H=nansum(Hs)
%             %             Frss=nansum(Frs)
%             
%             
%             
%             
%             %             for k=1:N
%             %                 if F(k)>0
%             %                     x0=T0(k);
%             %                     Febal=@(Tw) C(k)*Tw -dts*(Rabs(k) - cp*ghr(k)*(Tw-Ta(k))) +C(k).*T0(k);
%             %                     T(k)=fzero(Febal,x0);
%             %                 end
%             %                 Hcum=cp*ghr.*(T-Ta)*dts;
%             %                 T0=T;
%             %             end
%             
%             %energy balance
%             %d(C*T)/dt=Rabs - cp*ghr*(T-Ta) = C*dT/dt=Rabs - a*T +a*Ta
%             %has solution T(t)=K*exp(-a*t/C)+Rabs/a +Ta
%             
%             %             a=cp*ghr;
%             %             K=T0 - Rabs./a - Ta;
%             %             T=K.*exp(-a*dt./C) +Rabs./a + Ta;
%             
%             %
%             
%         end


        