function [sl, sh]=Leaf_Module_FullEB(OBJ,H2O,CO2,T,P,PAR_sl,PAR_sh,q_sl1,q_sh1,q_sl2,q_sh2,LW,U)
%
%  VERSION 10.02.2015 Samuli Launiainen (Luke)
%
% CALCULATES leaf photosynthesis (An), respiration (Rd), transpiration (E) and estimates of
% leaf temperature (Tleaf) and sensible heat fluxes (H) based on simplified leaf energy balance equation coupled with
% leaf-level photosynthesis and stomatal regulation descriptions. 
% Surface energy balance calculation is based on Isothermal net radiation -approximation, thereby eliminating the need for 
% iterations with radiation-sceme.
% 
% Photosynthesis is calculated based on biochemical model of Farquhar et
% al. (1980) in its simplified for where An = min(Av,Aj,As) where Av=Rubisco-limited (light-saturated rate), 
% Aj=RuBP regeneration (light) limited and Sc= sucrose transport limited rate.
%
% Stomatal conductance (gsv) is directly linked to An, either by optimal stomatal control principles (OptiL) or 
% Ball-Woodrow-Berry -semi-empirical model (BWB) (Katul et al. 2009, Launiainen et al. 2011; Ball et al., 1989). 
%
% NOTE THAT ALL STOMATAL CONTROL AND FARQUHAR PARAMETERS ARE PROPERTIES OF PlantType -object!
% 
% INPUT:
%       OBJ - PlantType -object with parameters defined in PlantType-class
%       H2O - water vapor mixing ratio (mol/mol)
%       CO2 - carbon dioxide mixing ratio (mol/mol)
%       T - ambient air temperature (degC)
%       P - pressure (Pa)
%       q_sl1 - absorbed PAR at sunlit leaves (Wm-2)
%       q_sh1 - absorbed PAR at shaded leaves (Wm-2)
%       q_sl2 - absorbed NIR at sunlit leaves (Wm-2)
%       q_sh2 - absorbed NIR at shaded leaves (Wm-2)
%       LW - net isothermal long-wave radiation (Wm-2)
%       U - mean wind speed (m/s)
%
%OUTPUT: structures 'sl' (sunlit leaves) and 'sh' (shaded leaves) with fields
%           .An -CO2 assimilation (umol m-2 leaf s-1)
%           .Rd -CO2 respiration (umol m-2 leaf s-1)
%           .E - H2O flux (transpiration) mol m-2 leaf s-1)
%           .H - sensible heat flux (W m-2 leaf)
%           .Fr - non-isothermal radiative flux (W m-2)
%           .Tleaf - leaf temperature (degC)
%           .Ci - leaf internal CO2 mixing ratio (mol/mol)
%           .Cs - leaf surface CO2 mixing ratio (mol/mol)
%           .gsv - stomatal conductance for H2O (mol m-2 leaf s-1)
%           .gbv - leaf boundary layer conductance for H2O (mol m-2 leaf s-1)
%
%CONTAINS:  "e_sat" - saturation vapor pressure at
%           "dSdT" - slope of saturation vapor pressure curve
%USES:      Functions "OptiL" and "BWB" defined in PlantType classdef -file
%           to calculate An, Rd, E and gsv
%           external function "boundary_layer_conductance" - estimates boundary layer
%           conductances for heat, H2O and CO2 based on flat-plate theory and forced convection
%           
%          
%USAGE:     Vectorized code can be used in multi-layer sense where inputs
%           [H20,T,q_sl1,q_sh1,q_sl2,q_sh2,LW,U] are vectors of equal length
%           
%
%Samuli Launiainen (METLA) 3/2011 -7/2012
% v. 03.08.2012

    %outputs
    sl=struct(); %sunlit leaves
    sh=struct(); %shaded leaves
    
    %% ------------ CONSTANTS and parameters --------------------------------------
    cp=29.3; % J/mol/K heat capacity of air at constant pressure
    L=44100; %J/mol latent heat of vaporization at 20 deg C
    parcf=4.56; % conversion from Wm-2 to micromol m-2 s-1
    b = 5.6697e-8; % W m-2 K-4 Stefan-Boltzmann const
    NT=273.15;
    
    alpha_p=1; % leaf par absorptivity. Here equals 1 since inputs include absorbed radiation
    alpha_n=1;
    
    N=length(H2O); %number of gridpoints
    
    %leaf properties
    lt=OBJ.lt;% Leaf length scale for aerodynamic resistance (m) - order or mm to cm
    ef=OBJ.emi;  % leaf emissivity for thermal radiation, order of 0.96-0.99
        
    %radiative conductance 
    %gr=4*ef*b*(T+273.15).^3/cp; % radiative conductance mol m-2 s-1, Campbell & Norman, 1998
    %gr=eps;
    
    
    for k=1:2,
        if k==1, %---sunlit leaves
            Qp=PAR_sl.*parcf; % PAR
            Qp(Qp<0)=0;     
            Rabs=alpha_p*q_sl1 + alpha_n*q_sl2 + ef*LW; % absorbed SW radiation + isothermal net LW radiation (Wm-2)
        end
        
        if k==2, % ---shaded leaves
            Qp=PAR_sh.*parcf; % PAR
            Qp(Qp<0)=0;     
            Rabs=alpha_p*q_sh1 + alpha_n*q_sh2 + ef*LW; % absorbed SW radiation + isothermal net LW radiation (Wm-2)     
        end
        D=e_sat(T)./P - H2O; % VPD in units mol/mol
        s = dSdT(T)./P; % slope of vapor pressure curve at T, Pa/Pa = mol/mol
    
        Tleaf=T; %initial guesses for leaf temperature and vapor pressure deficit
        Dleaf=D;
    
        [gb_h,gb_v,gb_c,~]=PlantType.leaf_boundarylayerconductance_mixed(U,lt,T,Tleaf-T);% first guess for leaf boundary layer conductance assuming Tleaf=Ta
   
        %-------- Start iterative solution
        NN=0;
        err=10^9;
        while err>0.01 && NN<200
            NN=NN+1;
            Told=Tleaf;
            
            if strcmpi(OBJ.StomaModel,'Medlyn'), % Medlyn et al. unified stomatal model
                Dl=Dleaf*P/1000; % kPa
                [gsv,An,Rd,Ci,Cs,Lf]=OBJ.Medlyn_gs(Qp,Tleaf,Dl,CO2,gb_c); % call Medlyn model
            end
            
            if strcmpi(OBJ.StomaModel,'OptiL'),
                [gsv,An,Rd,Ci,Cs]=OBJ.OptiL(Qp,Tleaf,Dleaf,CO2,gb_c); % call OptiL
                Rd(Qp>100)=0.5*Rd(Qp>100); % reduce dark respiration in light
            end
            
            if strcmpi(OBJ.StomaModel,'BWB'),
                RHleaf=100*(1-Dleaf*P./e_sat(Tleaf)); % relative humidity at leaf temperature (%)
                [gsv,An,Rd,Ci,Cs]=OBJ.BWB(Qp,Tleaf,RHleaf,CO2,gb_c); % callBWB
            end
            
            if strcmpi(OBJ.StomaModel,'Leuning'), %Leuning model
                Dl=Dleaf*P/1000; % kPa
                [gsv,An,Rd,Ci,Cs]=OBJ.LEUNING(Qp,Tleaf,Dl,CO2,gb_c);
            end
            
%             % FUTURE: one could addjust gs_v based on whether stomata are on one or
%             % both sides - currently parameters that are given are "effective", i.e. include this effect.
%             % gsv_sl=OBJ.StomaType*gsv_sl; % StomaType=1 for hypostomatous (one side) =2 for amphistomatous (both sides)
%             
%             geff = (gb_v.*gsv)./(gb_v+gsv); % efficient "bulk" conductance for H2O mol m-2 s-1 including stomatal and boundary-layer
%             
%             % solve leaf temperature using use Penman's linearization. Campbell & Norman 1998, p.225
%             % in normal conditions VERY GOOD APPROXIMATION!! SEE END OF THE CODE FOR FULL EBALANCE SOLUTION
%             
%             Tleaf= T + (Rabs - L.*geff.*D)./(cp.*(gb_h + gr) + L.*s.*geff); % leaf temperature where Rabs is net SW - isothermal net LW
%             
%             [gb_h,gb_v,gb_c,~]=PlantType.leaf_boundarylayerconductance_mixed(U,lt,T,Tleaf-T);
%             
%             err=max(abs(Tleaf-Told));
            
                   % solves leaf temperature from energy balance equation directly, using fzero
        geff = (gb_v.*gsv)./(gb_v+gsv); % efficient "bulk" conductance for H2O mol m-2 s-1 including stomatal and boundary-layer
    
        for n=1:N,
            x0=T(n)-0.5; % initial guess
            [Tleaf(n),~,exitflag]=fzero(@(Ts) Leaf_Ebal(Ts,n),x0);
        end

%         % solves leaf temperature using use Penman's linearization. Campbell & Norman (1998 p.225)
%         % in normal conditions VERY GOOD APPROXIMATION!!
% 
%         Tleaf= T + (Rabs - L.*geff.*D)./(cp.*(gb_h + gr) + L.*s.*geff); % leaf temperature (degC). Rabs is net SW - isothermal net LW
        
        err=max(abs(Tleaf-Told));

        [gb_h,gb_v,gb_c,~]=leaf_boundarylayerconductance_mixed(U,lt,T,Tleaf-T); % accounts for both forced and free convection.  
        
        end
        clear NN
        Dleaf=e_sat(Tleaf)/P - H2O; % vapor pressure difference between leaf and air, mol/mol
        
        if Dleaf<=0, %neglect condensation, handled in WetLeaf_module
            geff=gb_v;
            Dleaf=0;
        end
    
        
        if k==1, %OUTPUTS SUNLIT LEAVES
            sl.An=An;
            sl.Rd=Rd;
            sl.E=geff.*Dleaf; % water flux (mol m-2 s-1)
            sl.H=cp*gb_h.*(Tleaf - T); % sensible heat flux (Wm-2)
            %sl.Fr=cp*gr.*(Tleaf - T); % non-isothermal radiative flux (Wm-2)
            sl.Tleaf=Tleaf; % leaf temperature (degC)
            sl.Ci=Ci;
            sl.Cs=Cs;
            sl.gsv=gsv;
            sl.gbv=gb_v;
            sl.LWout=ef*b*(Tleaf+NT).^4;
        end
        
        if k==2, %OUTPUTS SHADED LEAVES
            sh.An=An;
            sh.Rd=Rd;
            sh.E=geff.*Dleaf; % water flux (mol m-2 s-1)
            sh.H=cp*gb_h.*(Tleaf - T); % sensible heat flux (Wm-2)
            %sh.Fr=cp*gr.*(Tleaf - T); % non-isothermal radiative flux (Wm-2)
            sh.Tleaf=Tleaf; % leaf temperature (degC)
            sh.Ci=Ci;
            sh.Cs=Cs;
            sh.gsv=gsv;
            sh.gbv=gb_v;
            sh.LWout=ef*b*(Tleaf+NT).^4;
        end
    end

    
    % test function
    figs=2;
    if figs ==1,
        Rabs_sl=alpha_p*q_sl1 + alpha_n*q_sl2 + LW;
        Rabs_sh=alpha_p*q_sh1 + alpha_n*q_sh2 + LW;
        D_sl=(e_sat(Tleaf_sl)/P - H2O)*P/1000;
        D_sh=(e_sat(Tleaf_sh)/P - H2O)*P/1000;
        
        z=1:length(Rabs_sl);
        figure(99);
        
        subplot(331); plot(Rabs_sl,z,'r-', sl.H + L*sl.E,z,'k-'); title('sl R_{abs} & H+LE')
        subplot(332); plot(Rabs_sh,z,'b-', sh.H + L*sh.E,z,'k-'); title('sh R_{abs} & H+LE')
        subplot(333); plot(sl.Tleaf,z,'r-', sh.Tleaf ,z,'b-', T,z,'k:'); title('T_{l,sl}& T_{l,sh}')
        subplot(334); plot(sl.An,z,'r-', sh.An ,z,'b-'); title('A_{n,sl} &A_{n,sh}')
        subplot(335); plot(q_sl1*parcf,z,'r-', q_sh1*parcf,z,'b-')
        subplot(336); plot(L*sl.E,z,'r-', L*sh.E ,z,'b-',sl.H,z,'r:', sh.H ,z,'b:'); title('E_{sl} & E_{sh} & H_{sl} &H_{sh}')
        subplot(337); plot(D_sl,z,'r-',D_sh,z,'b-'); title('Dsl, Dsh');
        subplot(338); plot(sl.gsv,z,'r-',sh.gsv,z,'b-'); title('gs')
        
        pause
    end
    
%% ************************************* Internal functions ******************************************

    function [esat]=e_sat(T)
    % Saturation vapor pressure over water surface
        esat = 611.* exp((17.502.*T)./(T + 240.97)); %Pa
    end

    function ss = dSdT(T)
    % the slope of saturation vapor pressure curve, de_s(T)/dT [in units Pa K^-1]
    %INPUT: T - [degC]
    %OUTPUT: ss - [Pa K-1]
        esat = 611.* exp((17.502.*T)./(T + 240.97)); %Pa (Stull 1988)
        ss=17.502.*240.97.*esat./((240.97+T).^2); % [Pa K-1], from Baldocchi's Biometeorology -notes
    end


%CODE PARTS FOR SOLVING LEAF EBAL WITHOUT LINEARIZATION


    function f=Leaf_Ebal(Ts,m)    
        % Leaf energy balance Wm-2. Uses global variables from calling function
        
        %constants for e_sat(T)
        aa=611; % Pa
        bb=17.502;
        cc=240.97;
        LWout=ef.*b.*(Ts+273.15).^4; %outgoing LW
        
        D=(aa*exp(bb*Ts/(Ts+cc)))/P -H2O(m); %H2O -gradient mol/mol       
        f=Rabs(m) - cp*gb_h(m).*(Ts - T(m)) - L*geff(m).*D - 2*LWout; %Wm-2   
    end

end


