function [S, h_root, Stotal]=RootUptake_Simple(obj,Tr,zs,h,Wliq,Ks)
% divides transpiration rate into soil layers determined by soil-to-root
% hydraulic conductivity
%
% INPUT: obj - PlantType -object
%       Tr - transpiration rate (m/s) 
%       zs - vertical soil grid (m), <0
%       h_soil - soil matrix pressure head (m)
%       Ks - soil hydraulic conductivity (m/s) at h_soil
%       Smax - 0 if uncompensated uptake, 1 if compensated uptake + hydr. redistribution.
%OUTPUT:S - sink term for Richards equation (1/s)
%       h_root - root pressure head (m)
%       S_total - total sink strength (m/s), equals input Tr
%SL 14.8.2015

    %% grid

    N=length(zs);  % nr of nodal points, N is deepest node
    S=zeros(N,1);

    %distances between grid points: dzu is between point i-1 and i, dzl between point i and i+1
    dzu(2:N)=zs(1:N-1) - zs(2:N); dzu(1)=-zs(1); 
    dzl(1:N-1)=zs(1:N-1) - zs(2:N); dzl(N)=(zs(N-1) - zs(N))/2;

    %layer thicknesses
    dz=dzu/2 + dzl/2; 
    dz(1)=dzu(1) + dzl(1)/2;
    clear dzu dzl
    dz=dz';
    % in case h>0 (i.e. saturated layer) set h to zero.
    h(h>0)=0;

    %% root parameters for compensated root water uptake
    % conversion of potential [Pa] --> [m] --> 1/(rho*grav)=1/9.81=0.10194. so, 1MPa=101.94 m ~102 m
    
    RAI=obj.RAI;
    L=obj.rad; % root area distribution in layer (m2 fine roots  m-3 soil)
    D=obj.RootDepth; %root zone depth (m)
    r = obj.rootradius; %effective fine root radius, order of 10-3 m
    RootCond=obj.RootRadConductivity; %Krr_max=5e-8; % s-1, bulk root membrane conductance in radial direction

    % calculate conductance from bulk soil to root
    alpha=sqrt(D/RAI)/sqrt(2*r); %[-]
    
    Ksr=alpha*Ks.*L; % s-1, conductance for water movement from bulk soil to root surface  
    Krr = L.*dz .*RootCond; % s-1, radial conductance via root membranes
    
    K= Ksr.*Krr./(Ksr + Krr); % total conductance s-1
    K(L==0)=0;
    
    % Tr=sum(f*Tr), where f is relative partitioning to layers in root zone
    f=K.*dz./sum(K.*dz);
    
    S=f.*Tr./dz; %sink term to Richards equation s-1
    Stotal=sum(S.*dz);
    %err=Stotal-Tr;
    h_root=sum(f.*h); % root zone effective water potential (m)
    
    
% 
%     figure(100)
%     subplot(221); plot(K,zs,'k.-', Ksr,zs,'r-',Krr,zs,'g-'); %legend('combined soil-root K')
%     subplot(222); plot(h,zs,'k-', h_root,zs,'ro'); legend('soil','root')
%     subplot(223); plot(S,zs,'g-'); xlabel('Rootuptake m3/m3/s')
%     subplot(224); plot(L./max(L),zs,'r-',h,zs,'k-')
%     pause

end

% function [S, h_root]=BigRootUptake(obj,Tr,zs,h_soil,Ks,comp)
% % models root water uptake
% % INPUT: obj - PlantType -object
% %       Tr - transpiration rate (m/s) 
% %       zs - vertical soil grid (m), <0
% %       h_soil - soil matrix pressure head (m)
% %       Ks - soil hydraulic conductivity (m/s) at h_soil
% %       comp - 0 if uncompensated uptake, 1 if compensated uptake + hydr. redistribution.
% %OUTPUT:S - sink term for Richards equation (1/s)
% %       h_root - root pressure head (m)
% %
% %SL 21.5.2012
% 
%     %%
% 
%     N=length(zs);
%     S=zeros(N,1);
%     
%     dz(2:N)=zs(1:N-1)-zs(2:N);
%     dz(1)=-2*zs(1);
%     dz=abs(dz)';
% 
%     %% root parameters for compensated root water uptake
%     % conversion of potential [Pa] --> [m] --> 1/(rho*grav)=1/9.81=0.10194. so, 1MPa=101.94 m ~102 m
% 
%     L=obj.rad; % root lenght distribution (m fine roots  m-3 soil)
%     % root conductivity scaling coefficients: GIVE AS PlantType-properties
%     ar1= 1.75*102; % for boxelder roots in Sperry et al. 1998
%     ar2=1.8; 
%     
% %     ar1=obj.RootCondScaling(1);
% %     ar2=obj.RootCondScaling(2);
%     %Krz_max=2e-4; % ms-1, bulk root conductivity in axial direction
%     Krr_max=obj.RootRadConductivity; %Krr_max=5e-8; % s-1, bulk root membrane conductance in radial direction
%     Xs=1e-3; % m, characteristic length from bulk soil to root surface, this should depend on root lenght density
%     % Xs=(pi.*L).^(-0.5); assuming cylindrical geometery and closest possible
%     % packing in soil, Xs could be determined from root length density L (m/m3), Sperry et al., 1998
% 
%     
%     % disp values for checking
%     
%     if comp==0, %uncompensated uptake assuming constant root density
%         D=obj.rootdepth; %m
%         f=find(-zs<=D); % rootlayers
%         b=S;
%         b(f)=dz(f)/D;
%         b=b/sum(b);
%         S=b./dz*Tr; % uptake distribution [1/s].
%         
%         %sum(S.*dz) - Tr;
%         h_root=sum(b.*h_soil); %root-zone averaged soil matrix pressure head
% 
%     end
% 
%     if comp==1, % compensated uptake + hydr. redistribution
%         % soil-to-root conductance for sink term. Assume that Krz>>Krr so that it
%         % can be neglected here
%         
%         b=L.*dz/sum(L.*dz) % initial normalized uptake distribution [1/m]
%         
%         bb=sum(b)
%         pause
%         h_root0=sum(b.*h_soil); %initial guess for root pressure head (m)
%         
%         err=9999;
%         while err>1e-3
%             Krr=XylemConductivity(h_root0,ar1,ar2,Krr_max); % s-1
%             
%             Ksr= (Ks/Xs).*Krr./((Ks/Xs)+Krr); % s-1, two resistances in series. 
%             
%             % solve h_root (m)
%             h_root=-(Tr -sum(Ksr.*L.*h_soil.*dz))./sum(Ksr.*L.*dz); % m
%             err=abs(h_root-h_root0);
%             h_root0=h_root;
%             S=-Ksr.*L.*dz.*(h_soil - h_root); % s-1 = m3/m3/s water sink/source term
%             clear Ksr Krr
%         end
%         clear err
%     end 
% 
% %     figure(100)
% %     %subplot(221); plot(Ks,zs,'r-', Ksr,zs,'k-'); legend('soil','comb')
% %     subplot(222); plot(h_soil,zs,'k-', h_root,zs,'r-');
% %     subplot(223); plot(S,zs,'g-'); xlabel('Rootuptake m3/m3/s')
% %     subplot(224); plot(Tr-sum(S))
% %     pause
% %     
% %     comp=comp
% %     Tr = Tr
% %     SS=sum(S)
% %% Sub-functions 
%     function x=XylemConductivity(h,a1,a2,Kmax)
%     %Xylem conductivity as a function of pressure head (h), i.e. "xylem
%     %vulnerability curve" according to Sperry & Tyree, 1990; Sperry et al.,
%     %2000 (Weibull-function where a1 and a2 are shape parameters)
%     %
%     %No hysteresis / time delay included here
%     %
%     %INPUT: h - pressure head (m)
%     %       a1 (m), a2 (-)  shape parameters
%     %       Kmax - maximum xylem conductivity (m2s) or conductance (s)
%     %
%         x=exp(-(-h./a1).*a2);    
%         x(x<0.001)=0.001; % avoids crash of the numerics
%         x=Kmax.*x;
%     end
% 
% end