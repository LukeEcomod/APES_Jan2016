

******** README_PlantType.txt ***********************

Date: 09.02.2015 / Samuli Launiainen

*************************************************

Folder /@PlantType: 

Contains Multi-layer Atmosphere-Plant Exchange Simultator (APES) codes for "PlantType" -object.

Files currently used in APES:

PlantType.m : class generator. Contains class-instance dependent & static functions for PlantType (vascular plants) -related processes
		(e.g. Farquhar-photosynthesis model, respiration model, several stomatal control schemes, 
		phenology/seasonal cycle model, etc.)

Leaf_Module.m : Dry-leaf energy balance module which calls several class-dependent functions in PlantType. 
		Calculates leaf temperature & mass & energy exchange separately for sunlit and shaded leaves

RootUptake.m : Distributes root water uptake between soil layers depending of root density distribution and soil matrix properties. 
		Computes root pressure that is used to scale leaf physiological parameters


**************************************************

Not currently in use:


PlantType_FullEB - class definition, uses energy balance solutions without linearization scheme. Numerically unstable.
Leaf_Module_FullEB - as Leaf_Module but solves energy balance without linearization. Numerically unstable


*************************************************
Example of properties & methods, see class def. for details

PlantType_1 = 

  PlantType

  Properties:
                Species: 'Overstory'
             StomaModel: 'Medlyn'
        RootUptakeModel: 'Volpe'
             PhenoModel: []
             Switch_LAI: 'n'
           Switch_Pheno: 'n'
      Switch_Stoma_PsiL: 'y'
                      z: [200x1 double]
                     dz: 0.1005
                   hmax: 15
                 LAImax: 3.5000
                 LAImin: 2.8000
                    WAI: 0.5250
                    LAI: 3.5000
                    PAI: 4.0250
                    lad: [200x1 double]
                    wad: [200x1 double]
                    pad: [200x1 double]
                     lt: 0.0200
                    emi: 0.9800
                 PARalb: 0.1200
                 NIRalb: 0.5000
              RootDepth: 0.6000
                    RAI: 7
                    rad: [33x1 double]
             rootradius: 0.0020
    RootRadConductivity: 5.0000e-008
            Vcmax25opti: 38
                Vcmax_T: [3x1 double]
             Vcmax_PsiL: [-2.0400 2.7800]
             Jmax25opti: 79.8000
                 Jmax_T: [3x1 double]
              Jmax_PsiL: [2x1 double]
                 Thetap: 0.7000
                   qeff: 0.2000
               Rd25opti: 0.8740
                   Rd_T: 33.8700
                Rd_PsiL: []
                     Kn: 0.5000
              StomaType: []
                     go: 1.0000e-003
              StomaPara: [2.2000 0.7000]
               Wmaxrain: 0.1500
               Wmaxsnow: 0.3000
             Q10sapwood: 1.9000
             R10sapwood: 0.3000
                Q10root: 2
                R10root: 1
             PhenoState: []
              PhenoPara: []
          DegreeDayPara: [2x1 double]
                  DDsum: 283.6996
         LeafGrowthPara: []
     LeafSenescencePara: []
      RelPhoto_Seasonal: 1
                  Twood: 15
                 h_root: -0.1000
                 h_leaf: [200x1 double]

  Methods

  PlantType defines APES PlantType -object;
  PlantType can be a plant functional type, a species or age-class of a given species
  Contains physical and ecophysiological parameter values & state variables
 
  Samuli Launiainen, Luke 2012-2015
  LAST EDIT: 19.02.2015


Methods for class PlantType:

BWB                                  OptiL                                
Farquhar                             Phenology                            
Farquhar_Scaling                     PlantType                            
LEUNING                              PlantType_FullEB                     
LeafAreaDynamics                     RootUptake                           
LeafDarkRespiration                  RootUptake_Simple                    
Leaf_Module                          ScalePhotoCapacity_SoilMoisture      
Leaf_Module_FullEB                   WoodyRespiration                     
Medlyn_gs                            

Static methods:

DegreeDaySum                         e_sat                                
ExponentialScaling                   generate_LAD_Weibul                  
RootDistribution                     leaf_boundarylayerconductance_mixed  
SetPropertyToVector               
