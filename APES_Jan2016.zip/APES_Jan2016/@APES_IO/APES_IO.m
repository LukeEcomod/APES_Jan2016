classdef APES_IO
    %APES (Atmosphere-plant exchange simulator) model component
    %contains static methods related to INPUTs and OUTPUTs of APES.
    %
    %Samuli Launiainen, Luke, 23.2.2015
    
    properties
    end
    
    methods 
        function obj=APES_IO()
            obj;
        end
    end
    
    methods (Static)
        
        function [oStand,oPlant,oDLF,oWLF,oFloor,oBryo,oFlux,oMeteo,oRadi,oSoil] = Initialize_Outputs(NPt,NBt,runs,Nlayers,Nsoillayers,LeafFlx)
            %APES_Initialize_Outputs creates and allocates memory for APES -model outputs
            %
            %IN:
            %   NPt - number of PlantTypes
            %   NBt - number of BryophyteTypes
            %   runs - total number of model runs
            %   Nlayers - number of above-ground computational layers
            %   Nsoillayers - number of computational soil layers
            %   LeafFlx -'y' if leaf-scale outputs asked, 'n' otherwisse
            %OUT: structures
            %   oStand
            %   oPlant
            %   oDLF
            %   oWLF
            %   oFloor
            %   oBryo
            %   oFlux
            %   oMeteo
            %   oRadi
            %   oSoil
            %
            %CALLED FROM "APES_main"
            %Samuli Launiainen, Luke 18.02.2015
            
            %intialize output values to NaN's
            dum1=single(ones(1,runs).*NaN); %
            dum2=single(ones(Nlayers,runs).*NaN);
            dum3=single(ones(Nsoillayers,runs).*NaN);
            dum4=single(ones(runs,4).*NaN);
            
            
            oStand=struct('time',dum4,'LAI',dum1,'WAI',dum1,'lad',dum2,'wad',dum2,'NrPlantTypes',dum1,'NrBryoTypes',dum1,'f_bryophyte',dum1,'f_litter',dum1,'Degree_days',dum1);
            
            if strcmpi(LeafFlx,'y'),% wet leaf fluxes (per m2 (leaf) s-1)
                oWLF=struct('time',dum4,'Rabs',dum2,'H',dum2,'LE',dum2,'Tleaf',dum2,'Inter',dum2,'Evap',dum2,'MBE',dum1);
            end
            
            % each PlantType gets its own dimension, i.e. oPlant(1), oPlant(2),..
            oPlant(1:NPt)=struct('time',dum4,'LAI',dum1,'WAI',dum1,'lad',dum2,'wad',dum2,'GPP',dum1,'Respi',dum1,'Tr',dum1,'RelPhoto_Seasonal',dum1,...
                'h_root',dum1,'h_leaf',dum2,'RootSink',dum3);
            
            if strcmpi(LeafFlx,'y'), %dry leaf fluxes (per m2 (leaf) s-1) & T
                for k=1:NPt,
                    oDLF(k).time=dum4;
                    oDLF(k).sl=struct('An',dum2,'Rd',dum2,'E',dum2,'H',dum2,'Tleaf',dum2,'Ci',dum2,'Cs',dum2,'gsv',dum2,'gbv',dum2,'Fr',dum2);
                    oDLF(k).sh=struct('An',dum2,'Rd',dum2,'E',dum2,'H',dum2,'Tleaf',dum2,'Ci',dum2,'Cs',dum2,'gsv',dum2,'gbv',dum2,'Fr',dum2);
                end
            else
                oDLF=[];
            end
            clear k
            
            % forest floor output
            oFloor=struct('time',dum4,'T',dum1,'H',dum1,'LE',dum1, 'G', dum1, 'Fc',dum1,'Rsoil',dum1,'E',dum1,'Esoil',dum1,'Trfall_s',dum1);
            
            % Bryophyte outputs
            if NBt>0,
            for k=1:NBt,
                
                oBryo(k)=struct('time',dum4,'Mdry',dum1,'LAI',dum1,'f_cover',dum1,'T',dum1,'W',dum1,'Theta',dum1,'h',dum1,... %state variables
                    'GPP',dum1,'Respi',dum1,'Rn',dum1,'LWout',dum1,'LE',dum1,'H',dum1,'G',dum1,'dQ',dum1,'Fcapi',dum1); %fluxes
            end
            else
                oBryo=[];
            end
            %oFloor.Litter=struct('Mdry',[],'f_cover',[],'T',[],'W',[]); %litter layer to be included
            
            % stand fluxes
            oFlux=struct('time',dum4,'Fc',dum2,'LE',dum2,'E',dum2,'H',dum2,'G',dum1,'Csource',dum2,'Esource',dum2,'Hsource',dum2);
            
            oMeteo=struct('time',dum4,'U',dum2,'T',dum2,'H2O',dum2,'CO2',dum2,'WatStor',dum2,'df',dum2,'Trfall',dum2);
            
            oRadi=struct('time',dum4,'f_sl',dum2,'SWb1',dum2,'SWd1',dum2,'SWu1',dum2,'SWb2',dum2,'SWd2',dum2,'SWu2',dum2,'LWnet',dum2,'LWup',dum2,'LWdn',dum2,'LWleaf',dum2,'alb1',dum1,'alb2',dum1,'alb_glob',dum1, ...
                'q_sl1',dum2,'q_sh1',dum2,'q_sl2',dum2,'q_sh2',dum2,'q_floor1',dum1,'q_floor2',dum1);
            
            oSoil=struct('time',dum4,'h',dum3,'Wliq',dum3,'Wice',dum3,'T',dum3,'KLh',dum3,'Ktherm',dum3,'GWL',dum1,'Fliq',dum3,'Fvap',dum3,'Fheat',dum3,'Infil',dum1,'Esoil',dum1,'Drain',dum1,...
                'Roff',dum1, 'h_pond',dum1,'RootSink',dum3,'HorizFlux',dum3,'qtop',dum1,'Rsoil',dum1);
            
            clear dum1 dum2 dum3 dum4
            
        end
        
        %write outputs
        
        function write_oBryo(time,MTypes,Flx_b)
            %
            %Saves BryoType -object outputs to structure 'oBryo'; bryophyte-specific values
            global oBryo
            persistent k
            
            if isempty(k) %|| k==length(oBryo(1).time),
                k=1;
            else
                k=k+1;
            end
            
            for n=1:length(MTypes),
                oBryo(n).time(k,:)=time;
                oBryo(n).Mdry(k)=MTypes(n).Mdry; oBryo(n).LAI(k)=MTypes(n).LAI; oBryo(n).f_cover(k)=MTypes(n).f_cover;
                oBryo(n).T(k)=MTypes(n).T; oBryo(n).W(k)=MTypes(n).W; oBryo(n).Theta(k)=MTypes(n).Theta; oBryo(n).h(k)=MTypes(n).h;
                
                oBryo(n).GPP(k)=Flx_b{n}.Anb; oBryo(n).Respi(k)=Flx_b{n}.Rb;
                oBryo(n).Rn(k)=Flx_b{n}.Rn; oBryo(n).LWout(k)=Flx_b{n}.LWout; oBryo(n).H(k)=Flx_b{n}.H;
                oBryo(n).LE(k)=Flx_b{n}.LE; oBryo(n).G(k)=Flx_b{n}.G; oBryo(n).dQ(k)=Flx_b{n}.dQ; 
                oBryo(n).Fcapi(k)=Flx_b{n}.FL_bryo;
            end
            
        end
        
        function write_oFloor(time,Tf,Hf,LEf,Gsoil,Fcf,Rsoil,Ef,Esoil,Trfall_s)
            %
            %Saves outputs to structure 'oFloor'; effective forest floor values & fluxes
            global oFloor
            persistent k
            
            if isempty(k) %|| k==length(oFloor.time),
                k=1;
            else
                k=k+1;
            end
            
            oFloor.time(k,:)=time;
            oFloor.T(k)=Tf;
            oFloor.H(k)=Hf;
            oFloor.LE(k)=LEf;
            oFloor.G(k)=Gsoil;
            oFloor.Fc(k)=Fcf; 
            oFloor.Rsoil(k)=Rsoil;
            oFloor.E(k)=Ef;
            oFloor.Esoil(k)=Esoil;
            oFloor.Trfall_s(k)=Trfall_s;
        end

        function write_oRadi(time,f_sl,SWb1,SWd1,SWu1,SWb2,SWd2,SWu2,LW,alb1,alb2,albGlob,q_sl1,q_sl2,q_sh1,q_sh2,LWup,LWdn,LWleaf,q_soil1,q_soil2)
            %
            %Saves radiation to output oRadi
            
            global oRadi
            persistent k
            
            if isempty(k) %|| k==length(oRadi.time),
                k=1;
            else
                k=k+1;
            end
            
            %radiation -arrays
            oRadi.time(k,:)=time;
            oRadi.f_sl(:,k)=f_sl;
            oRadi.SWb1(:,k)=SWb1; oRadi.SWd1(:,k)=SWd1; oRadi.SWu1(:,k)=SWu1;
            oRadi.SWb2(:,k)=SWb2; oRadi.SWd2(:,k)=SWd2; oRadi.SWu2(:,k)=SWu2;
            oRadi.LWnet(:,k)=LW;
            oRadi.LWup(:,k)=LWup;
            oRadi.LWdn(:,k)=LWdn;
            oRadi.LWleaf(:,k)=LWleaf;
            oRadi.alb1(k)=alb1; oRadi.alb2(k)=alb2; oRadi.alb_glob(k)=albGlob;
            oRadi.q_sl1(:,k)=q_sl1; oRadi.q_sh1(:,k)=q_sh1;
            oRadi.q_sl2(:,k)=q_sl2; oRadi.q_sh2(:,k)=q_sh2;
            oRadi.q_floor1(k)=q_soil1;
            oRadi.q_floor1(k)=q_soil2;
        end
        
        function write_oMeteo(time,U,T,H2O,CO2,W,df,Trfall)
            %
            %Saves microclimate to output oMeteo
            
            global oMeteo
            persistent k
            
            if isempty(k) %|| k==length(oMeteo.time),
                k=1;
            else
                k=k+1;
            end
            
            %microclimatic arrays
            oMeteo.time(k,:)=time;
            oMeteo.U(:,k)=U; oMeteo.T(:,k)=T; oMeteo.H2O(:,k)=H2O; oMeteo.CO2(:,k)=CO2;
            oMeteo.WatStor(:,k)=W; oMeteo.df(:,k)=df; oMeteo.Trfall(:,k)=Trfall;
            
        end
        
        function write_oFlux(time,dz,Csource,Esource,Hsource,Rsource,Fcground,Eground,Hground,Gsoil)
            %
            %Saves stand scale fluxes and sink/source profiles to structure 'oFlux'
            
            L_molar=44100; %J/mol latent heat of vaporization at 20 deg C
            global oFlux
            persistent k
            
            if isempty(k) %|| k==length(oFlux.time),
                k=1;
            else
                k=k+1;
            end
            
            %canopy fluxes
            oFlux.time(k,:)=time;
            
            oFlux.Fc(2:end,k)=cumsum(Csource(2:end).*dz) + Fcground; %umolm-2s-1
            oFlux.Fc(1,k)=Fcground;
            oFlux.H(2:end,k)=cumsum(Hsource(2:end).*dz) + Hground; %Wm-2
            oFlux.H(1,k)=Hground;
            oFlux.E(2:end,k)=cumsum(Esource(2:end).*dz) + Eground;
            oFlux.E(1,k)= Eground; %molm-2s-1
            oFlux.LE(:,k)=L_molar*oFlux.E(:,k); %Wm-2
            oFlux.G(k)=Gsoil; %Wm-2
            
            %sink/source terms
            oFlux.Csource(:,k)=Csource;
            oFlux.Esource(:,k)=Esource;
            oFlux.Hsource(:,k)=Hsource;
            oFlux.Rsource(:,k)=Rsource;
            
        end
        
        function write_oPlant(time,PTypes,PFlx)
            %
            %Saves outputs to structures oPlant, oDLF
            global oPlant oDLF
            persistent k
            
            if isempty(k) %|| k==length(oPlant(1).time),
                k=1;
            else
                k=k+1;
            end
            
            for n=1:length(PTypes)
                f=find(PTypes(n).lad>0);
                
                oPlant(n).time(k,:)=time; oPlant(n).LAI(k)=PTypes(n).LAI; oPlant(n).WAI(k)=PTypes(n).WAI;
                oPlant(n).lad(:,k)=PTypes(n).lad; oPlant(n).wad(:,k)=PTypes(n).wad; %oPlant(n).pad(:,k)=PTypes(n).pad;
                
                oPlant(n).GPP(k)=PFlx(n).GPP; oPlant(n).Respi(k)=PFlx(n).Respi; oPlant(n).Tr(k)=PFlx(n).Transpi;
                
                oPlant(n).RelPhoto_Seasonal(k)=PTypes(n).RelPhoto_Seasonal; oPlant(n).h_root(k)=PTypes(n).h_root;
                oPlant(n).h_leaf(f,k)=PTypes(n).h_leaf(f);
                
                
                if ~isempty(PFlx(n).sl), %dry-leaf fluxes, sunlit leaves. values per m2(leaf)
                    oDLF(n).time(k,:)=time;
                    oDLF(n).sl.An(f,k)=PFlx(n).sl.An(f); oDLF(n).sl.Rd(f,k)=PFlx(n).sl.Rd(f); oDLF(n).sl.E(f,k)=PFlx(n).sl.E(f); oDLF(n).sl.H(f,k)=PFlx(n).sl.H(f);
                    oDLF(n).sl.Tleaf(f,k)=PFlx(n).sl.Tleaf(f); oDLF(n).sl.Ci(f,k)=PFlx(n).sl.Ci(f); oDLF(n).sl.Cs(f,k)=PFlx(n).sl.Cs(f);
                    oDLF(n).sl.gsv(f,k)=PFlx(n).sl.gsv(f); oDLF(n).sl.gbv(f,k)=PFlx(n).sl.gbv(f); oDLF(n).sl.gsv(f,k)=PFlx(n).sl.gsv(f);
                    oDLF(n).sl.Fr(f,k)=PFlx(n).sl.Fr(f);
                end
                
                if ~isempty(PFlx(n).sh), %dry-leaf fluxes, shaded leaves. values per m2(leaf)
                    oDLF(n).time(k,:)=time;
                    oDLF(n).sh.An(f,k)=PFlx(n).sh.An(f); oDLF(n).sh.Rd(f,k)=PFlx(n).sh.Rd(f); oDLF(n).sh.E(f,k)=PFlx(n).sh.E(f); oDLF(n).sh.H(f,k)=PFlx(n).sh.H(f);
                    oDLF(n).sh.Tleaf(f,k)=PFlx(n).sh.Tleaf(f); oDLF(n).sh.Ci(f,k)=PFlx(n).sh.Ci(f); oDLF(n).sh.Cs(f,k)=PFlx(n).sh.Cs(f);
                    oDLF(n).sh.gsv(f,k)=PFlx(n).sh.gsv(f); oDLF(n).sh.gbv(f,k)=PFlx(n).sh.gbv(f); oDLF(n).sh.gsv(f,k)=PFlx(n).sh.gsv(f);
                    oDLF(n).sh.Fr(f,k)=PFlx(n).sh.Fr(f);
                end
                if ~isempty(PFlx(n).RootSink)
                    oPlant(n).RootSink(:,k)=PFlx(n).RootSink;
                end
                
            end
        end
        
        function write_oWLF(time,flx_w,cum_w,Tleaf_w)
            %[flx_w,LEw,Hw,Tleaf_w,W,df,Trfall,cum_w]
            %Saves outputs to structure oWLF
            global oWLF
            persistent k
            
            if isempty(k) %|| k==length(oWLF(1).time),
                k=1;
            else
                k=k+1;
            end
            
            oWLF.time(k,:)=time;
            oWLF.Rn(:,k)=flx_w.Rn;
            oWLF.H(:,k)=flx_w.H;
            oWLF.LE(:,k)=flx_w.LE;
            oWLF.Fr(:,k)=flx_w.Fr;
            oWLF.Tleaf(:,k)=Tleaf_w;
            
            oWLF.Evap(:,k)=cum_w.Evap;
            oWLF.Inter(:,k)=cum_w.Inter;
            oWLF.MBE(k)=cum_w.MBE;
        end

        
        function write_oSoil(time,sobj,FL,Fheat,Infil,Evap,Drain,HorizFlux,Roff,Rootsink,MBE,qtop, Rsoil)
            %
            %Saves SoilProfile outputs to oSoil
            global oSoil
            persistent k
            
            if isempty(k) %|| k==length(oSoil.time),
                k=1;
            else
                k=k+1;
            end
            
            %oSoil=struct('time',dum4,'h',dum3,'Wliq',dum3,'Wice',dum3,'T',dum3,'KLh',dum3,'GWL',dum1,'Fliq',dum3,'Fheat',dum3,'Infilt',dum1,'Esoil',dum1,'Drain',dum1,...
            %    'Roff',dum1, 'h_pond',dum1,'RootSink',dum3,'q_top',dum1,'Rsoil',dum1);
            
            oSoil.time(k,:)=time;
            oSoil.h(:,k)=sobj.h; oSoil.Wliq(:,k)=sobj.Wliq; oSoil.Wice(:,k)=sobj.Wice; oSoil.T(:,k)=sobj.T;
            oSoil.KLh(:,k)=sobj.KLh; oSoil.Ktherm(:,k)=sobj.Ktherm;
            oSoil.GWL(k)=sobj.GWL; oSoil.h_pond(k)=sobj.h_pond;
            oSoil.Fliq(:,k)=FL(:,1) + FL(:,3); %liquid water flux (due dh/dz and dT/dz)
            oSoil.Fvap(:,k)=FL(:,2) + FL(:,4); %water vapor flux (due dh/dz and dT/dz)
            oSoil.Fheat(:,k)=Fheat; %heat flux in soil
            oSoil.MBE(k)=MBE;
            oSoil.qtop(k)=qtop; %m/s
            
            %fluxes, cumulative mm/timestep
            oSoil.Infil(k)=1e3*Infil; oSoil.Esoil(k)=1e3*Evap; oSoil.Drain(k)=1e3*Drain; oSoil.Roff(k)=1e3*Roff;
            % s-1
            oSoil.HorizFlux(:,k)=HorizFlux;
            oSoil.RootSink(:,k)=Rootsink;
            oSoil.Rsoil(k)=Rsoil;
        end
        
        function write_oStand(time,Stand_1)
            
            global oStand
            persistent k
            
            if isempty(k) %|| k==length(oStand.time),
                k=1;
            else
                k=k+1;
            end
            
            oStand.time(k,:)=time;
            oStand.LAI(k)=Stand_1.LAI; oStand.WAI(k)=Stand_1.WAI; oStand.lad(:,k)=Stand_1.lad; oStand.wad(:,k)=Stand_1.wad;
            
        end
        
    end
end

