classdef Stand
    %Stand defines Stand -object of APES. It contains: 
    % 1) user-defined general stand properties
    % 2) Stand total leaf,plant and woody areas as sum of PlantType -objects
    % 3) plant-area -density weighted, layerwise averages of PlantType -object properties
    % 4) State variables of layerwise canopy surface temperature, liquid and snow water storage, dry foliage fraction and soil
    % surface temperature 
    %
    % Samuli Launiainen, Luke, 19.02.2015

    properties (SetAccess = public, GetAccess = public)
        
        SiteName;
        NrPlantTypes; % number of PlantType-objects
        NrBryoTypes; % number of Bryophyte-objects
        LAT; % latitude deg.
        LON;
        ELEV; %m
        Slope; %site slope (%)
        Tave; % average annual temperature (degC)
        
        N; %number of grid points
        z; % height vector (m), >0
        hc; %canopy height (m)
          
        %CanopyClosure; % canopy closure fraction (-); not used now
        ClumpingFactor; % leaf clumping factor (-)
        LeafAngleDistribution; % parameter describing leaf angle distribution (1 = spherical, 0 = vertical, -->inf = horizontal)

        LAI=0; %total canopy leaf-area index
        WAI=0; % total canopy Woody area index
        PAI=0; % total canopy plant area index
        lad=0; %leaf area dentity distribution (m2/m3)
        wad=0; %woody area dentity distribution (m2/m3)
        pad=0; %plant area dentity distribution (m2/m3)
        lt=0; %characteristic dimension for boundary-layer conductance (m)
        emi; %emissivity for thermal radiation (-)
        PARalb=0; %leaf PAR albedo (-)
        NIRalb=0; %leaf NIR albedo (-)
        soilemi; % soil emissivity (-)
        surfPARalb; % forest floor albedo (-)
        surfNIRalb; %
        Wmaxrain=0; % maximum water storage capacity (mm / unit of PAI)
        Wmaxsnow=0; % maximum water storage capacity as snow (mm / unit of PAI)
        
        
        SN_CO2; %ratio of eddy diffusivity of CO2 to momentum; Ks/Km, turbulent Schmidt number
        SN_H2O;
        SN_heat;
        Cd; %drag coefficient
        d; % displacement height / canopy height 
        dPdx; %horizontal pressure gradient
        
        % state variables (Nx1 -vectors)
        
        W;  % canopy water storage per layer (mm / unit of PAI)
        S;  % canopy snow storage per layer (mm / unit of PAI)
        df; % dry fraction per layer (-)
        Tleaf;  % canopy temperature per layer (degC)
        Tfloor; % forest floor / soil surface temperature (degC)
        f_bryophytes=0; % total fractional cover of all bryophyte species
        f_litter=0; % fractional cover of litter/mulch -layer 
        f_baresoil=1; % fractional cover of bare soil: f_baresoil + f_bryophyte + f_litter=1
    end
    
    methods  % class constructor       
        function obj=Stand(Sitename,z,Gen,PTypes,nr_bryotypes,f_bryophytes,f_litter,IniCond)

            obj.SiteName=Sitename;
            obj.NrPlantTypes=length(PTypes);
            obj.NrBryoTypes=nr_bryotypes;
            obj.LAT=Gen.LAT;
            obj.LON=Gen.LON;
            obj.ELEV=Gen.ELEV;
            obj.Slope=Gen.Slope;
            obj.Tave=Gen.Tave;
            obj.N=length(z);
            obj.z=z;
            obj.hc=Gen.hc;
            %obj.CanopyClosure=Gen.CanopyClosure; %not used now
            obj.ClumpingFactor=Gen.ClumpingFactor;
            obj.LeafAngleDistribution=Gen.LeafAngleDistribution;
            
            obj.emi=Gen.emi_leaf;
            obj.soilemi=Gen.emi_soil;
            obj.surfPARalb=Gen.surfPARalb;
            obj.surfNIRalb=Gen.surfNIRalb; 
            
            %flow-field related stuff
            obj.SN_CO2=Gen.SN_CO2;
            obj.SN_H2O=Gen.SN_H2O;
            obj.SN_heat=Gen.SN_heat;
            obj.Cd=Gen.Cd;
            obj.d=Gen.d;
            obj.dPdx=Gen.dPdx;
            
            % following properties are superpositions of PType properties

            for k=1:length(PTypes)
                obj.LAI=obj.LAI+PTypes(k).LAI;
                obj.WAI=obj.WAI+PTypes(k).WAI;
        
                obj.lad=obj.lad + PTypes(k).lad;
                obj.wad=obj.wad + PTypes(k).wad;
            end
            obj.PAI=obj.LAI+obj.WAI;
            obj.pad=obj.lad + obj.wad;
            
            
            for k=1:length(PTypes)
                sp=PTypes(k).pad./(obj.pad+eps);
                sl=PTypes(k).lad./(obj.lad+eps);

                obj.lt=obj.lt+PTypes(k).lt.*sl; %effective leaf lenth scale
                obj.Wmaxrain=obj.Wmaxrain + PTypes(k).Wmaxrain.*sp;
                obj.Wmaxsnow=obj.Wmaxsnow + PTypes(k).Wmaxsnow.*sp;
                clear sp sl
                
                obj.PARalb=obj.PARalb + PTypes(k).PARalb.*PTypes(k).LAI/obj.LAI;
                obj.NIRalb=obj.NIRalb + PTypes(k).NIRalb.*PTypes(k).LAI/obj.LAI;
                
            end

            %state variables;
            obj.W=Stand.SetPropertyToVector(obj.N,obj.pad,IniCond.W);
            obj.S=Stand.SetPropertyToVector(obj.N,obj.pad,IniCond.S);
            obj.df=1-obj.W./(obj.Wmaxrain+eps);
            
            obj.Tleaf=Stand.SetPropertyToVector(obj.N,obj.pad,IniCond.Tair);
            obj.Tfloor=IniCond.Tair;
            
            %fractional covers
            if ~isempty(f_bryophytes), obj.f_bryophytes=f_bryophytes; end
            if ~isempty(f_litter), obj.f_litter=f_litter; end
            obj.f_baresoil=1-obj.f_bryophytes - obj.f_litter; 
            
        end
    end
    

    
    methods(Static)
        
        function x=SetPropertyToVector(N,mask,xx)
            %sets property xx to Nx1 vector where mask~=0. 
            x=zeros(N,1);
            x(mask~=0)=xx;
        end
        
        function [x,y]=SourceProfile(z,ladprofile,Leafflux,Groundflux)
            % scales leaf-level fluxes (e.g. mol m-2 (leaf) into source
            % profile (e.g.  mol m2/m3 s-1)   
            dz=abs(z(2)-z(1));
            x=Leafflux.*ladprofile; %source profile
            x(1)=x(1) + Groundflux;
            y=cumsum(x*dz); % flux profile
        end

 %% ********************************************************************************************************
        function [a]=generate_LAD_Weibul(z,LAI,h,b,c)
            %generate_LAD_Weibul.m: This function generates a Weibul-distributed 
            %Leaf Area density profile based on a specified leaf area index 
            %LAI, canopy height h, and shape and scale parameters b,c.
            %z is height
            %Reference: Teske, M.E., and H.W. Thistle, 2004, A library of forest canopy
            %structure for use in interception modeling, Forest Ecology and Management,
            %198, 341-350. n.b. their formula is missing brackets for the scale param.
            %
            %Gabriel Katul, 2009
            %-------------------------------------------------------------------------
            %N=length(z);
            dz=z(2)-z(1);
            a=0*z;
            xx=z(z<=h);
            xx=xx/h;

            nn=length(xx);
            a(1:nn)=-(c/b)*(((1-xx)/b).^(c-1)).*(exp(-((1-xx)/b).^c))./(1-exp(-(1/b)^c));
            %a=smooth(a,10);
            %a=a';
            a=LAI*(a./(sum(a.*dz)));
        end
        
    end
    
%     methods
%         %located at @Stand -folder.
%         %CanopyLWRad;
%         %CanopySWRad_ZhaoQualls_2005;
%         %CanopySWRad_Spitters_1986;
%         %WetLeaf_Module;
%         %GenerateFlowfield;
%         %closure_1_model_T
%         %closure_1_model_H2O
%         %closure_1_model_CO2
%     end
end

