

******** README_Stand.txt ***********************

Date: 09.02.2015 / Samuli Launiainen


*************************************************

Folder /@Stand: 

Contains Multi-layer Atmosphere-Plant Exchange Simultator (APES) codes for "Stand" -object:


 Stand defines Stand -object of APES. It contains: 
  1) user-defined general stand properties
  2) Stand total leaf,plant and woody areas as sum of PlantType -objects
  3) plant-area -density weighted, layerwise averages of PlantType -object properties
  4) State variables of layerwise canopy surface temperature, liquid and snow water storage, dry foliage fraction and soil
  surface temperature 
 
  Samuli Launiainen, Luke, 19.02.2015



Files currently used in APES:

Stand.m : class definition

WetLeaf_module.m : Interception, throughfall and wet-canopy energy budget in canopy layers



------- in case leaf energy balance is solved without linearization following codes should be used ------

WetLeaf_Module_FullEBAL.m


**************************************************

Interception.m : Interception, throughfall and wet canopy energy budget; simpler scheme. Check this for potential errors!!! 

***************************************************



