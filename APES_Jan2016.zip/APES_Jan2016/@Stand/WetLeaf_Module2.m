function [flx,LEwc,Hwc,Tleaf_w,Wo,df,Trfall,cum]=WetLeaf_Module2(CAN,H2O,T,Pamb,Rabs,U,Prec,dt)

%function [LEw,Hw,Tleaf_w,W,df,Trfall_crown,Trfall_free]=WetLeaf_Module(CAN,H2O,T,P,Rabs,U,Prec,dt)
%updates canopy liquid water storage by partitioning precipitation (Prec) to
%interception (I) and throughfall (Prec-I)at each layer. 
%The temperature of wet leaves is  determined from isothermal heat balance corrected by radiative "conductance"
%(Campbell and Norman, 1998). Evaporation/condensation rate is controlled by esat(Tleaf)-e_amb as the driving force. 
%
%Boundary layer conductances for heat and H2O are calculated from U(z) and leaf dimensions. 
%Rate of change of water stored at each layer (W) is as in Watanabe & Mizutani (1996) Agric. For.
%Meteorol. 80, 195-214 and Tanaka, 2002 Ecol. Mod. 147:
%
%(1) dW(z)/dt = F(1-W(z)/Wmax(z))I(z) - (W(z)/Wmax(z))E(z), I(z)=dPrec/dz=Fa(z)dz(1-W(z)/Wmax(z))Prec(z+dz) when E>0 (evaporation)
%(2) dW(z)/dt = (1-W(z)/Wmax(z))(FI(z)-E(z)), I(z)=dPrec/dz=Fa(z)dz(1-W(z)/Wmax(z))Prec(z+dz) + a(z)dz(W(z)/Wmax(z))E(z) when E<0(condensation)
% 
% a(z) is one-sided plant area density (m2m-3), F fraction of leaf area (0-1) perpendicular to Prec and 
% Wmax(z) maximum water storage (mm) at each layer.
%
% INPUT:
% CAN - Stand -object
% H2O - ambient water vapor mixing ration (mol/mol)
% T - ambient air temperature (degC)
% Pamb - ambient pressure (Pa)
% Rabs - net isothermal radiation at each layer (Wm-2, sum of sunlit & shaded leaves together)
% U - wind speed (ms-1) at each layer
% Prec - precipitation rate (mm/s) above canopy
% dt - time increment (s) for model integration
%
% OUTPUT:
%   flx - structure with fields (flux rate per unit wet leaf area (Wm-2 leaf)):
%       Rn - absorbed SW + isothermal LW (Wm-2 leaf)
%       H - sensible heat flux rate per unit leaf area (Wm-2 leaf)
%       LE - latent heat flux rate per unit leaf area (Wm-2 leaf)
%       Fr_w - non-isothermal radiative flux rate per unit leaf area (Wm-2 leaf)
%   LEwc - latent heat flux from wet fraction (Wm-2 ground), i.e. sum of all layers gives canopy value
%   Hwc - sensible heat flux from wet fraction (Wm-2 ground), i.e. sum of all layers gives canopy value
%   Tleaf_w - wet leaf temperature (degC)
%   Wo - liquid water storage (mm) per layer
%   df - fraction of dry leaves per layer (-)
%   Trfall - throughfall + condensation drip rate (mm/s)
%   cum - structure with fields:
%       cIr - total interception (mm) per layer during dt
%       cE - total evaporation / condensation (mm) per layer during dt
%       MBE - mass balance error (mm)
%
% CONTAINS: Internal functions e_sat(T) and dSdT(T) to calculate saturation
% vapor pressure and its temperature derivative.
%
% USES: External function boundary_layer_conductance (U,lt) from MicroMet
%
% Samuli Launiainen, METLA, 19.8.2013

import MicroMet.boundary_layer_conductance

%% Physical constants
    cp=29.3; % J/mol/K molar heat capacity of air at constant pressure
    L=44100; %J/mol latent heat of vaporization at 20 deg C
    Mw=18.0153e-3; % Molecular weight of water kg/mol
    b = 5.6697e-8; % W m-2 K-4 Stefan-Boltzmann const
    
%% parameters & canopy attributes
    z=CAN.z; % height vector(m)
    N=length(z); % number of layers
    dz=z(2)-z(1); % vertical increment (m). NOTE: Assumes constant dz!!!
    
    %ef=CAN.emi; %leaf emissivity for thermal radiation
    ef = 0.98; % assume wet leaves grey bodies
    %lt=CAN.lt; %Leaf length scale for aerodynamic resistance (m)
    lt=0.10; % equals needle length (m). NOTE: seems that lt order of 1 - 10 cm is appropriate for pine evaporation !
    PAI=CAN.lad.*dz; % plant area at each layer (m2/m2)
    Wmax=PAI.*CAN.Wmaxrain +eps; % Maximum liquid water storage at each layer (mm = kg/m2 - check units??) 
    
    F=1;    % Leaf orientation factor with respect to incident Prec; assumed to be 1 when Prec is in vertical, 
            %PAI one-sided and spherical leaf angle distribution
    
    %% initial conditions and state variables            

    Wo_init=CAN.W;  % initial water storage at each layer (mm = kg/m2)
    %this checks that water storage in a layer does not exist new capacity due PAI development
    df=1 - Wo_init./(Wmax);
    df(dz<0)=0;
    Wo_init(df<0)=Wmax(df<0);
    
    wfo=1-df; % initial wet fraction (-)
    Wo=Wo_init;
    
    dW=zeros(N,1); % change in water storage (mm)
    W=zeros(N,1); % new water storage (mm)
    
    P=ones(N,1).*eps; % Within-crown throughfall + condensation drip vector 
    P(N)=Prec; % at highest gridpoint equals precipitation rate through canopy crown (mm/s) 
    
    %% ************************** MAIN CALCULATION BLOCK *******************************************************************
    
    % solve wet leaf energy balance
    %for wet leaves assume only laminar forced convection
    [~,gb_v,gb_h,~]=boundary_layer_conductance (U,lt); % boundary layer conductances for heat and H2O, mol m-2 s-1 
    
    gr=4*ef*b*(T+273.15).^3/cp; % radiative conductance mol m-2 s-1, Campbell & Norman, 1998

    % solve for Tleaf (degC) from energy balance using Penman's linearization. ACCURATE APPROXIMATION IN TYPICAL CONDITIONS when
    % Tlear_w - Ta small as in wet canopies
    
    D=e_sat(T)./Pamb - H2O; % mol/mol    
    s = dSdT(T)./Pamb; % slope of vapor pressure curve at T, Pa/Pa = mol/mol
    Tleaf_w = T + (Rabs - L.*gb_v.*D)./(cp.*(gb_h + gr) + L.*s.*gb_v); % solve leaf temperature. Rabs is net SW - isothermal net LW on leaves (Wm-2)
    
    Dleaf_w=e_sat(Tleaf_w)/Pamb - H2O; % vapor pressure difference between leaf and air, mol/mol
    LEw=L*gb_v.*Dleaf_w; % evaporation/condensation rate as latent heat flux (Wm-2) per unit wet/dry leaf area
    Hw=cp*gb_h.*(Tleaf_w - T); % sensible heat flux (Wm-2) per unit wet leaf area
    Frw=cp*gr.*(Tleaf_w -T); %non-isothermal radiative flux (Wm-2)
    Ew=(LEw./L*Mw); %evaporation / condensation rate per unit leaf area (kg m-2 s-1 = mm s-1

    %% Canopy water storage & evaporation/condensation 
    %Tanaka, 2002 Ecol. Mod. 147, (eq 5 - 17) & Watanabe and Mizutani, 1996 Agric. For. Meteorol. 80, eq. 1 - 6)
    
    % wfo = wet fraction
    % 1-wfo = dry fraction
    % assume Tleaf and flux rates remain constant during dt
    
    % cumulative fluxes at each layer (mm)
    cIr=zeros(N,1);
    cE=zeros(N,1);
    cTrfall=zeros(N,1);
    cH=zeros(N,1); %Wm-2(wet leaf area)
    
    if Prec>0 || any(wfo>0) ||any(LEw<0)
        
        K=100; %number of subtimesteps
        subdt=dt/K; %sec

        for t=1:K, %time loop
            Ir=zeros(N,1); % interception rate vector
            P(1:N-1)=0; % set trfallrate to zero

            % calculate throughfall (and condensation drip) rates P (mm/s) at each height
                for n=N-1:-1:1 % start from highest gridpoint
                    if Ew(n)>=0 % evaporation

                        Ir(n)=F*(1 - wfo(n))*PAI(n)*P(n+1); %interception rate (mm/s)
                        P(n)=P(n+1) - Ir(n); % Throughfall rate at each layer (mm/s)
                        %(1-wfo(n))*PAI(n) is dry leaf area at layer n

                    else % condensation 
                        Ir(n) = F*(1 - wfo(n))*PAI(n)*P(n+1);% condensation term added directly to P - Ew(n)*PAI(n)*wfo(n);
                        P(n)=P(n+1) - Ir(n) - Ew(n)*PAI(n)*wfo(n); % Throughfall rate at each layer (mm/s)
                    end
                end

            % calculate liquid water storage change (dW, mm/PAI) and new water storage (W, mm/PAI):
            % assume P and E constant with time over subdt

            for n=N-1:-1:1 % start from highest gridpoint
                if Ew(n)>=0 % evaporation
                    dW(n)=( F*P(n)/(F*P(n) + Ew(n) +eps)*Wmax(n) -Wo(n))*(1 - exp(- (F*P(n)+Ew(n)).*PAI(n).*subdt/Wmax(n))); % dW(n) (mm)
                    W(n)=Wo(n) + dW(n); % updated water storage
                else % condensation
                    %dW(n)= (Wmax(n) - Wo(n))*(1 -exp(-(Ir(n))*subdt/Wmax(n))); %T�M� MUUTETTU 7.2.2014
                    dW(n)= (Wmax(n) - Wo(n))*(1 -exp(-(F*P(n)-Ew(n)).*PAI(n).*subdt/Wmax(n)));
                    W(n)=Wo(n) + dW(n);
                end
            end

            % update state variables:
            Wo=W; % new initial storage
            Wo(PAI==0)=0;
            %wfold=wfo;
            
            wfo=Wo./Wmax; % wet fraction
            %cumulative wet leaf fluxes
            %wfave=0.5*(wfold + wfo); clear wfold
            
            f=find(Ew>=0); %evaporation
            cE(f)=cE(f) + Ew(f).*wfo(f).*PAI(f)*subdt; %mm
            clear f
            f=find(Ew<0); %condensation
            cE(f)=cE(f) + Ew(f).*(1-wfo(f)).*PAI(f)*subdt; %mm
            clear f
            cH=cH + Hw.*wfo.*PAI*subdt; % sensible heat flux Wm-2
            
            cIr=cIr +Ir*subdt; % total interception at each layer (mm)
            cTrfall=cTrfall + P*subdt; % troughfall (mm)

        end % end of time loop   
    end % end if
    

    %return values at end of timestep
    
    
    df=1-wfo; % updated dry fraction (-)
    
    if all(df>0.99) % when all layers least 99% dry set canopy dry to speed up calculations
        df=ones(N,1); 
        Wo=zeros(N,1);
    end
    
    Trfall=max(0,cTrfall/dt); % throughfall + condensation drip rate (mm/s = kg/m2/s)
    LEwc=L*cE/dt/Mw; %Wm-2 (ground) 
    Hwc=cH/dt; %Wm-2 (ground)
    %MBE=sum(Wo) -sum(Wo_init) +sum(cE) - sum(cIr); % mass balance error (mm)
    
    %fluxes per unit wet leaf area
    flx.Rn=Rabs;
    flx.H=Hw;
    flx.LE=LEw;
    flx.Fr=Frw;
    
    %cumulative
    cum.Inter=cIr;
    cum.Evap=cE;
    cum.MBE=sum(Wo) -sum(Wo_init) +sum(cE) - sum(cIr); % mass balance error (mm)
    
%         sumP=Prec*dt
%         sumW=sum(Wo)
%         sumWo=sum(Wo_init)
%         sumE=sum(cE)
%         sumIn=sum(cIr)
      
%     figure(1)
%     
%     subplot(321); plot(Trfall_crown*dt, z,'r-'); title('Trfall')
%     subplot(322); plot(wfo, z,'r-'); title('dry fraction')
%     subplot(323); plot(Hw,z,'r-',LEw, z,'b-'); title('H & LE Wm-2 leaf')
%     subplot(324); plot(Hwc,z,'r-',LEwc, z,'b-'); title('H & LE Wm-2 ground')
%     subplot(325); plot(Tleaf_w,z,'r-',T, z,'b-'); title('T_w & T_a')
%     subplot(326); plot(cIr,z,'r-'); title('cIr')
%     if MBE~=0, pause; end
    %pause
    %% internal function definitions

    function [esat]=e_sat(T)
    % Saturation vapor pressure over water surface
        esat = 611.* exp((17.502.*T)./(T + 240.97)); %Pa
    end

    function ss = dSdT(T)
    % the slope of saturation vapor pressure curve, de_s(T)/dT [in units Pa K^-1]
    %INPUT: T - [degC]
    %OUTPUT: ss - [Pa K-1]
        esat = 611.* exp((17.502.*T)./(T + 240.97)); %Pa (Stull 1988)
        ss=17.502.*240.97.*esat./((240.97+T).^2); % [Pa K-1], from Baldocchi's Biometeorology -notes
    end


end   
    
