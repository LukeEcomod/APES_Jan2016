% Boundary layer conductance of bryophyte communities
% Rice et al. 2001. Functionl Significance of varition in bryophyte canopy
% structure. Amer. J. Bot. 88:1568-1576

% slope n (-), intercept c (-) and roughness height lt (m). Rice et al
% table 1.

%Mosses
n=[1.33 1.49 1.54 1.18 1.37 1.18 1.28 1.24 1.54];

c=[4.46 1.23 0.83 5.25 7.59 7.41 5.25 12.0 1.45]*1e-3;

lt=[.44 .21 .70 .50 1.18 .46 .30 .85 .51]*1e-2; %m

%%
rho=41.6;       %Density of air (mol/m3) at 20oC
mu=15.1e-6;     %Viscosity of air at 20oC [m2/s]

D_H=21.4e-6;    %Thermal diffusivity of air 20oC [m2/s]
D_c=15.7e-6;    %Molecular diffusivity of CO2 in air at 20oC [m2/s]
D_v=24.0e-6;     %Thermal diffusivity of water vapor in air at 20oC [m2/s]
D_O3=14.4e-6;   %Molecular diffusivity of O3 in air at 20 oC [m2/s]

Pr=mu/D_H;             %Prandtl number
%Re=lt*(U+eps)/mu;      %Reynolds number

Sc=mu/D_v; %Schmidt number for water vapor

figure(1)
clf

for U=0.01:0.01:4.6,
   Re=lt*(U+eps)/mu;      %Reynolds number
   
   %gb_v=10.^(-c).*Re.^n*D_v./lt*Sc^(1/3);
   gb_v=c.*Re.^n*D_v/lt*Sc^(1/3);
   Sh=gb_v.*lt/D_v;
   
   plot(log10(Re),log10(Sh.*Sc^(-1/3)),'ko'); hold on
end

title('Fig_1 Rice et al. 2008');
ylabel('log_{10} (ShSc^{-0.33})');
xlabel('log_{10} (Re_r)');
xlim([1.5 3.5]); ylim([-0.5 2.5]);

%% equation 1. parameteters
N=1.61; C=3.18;
lt=0.01
figure(2)
clf
figure(3)
clf
U=0.01:0.1:2;

for n=1:length(U),
    Re=lt*(U(n)+eps)/mu;      %Reynolds number
    %gb_v=10.^(-C).*Re.^N*D_v./lt*Sc^(1/3);
    
    gb_v(n)=10.^(-C).*Re.^N*D_v./lt*Sc^(1/3);
    Sh=gb_v(n).*lt/D_v; %sherwood number
    figure(2); plot(log10(Re),log10(Sh.*Sc^(-1/3)),'ro'); hold on
end
figure(2);

title('Fig_3 Rice et al. 2008: Eq.1');
ylabel('log_{10} (ShSc^{-0.33})');
xlabel('log_{10} (Re_r)');
xlim([1.8 4]); ylim([-2 3]);

figure(3);
plot(U,gb_v,'k-');
title('Bryophyte g_{b,v} (l_m=10 mm)');
ylabel('g_{b,v} (m/s)');
xlabel('U (m/s)');
%gb_v=exp(-C).*Re^N*D_v./lt*Sc^(1/3);
    