*****************************************

09.02.2015 Samuli Launiainen, Luke

*****************************************

@BryoType contains APES -model BryoType class definition file.

Class instances are used to compute water & heat balance and storages at bryophyte (moss) layer at the ground.
Contain functions to compute moss/lichen CO2-exchange etc.

 BryoType

  Properties:
                 Species: 'Feather moss'
    Switch_CapillaryRise: 'y'
                 f_cover: 1
                  height: 0.0300
                      lt: 0.0100
                     LAI: 1.0800
                    Mdry: 0.0600
             BulkDensity: 50
                     SLA: 180
                    Wmax: 10
                    Wmin: 1.5000
                      pF: [0.9700 0.0150 1.7200 1.2500 1.0000e-005 1.0000e-006 0.5000]
                porosity: 0.9700
                    Ksat: 1.0000e-006
               PhotoPara: [2x1 double]
                     Q10: 2
                     R10: 0.0200
                  PARalb: 0.0500
                  NIRalb: 0.4500
                     emi: 0.9800
                       T: 3
                       W: 10
                   Theta: 0.2786
                       h: -1
                     KLh: 2.3982e-007

  Methods

 APES -model component: 
 BryoType defines object for describing structural and functional
 properties and processes of moss/lichen (bryophytes) species / groups at the forest bottom layer. 
 
 
 CLASS METHODS: require class-instance to be run
    BryoEnergyH2Obalance - computes moss bulk temperature and moisture
    dynamics due soil-moss-atmosphere interactions using biophysical
    theories. 
    BryoCO2exchange - computes moss photosynthesis and respiration from
    state variables (T,hydration status) and near-surface Tair and PAR.
 
 STATIC METHODS: call as BryoType.functioname(params)
    km=OrganicMatterHeatConductivity(volwat, model) computes heat conductivities (Wm-1K-1)
    [gb_c,gb_v,gb_h]=Bryophyte_boundary_layer_conductance(U,Lr) (Rice et al. 2001)
    [g_c,g_v]=VaporConductancePorousMedia(Wliq,poros,depth,Ta,P, U)
    K=MossHydraulicConductivity(psi,Ksat), Lauren (1999), Table 4
    y = MossWaterRetention(x,pFpara,conv), converts between vol. water content (m3m-3) and pressure head (m)
 
 Author:
    Samuli Launiainen, Metla, 2011-2015.
 LAST UPDATE: 19.02.2015