    classdef BryoType
    %APES -model component: 
    %BryoType defines object for describing structural and functional
    %properties and processes of moss/lichen (bryophytes) species / groups at the forest bottom layer. 
    %
    %
    %CLASS METHODS: require class-instance to be run
    %   BryoEnergyH2Obalance - computes moss bulk temperature and moisture
    %   dynamics due soil-moss-atmosphere interactions using biophysical
    %   theories. 
    %   BryoCO2exchange - computes moss photosynthesis and respiration from
    %   state variables (T,hydration status) and near-surface Tair and PAR.
    %
    %STATIC METHODS: call as BryoType.functioname(params)
    %   km=OrganicMatterHeatConductivity(volwat, model) computes heat conductivities (Wm-1K-1)
    %   [gb_c,gb_v,gb_h]=Bryophyte_boundary_layer_conductance(U,Lr) (Rice et al. 2001)
    %   [g_c,g_v]=VaporConductancePorousMedia(Wliq,poros,depth,Ta,P, U)
    %   K=MossHydraulicConductivity(psi,Ksat), Lauren (1999), Table 4
    %   y = MossWaterRetention(x,pFpara,conv), converts between vol. water content (m3m-3) and pressure head (m)
    %
    %Author:
    %   Samuli Launiainen, Metla, 2011-2015.
    %LAST UPDATE: 19.02.2015

    properties (SetAccess = public, GetAccess = public)

        Species; %Species name string
        Switch_CapillaryRise='y'; %'y' enables capillary rise from soil, 'n' omits

        f_cover=1; % bryophyte cover, fraction of soil (-)
        height=0.05; % height of livingbryophyte layer (m)
        lt=0.01; % characteristic roughness height of moss layer (m)
        %zo; %bryophyte roughness length (m) (for using rb=log(z/z0)/(kv^2*U))

        LAI; % moss LAI (m2/m2)
        Mdry; % moss dry mass (kg/m2)
        BulkDensity; % bulk density of moss (kg/m3)
        SLA; % moss specific leaf area (g/m2)

        Wmax=10; % (g/g), maximum water retention capacity of moss layer (fresh / dry weight)     
        Wmin=1.5; % (g/g), minimum water retention capacity of moss layer (fresh / dry weight)

        %hydraulic properties
        pF; % parameters of pF-curve [ThetaS(m3/m3) ThetaR(m3/m3) alfa(-) n(-) compressibility(1/m) Kzsat(m/s)]
            % feather mosses: [0.97 0.015 1.72 1.25 1e-5 1.0e-6]; %pFcurve parameters: Lauren 1999 CT 32 o2[0.92 0.015 1.72 1.25 1e-5 4e-6 0.5]
            % sphagnum mosses: [0.95	0.10 0.34	1.4 1e-5 3.5e-4]% 'Rahkaturve pinta'
        porosity; % porosity (m3/m3)
        Ksat; % saturated hydr. conductivity (m/s). Sphagnum ~3.5e-4 m/s ~130 cm/h

        %photosynthesis and respiration
        PhotoPara; %[ Amax(umolm-2(leaf)s-1) light-saturated rate;  em (mol/mol) quantum efficiency on incident light basis]
        Q10; %respi sensitivity (-)
        R10; %base rate at 10degC (umolm-2(leaf)s-1)

        PARalb=0.05; % moss layer albedo (-)
        NIRalb=0.45; % moss layer albedo (-)
        emi=0.98; % emissivity (-);

        % state variables

        T; % moss temperature (degC)
        W; % moss layer relative water content (g/g), conversion to mm=kg/m2: Wbryo*Mbryo
        Theta; %moss vol. moisture content (m3m-3)
        h; % water potential (m)
        KLh; % conductivity of liquid water in live bryophytes (m/s)
    end

    methods
        function obj=BryoType(Species,BT,IniCond)

            obj.Species=Species;

            obj.f_cover=BT.f_cover;
            obj.height=BT.height;
            obj.lt=BT.lt;

            obj.LAI=BT.LAI;
            obj.Mdry=BT.Mdry;
            obj.BulkDensity=BT.BulkDensity;
            obj.SLA=BT.SLA;

            obj.Wmax=BT.Wmax;
            obj.Wmin=BT.Wmin;

            obj.pF=BT.pF;
            obj.porosity=BT.pF(1);
            obj.Ksat=BT.pF(6);

            obj.PhotoPara=BT.PhotoPara;
            obj.Q10=BT.Q10;
            obj.R10=BT.R10;

            obj.PARalb=BT.PARalb;
            obj.NIRalb=BT.NIRalb;
            obj.emi=BT.emi;


            %initial values
            obj.W=IniCond.W;
            obj.T=IniCond.T;
            FC=BryoType.MossWaterRetention(-1,obj.pF,1); % m3m-3
            obj.Theta=obj.W/obj.Wmax*FC; %m3m-3. Assumption here is that at FieldCapa W=Wmax
            clear FC
            obj.h=BryoType.MossWaterRetention(obj.Theta,obj.pF,2); %m
            obj.KLh = BryoType.MossHydraulicConductivity(obj.h,obj.Ksat); %m/s
        end

        function [Flx, Trfall, Statev]=BryoEnergyH2OBalance(obj,dt,Precmm,CapillaryRise,Ta,Tprec,Ts,kms,Qb1,Qd1,Qb2,Qd2,LWdn,U,H2O,P) 

        %Estimates energy and water balance for bryophyte species at the ground accounting for air-soil-moss interactions
        %
        %INPUT: 
        %       obj - ForestFloor -object.
        %       dt - timestep (s)
        %       Precmm - precipitation rate to moss layer (kg/(m2 s) = mm/s)
        %       Ta - air temperature (degC)
        %       Tprec - temperature of precipitating water (degC)
        %       CapillaryRise - liquid water capillary rise from soil (mm/s)
        %       Ts - soil surface temperature (degC)
        %       kms - conductance from moss to soil surface (W/(m2 K))
        %       Qb1 - incident direct beam PAR at forest floor (Wm-2)
        %       Qd1 - incident diffuse PAR at forest floor (Wm-2)
        %       Qb2 - incident direct beam NIR at forest floor (Wm-2)
        %       Qd2 - incident diffuse NIR at forest floor (Wm-2)
        %       LWdn - downwelling net radiation at surface (Wm-2)
        %       U - winds speed at reference height (m/s)
        %       H2O - H2O partial pressure in air (Pa=mol/mol)
        %       P - ambient pressure (Pa)
        %OUTPUT:
        %   Flx -structure with fields:
        %       Rn - net radiation balance
        %       LEb - latent heat flux (Wm-2)
        %       Hb - sensible heat flux rate (Wm-2)
        %       G - heat flux between soil and moss, negative towards soil (Wm-2)
        %       LWout - emitted LW rad (Wm-2)
        %       dW - change in water storage (kgm-2=mm)
        %       dQ - change in heat storage (Wm-2)
        %   Trfall - throughfall rate to soil (mm/s = kg/m2/s)
        %   Statev -structure with fields: (don't update here because APES_main is using iterative loops...)
        %       Tb - new moss temperature (degC)
        %       Wb - new water content of moss layer (g/g)
        %       psi_b - moss water potential (m)
        %       Theta_b - moss vol. water content (m3m-3)
        %
        % Samuli Launiainen, 2012-2015 (last update 11.02.2015)

            %% constants

            L=44100; %J/mol latent heat of vaporization at 20 deg C
            Mw=18.015e-3; % molar mass of water, kg mol-1
            cw=4.18e3; %specific heat of water (J/kg/K)
            cm=1.92e3; % specific heat of organic matter (J/kg/K)
            cp=29.3; % J/mol/K molar heat capacity of air at constant pressure
            StefBolz = 5.6697e-8; % W m-2 K-4 Stefan-Boltzmann const
            NT = 273.15; %K

            %% Local copies from obj-properties

            Mb=obj.Mdry; % moss layer dry biomass (kg/m2)
            emi_f=obj.emi; %emissivity
            %emi_f=eps;
            
            Wminb=obj.Wmin*Mb; %minimum water content kgm-2
            Wmaxb=obj.Wmax*Mb; %maximum water conten

            %% initial state after capillary rise and interception
            W0=obj.W*Mb; %kg m-2 initial water content of moss layer
            % update for capillary rise (restricted by free storage space) and interception
            W0=min(W0 + CapillaryRise*dt, Wmaxb); % kgm-2

            % Interception of liquid water
            %Ir=min([Precmm*dt*(1-exp(W0/Wmax-1)) Wmax-W0]); % interception (kg/m2), depends exponentially on the initial water content (Watanabe and Mizutani, 1996)
            Ir=max( 0,min([Precmm*dt Wmaxb-W0]) ); %interception kg/m2 is limited by precipitation rate or moss storage capacity

            Trfall=Precmm - Ir/dt; % mm/s =kg/m2/s throughfall rate to soil

            W0=W0+Ir; % intermediate water storage kgm-2
            C_old=cm.*Mb + cw*W0; %intermediate specific heat (J m-2 K-1) after capillary rise + interception

            Tb0=obj.T;
            Tb0=Tb0 + (cw*Ir*Tprec)/C_old; % account for heat advection with precipitation -->intermediate temperature (degC)
            %Qin=cw*Ir*Tprec % advected heat (Jm-2)


            %% Solve moss energy balance equation

            Rabs=(Qb1+Qd1)*(1-obj.PARalb) + (Qb2+Qd2)*(1-obj.NIRalb)+emi_f*LWdn; % absorbed all-wave radiation (Wm-2)

            % conductances
            [~,gb_v,gb_h]=BryoType.Bryophyte_boundary_layer_conductance(U,obj.lt); % bl cond. for H2O and heat (molm-2s-1)

            % relative evaporation rate as a function of water content. 
            %gm_rel=-1.5*(W0/Wmax)^2 + 2.44*(W0/Wmax); Rice (2012), Lindbergia (based on Pleurozium and Sphagnum data of Williams and Flanagan 1996, Oecologia)
            gm_rel=min(0.1285*W0/Mb -0.1285, 1.0); % Williams and Flanagan 1996, Oecologia. crosses 1 at ~ W/Mb=8.8
            
            gv=gb_v*gm_rel; % bulk water vapor conductance from moss tissue to air (molm-2s-1) 

            %% -------- Solve energy balance equation
            Emax=(W0 -Wminb)/dt; %maximum evaporation rate, kgm-2s-1 
            Emin=-(Wmaxb - W0)/dt; %maximum condensation rate, kgm-2s-1

            %solve set of ode's to obtain Tb and Wb: note this does not
            %allow sub-zero temperatures; should update to include phase changes
            options=odeset('NonNegative',2); %odeset('RelTol',1e-4,'AbsTol',[1e-4 1e-4 1e-5]);

            [~,Y] = ode15s(@MossEB,[0, dt],[Tb0, W0],options); %0.5*(Tb0+Ta)

            Tb=Y(end,1);
            Wb=Y(end,2);

            vpd=(611/P*exp(17.502*Tb./(Tb+240)) -H2O); %mol/mol

            %fluxes
            Flx.Rn=Rabs - emi_f*StefBolz*(Tb+NT).^4;
            Flx.LE=L*gv*vpd; %Wm-2
            Flx.H=cp*gb_h*(Tb-Ta);
            Flx.G=-kms*(Tb-Ts);
            Flx.LWout=emi_f*StefBolz*(Tb+NT).^4;
            Flx.dW=W0-Wb; %change in water storage (kgm-2=mm)
            Flx.dQ=((cm.*Mb + cw*Wb)*Tb - C_old*Tb0)/dt; %change in heat storage (Wm-2)
            Flx.Ir=Ir; %interception kg/m2

            %Compute state variables

            Wb=Wb/Mb; %fresh/dry mass g/g

            Theta_max=BryoType.MossWaterRetention(-obj.height,obj.pF,1);    % m3m-3, assume that when moss are at their maximum water retention capacity, their water potential is in hydrostatic equilibrium with soil surface 
                                                                            %(rationale is that also soil surface should be 'saturated, i.e. water potential ~= 0m' in these conditions)
                                                                            %
                                                                            % i.e. dh/dz +1 = (h_moss - 0) / moss height --> h_moss = - moss height
                                                            
            Theta_b=Wb/obj.Wmax*Theta_max; %m3m-3
            clear Theta_max
            Statev.psi_b=BryoType.MossWaterRetention(Theta_b,obj.pF,2); % matrix potential m
            Statev.Theta_b=Theta_b;
            Statev.Wb=Wb;
            Statev.Tb=Tb;
            
            function [dy]=MossEB(t,y)
                %defiens moss energy balance equation in suitable format for ode-solvers
                %t=time, y(1)=T(degC),y(2)=W(kgm-2)
                dy=zeros(2,1);

                dy(2)= -gv*(611/P*exp(17.502*y(1)/(y(1)+240)) -H2O)*Mw; %kgm-2s-1, evaporation <0
                dy(2) = min(max(dy(2),-Emax),-Emin); %kgm-2s-1, checks for E<Emax &E>Emin.

                dy(1)= ( Rabs - emi_f*StefBolz*(y(1)+NT).^4 - cp*gb_h*(y(1)-Ta) +L/Mw*dy(2) -kms*(y(1)-Ts) - cw*y(1)*dy(2) ) /(cm*Mb + cw*y(2));
            end


        end

        function [Ab,Rb]=BryoCO2exchange(obj,Q1)
            %calculates bryophyte photosynthesis (Ab,umolm-2s-1) and respiration (Rb,umolm-2s-1)
            %Photosynthesis is restricted by both tissue water content (dry cases) and excess water film on leaves (diffusion limitation) 
            %as in Williams and Flanagan (1996), Oecologia 108, 38-46.
            %INPUT: 
            %       obj -BryophyteLayer -object (contains properties & state variables)
            %       Q1 - incident PAR (dir + diffuse)(Wm-2)
            %
            %OUTP:  Ab - assimilation rate (umolm-2s-1), <0
            %       Rb - respiration rate (umolm-2s-1), >0
            %
            %Samuli Launiainen, 2011-2015 (last edit 11.02.2015)

            Q1=4.56*Q1; % conversion from Wm-2 to micromol m-2 s-1
            Q1(Q1<0)=0;

            wn=obj.W/obj.Wmax; % bryophyte normalized water content (relative to maximum capacity)
            Tb=obj.T; % bryophyte temperature

            %Photo model parameters
            Amax=obj.PhotoPara(1); %umolm-2(leaf)s-1
            em=obj.PhotoPara(2); %mol/mol

            Kd = 0.8; %radiation attenuation coeff. assumed diffuse    

            % empirical modifier of photosynthesis due to water content,assume that both light-limited and Rubisco limited assimilation are affected similarly
            % seems to apply both for Pleurozium and Sphagnum when wn=W/Wmax is used as scaling
            a=[6.4355  -14.0605    9.1867   -0.8720]; % coefficients of 3rd order polynomial fitted to the data of Williams and Flanagan (1996),Oecologia 108, 38-46.
            f1=max([0.05 (a(4) + a(3)*wn + a(2)*wn^2 + a(1)*wn^3)]); %always 5% capacity left

            %temperature modifier of Ab
            f2= -4.3e-5*Tb.^3 -8.3e-4*Tb.^2 +0.08*Tb +0.1; %Fit based on Fig. 2 'late growing season' in Frolking et al. 1996. Global Change Biology 1996, 2, 343-366
            f2=min(1,max(0.01,f2));

            % compute assimilation rate, divide local LAI to 10 equally deep layers.
            % f_cover<1 means that biomass is concentrated into patches and locally LAI can be high --> greater rad. attenuation
            LAIeff=obj.LAI/obj.f_cover; 
            dL=LAIeff/10; %LAI increment
            Lz=dL:dL:LAIeff; %cumulative LAI from top
            Q1z=Q1.*exp(-Kd.*Lz);

            %hyperbolic light response
            b=Amax/(2*em); 
            Ab=(Amax.*Q1z)./(b+Q1z)*f1*f2; % photosynthetic rate at each layer (umolm-2(leaf)s-1)

            %sum layerwise rates, <0 = uptake; scaling by f_cover returns average values at the site
            Ab=-dL*sum(Ab).*obj.f_cover; %umolm-2(ground)s-1
    
            % Respiration rate restricted by water content, fit is  based on Fig. 2 in Frolking et al. 1996. Global Change
            %Biology 1996, 2, 343-366 but so that x-axis is W=fresh mass while in Frolking it is water content (i.e. W-drymass)

            if obj.W<7,
                f3=-0.45 +0.4*obj.W -0.0273*obj.W.^2;
            else
                f3=-0.04*obj.W + 1.38;
            end

            f3=max(0.01, min(1,f3)); %ensure f3 in range 0.01 - 1.0 in all conditions

            Rb=obj.R10.*obj.Q10.^((Tb-10)./10)*f3; % umolm-2s-1

            % scale with leaf area and return
            Rb=obj.LAI.*Rb; %umolm-2(ground)s-1

        end

        function Fcapi=CapillaryRise(obj,dt,KLs,hs,zs)
            %estimates liquid water flux q=-k(dh/dz +1), (mm/s) to moss as capillary rise from underlying soil
            %INPUT:
            %   obj - Bryophyte-object
            %   dt - timestep (s)
            %   KLs - top soil liquid hydraulic conductivity (m/s)
            %   hs - top soil hydraulic head (m)
            %   zs - depth of 1st soil node (m)
            %OUT:
            %   Fcapi - liquid water flux due capillary rise: q=-k(dh/dz +1), (mm/s)  
            %NOTE:
            %   Multiply Fcapi by f_cover and add that to rootsink(1) for Soil_WaterFlow.


            Kbr=(obj.KLh*KLs)^0.5; % hydr. conductivity m/s, geom. average of soil and moss KL
            
            % liquid water flux (mm/s), only capillary rise is allowed: q=-k(dh/dz +1)
            Fcapi=1e3*max([0 ; -Kbr*((obj.h - hs)./(obj.height -zs)+1)]); %mm/s =kgm-2s-1: 19.06: removed factor 0.5 from bryophyte depth
            Fcapi=min([Fcapi; (obj.Wmax - obj.W)*obj.Mdry / dt]); % check limitation by moss storage space
            clear Kbr

        end

        function Es = SoilEvaporation_through_Moss(obj,Theta_b,T,H2O,U,P,Ts,hs,KLs,zs)
           % Computes soil evaporation through bryophytes; limited either by atm. demand & transport or soil supply. 
           % Vapor flow from soil to air must overcome two resistances in series: 
           %1 . molec. diffusion through porous living moss and then 2. from moss canopy to 1st calc. node in the atm; latter assumed equal to conductance from wet moss canopy
           %
           %INPUT:
           %    obj - bryophyte -object
           %    Theta_b - bryophyte vol. water content (due iteration doesn't use state variable)
           %    T - air temperature (degC)
           %    H2O - air H2O mixing ratio (mol/mol)
           %    U - wind speed (m/s)
           %    P - ambient pressure (Pa)
           %    Ts - top soil temperature (degC)
           %    hs - top soil hydraulic head (m)
           %    KLs - top soil liquid hydraulic conductivity (m/s)
           %    zs - depth of 1st soil node (<0), m
           %OUTPUT:
           %    Es - soil evaporation rate through moss (mol m-2(ground)s-1)
           %NOTE: multiply Es by obj.f_cover to obtain sink rate for Soil_WaterFlow
            
           %L_molar=44100; %J/mol latent heat of vaporization at 20 deg C
           Mwater=18.0153e-3; % Molecular weight of water kg/mol
           GasConst=8.314; % universal gas constant, Jmol-1

           [~,gvb]=BryoType.VaporConductancePorousMedia(Theta_b,obj.porosity, obj.height,T,P,U); %(mol m-2 s-1): "from soil surface to moss canopy height"
           [~,gav,~]=BryoType.Bryophyte_boundary_layer_conductance(U,obj.lt); %boundary layer conductance in mol m-2 s-1 for H2O from moss canopy to atm.
           geff=gvb*gav/(gvb + gav); %in series
           clear gav gbv

           %compute atm. evaporative demand (mol m-2 s-1)
           H2Osurf=BryoType.e_sat(Ts)/P; %mol/mol, assuming soil is saturated to calculate the maximum evaporation rate
           Edemand=geff.*(H2Osurf - H2O); % mol m-2 s-1
           clear H2Osurf

           %max E from 1st soil node limited by soil supply (mol m-2 s-1)
           RH=H2O*P/BryoType.e_sat(T); % air relative humidity (-) above ground
           h_atm=GasConst*(273.15+T).*log(RH)/(Mwater*9.81); % m, atm pressure head in equilibrium with atm. relative humidity

           Esupply=1000/Mwater*KLs*((h_atm - hs)/zs - 1); %mm/s(=kg/m2/s) / kg/mol = mol m-2 s-1 

           Es=min([Edemand Esupply]); %mol m-2 s-1
           clear Edemand Esupply RH h_atm
        end
    end


    %% ************* Static methods *******************    
    methods (Static)

        function [esat]=e_sat(T)
            % Saturation vapor pressure over water surface (Pa)
            % T in degC
            esat = 611.* exp((17.502.*T)./(T + 240.97)); %Pa
        end
        
        function km=OrganicMatterHeatConductivity(volwat, model)
            %function km=OrganicMatterHeatConductivity(volwat, model) computes heat conductivity (W m-1 K-1)in organic matter.
            %
            %INPUT: 
            %   volwat - volumetric water content (m3m-3), 
            %   model - 1=O'Donnell et al. 2009; 2=Campbell, 1985; 3=constant value (dry organic matter); 4=Lauren 1999 Table 4 (boreal mor) 
            %OUTPUT: 
            %   km - thermal conductivity (Wm-1K-1)


            if model ==1,
                % O'Donnell et al, 2009 Soil Sci. 174. 
                km=min([0.6 (3e-2 + 5e-1*volwat)]); % %moss/litter heat conductivity (W/m/K)
                km=max([4e-2 km]);
            end
            if model == 2,
                % Campbell, 1985: Soil physics with basic
                A=0.4; B=0.5; C=1; D=0.06; E=4; % constants for forest litter

                km= A + B*volwat - (A-D).*exp(-(C.*volwat).^E); % W/m/K
                km=min([0.6 km]);
            end
            if model ==3
                %constant value
                km = 0.25; % W/m/K
            end
            if model ==4
                % Laur�n 1999 Table 4 for boreal mor
                km = -0.004 + 0.609*volwat;
                %if volwat>0.5, km=-0.004 + 0.609*0.5; end 
                %if volwat<0.1, km=-0.004 + 0.609*0.1; end 
            end
        end

        function [gb_c,gb_v,gb_h]=Bryophyte_boundary_layer_conductance(U,Lr)
            % Computes boundary layer conductance of bryophyte canopy 
            %
            % INPUT: 
            %   U - wind speed (m/s), should represent U at ca. 20cm above moss canopy (wind-tunnel studies)
            %   Lr - roughness lengths scale (m) equaling to the "characteristic vertical height of individual bryophyte shoots", typically order of 3-10 mm
            % OUTPUT: 
            %   boundary layer conductances foc CO2, H2O and heat (molm-2s-1).
            % REFERENCE:
            %   Rice et al. 2001: Significance of variation in bryophyte canopy structure. Amer. J. Bot. 88:1568-1576
            %   Rice, 2006: Towards an Integrated unterstanding of Bryophyte performance: the dimensions of space and time. Lindbergia 31, 42-53.

            %constants
            rho=41.6;       %Density of air (mol/m3) at 20oC
            mu=15.1e-6;     %Viscosity of air at 20oC [m2/s]
            D_H=21.4e-6;    %Thermal diffusivity of air 20oC [m2/s]
            D_c=15.7e-6;    %Molecular diffusivity of CO2 in air at 20oC [m2/s]
            D_v=24.0e-6;     %Thermal diffusivity of water vapor in air at 20oC [m2/s]       

            Sc_v=mu/D_v; %Schmidt number for water vapor
            Re=U*Lr/mu; % Reynolds number

            gb_v=rho*10^(-3.18).*Re.^1.61*D_v/Lr*Sc_v^(1/3); % Rice et al. global equation (eq.1)
            %gb_v=0.5*gb_v; % decrease by factor of 2 due to sheltering effect when moss carpet is continuous (Rice 2006, Lindbergia, 31 :42-53)
                                                             % omit here since 'effective' conductances are likely be higher than those based on mean U
                                                                % ('intermittent turbulence; sweep/ejection -cycle)

            % assume CO2 and heat conductances are related to water vapor by
            % the ratio of molecular diffusivities (Campbell & Norman 1998, eq. 7.29 - 7.33)
            gb_c=D_c/D_v*gb_v;
            gb_h=D_H/D_v*gb_v;

            %stability correction based on daamend & simmonds (1996), accounted here only in unstable conditions
            %     %dT=0;
            %     stabfact=1;
            %     if dT>0, stabfact= 1./(1+ 5*9.81*z*(dT)/((Ta+273.15)*U^2)).^-0.75; end
            %     if dT<0, stabfact= 0.5./(1+ 5*9.81*z*(-dT)/((Ta+273.15)*U^2)).^-0.75; end
            %     gb_v=gb_v*stabfact;
        end

    % ***********************************************************************        
        function y = MossWaterRetention(x,pFpara,conv)
            % Converts between hydraulic parameters Theta (m3/m3) <--> head (m)
            % INPUT:    x - matrix potential (m) OR Theta (m3/m3)
            %           pFpara - parameters of pF-curve: [Th_sat Th_res alpha n]
            %           conv - 1 if head --> Theta, 2 if Theta -->head
            % OUTPUT:   y - Theta or matrix potential

            %pF-curve
            Ws=pFpara(1);
            Wr=pFpara(2);
            alfa=pFpara(3);
            n=pFpara(4);
            m=1 - 1/n; 

            if conv==1, %From potential to Theta
                x=100*x; % cm 
                if x<0,
                    y= max([Wr + (Ws - Wr)/(1 + (-alfa*x)^n)^m; Wr]);
                else
                    y=Ws;
                end
                y=min(Ws,y);
                y=max(Wr,y);
            end

            if conv==2, %From Theta to potential
                if x>Ws, x=Ws; end
                if x<=Wr, x=Wr + eps; end

                R=((Ws - Wr)/(x - Wr))^(1./m);
                y = 1e-2*(-1./alfa*(R-1)^(1/n)); %m

                y(y<-10000)=-10000;
            end
        end           

        function K=MossHydraulicConductivity(psi,Ksat)
            %estimates boreal moss hydraulic conductivity 
            %based on Lauren 1999 Table 4
            % INPUT: psi - matrix potential in m
            %        Ksat - saturated conductivity (m/s)
            % OUTPUT: K - hydraulic conductivity m/s

            psi=-10*psi; %kPa
            %parameterization is valid between -4 ... -80 kPa
            psi(psi<4)=4; %
            %psi(psi>120)=120; %

            f=10.^(1./(-0.62 + 0.26.*log10(psi)))/10^(1/(-0.62 + 0.26*log10(4))); % relative conductivity to 4kPa 
            f(psi>80)=0; %assume in dry conditions no conductivity.
            K=Ksat*f; %m/s

            %K=max(1e-15,K); %ensure positive hydr. conductivity.
        end
    % ***********************************************************************
        function [g_c,g_v]=VaporConductancePorousMedia(Wliq,poros,depth,Ta,P, U)
            % Returns molecular conductance of CO2 (g_c) and H2O (g_v) in porous
            % media [mol m-2 s-1]
            % Assumptions:
            % 1) all gas exchange is due molecular diffusion
            % 2) relative diffusivity in soil to that of air D/Do is by Millington & Quirk (1961)
            %
            % INPUT:
            %   Wliq - vol. water content (m3m-3)
            %   poros - porosity (-)
            %   depth - distance for transport (m)
            %   Ta - temperature (degC)
            %   P - pressure (Pa)
            %   U - wind speed (m/s), for convective adjustment

            Ta=Ta+273.15;
            Wair=max(0,poros-Wliq);
            D_c=15.7e-6;    %Molecular diffusivity of CO2 in air at 20oC [m2/s]
            D_v=24.0e-6;     %Molecular diffusivity of water vapor in air at 20oC [m2/s]
            GasConst=8.3143; % J mol-1 K-1

            % P/(GasConst*Ta) = mol m-3, converts m/s to mol m-2 s-1        
            Drel=(Ta/273.15)^1.75.*Wair.^(10/3)./poros.^2; %D/Do, Millington & Quirk (1961)

            g_c = P./ (GasConst*Ta)*D_c.*Drel/depth; %mol m-2 s-1, CO2
            g_v = P./ (GasConst*Ta)*D_v.*Drel/depth; %mol m-2 s-1, H2O

    %             %These are from Hillel
    %             g_c= P/(GasConst*(Ta+273.15))*D_c*0.66*poros/depth %mol m-2 s-1, CO2
    %             g_v=P/(GasConst*(Ta+273.15))*D_v*0.66*poros/depth %mol m-2 s-1, H2O

            % modified from Wilson et al. 2012 (AFM 161, p.131-147)
            % term (1 + 4.*U) takes account impact of wind speed in porous media at ground, Wilson et al. 2012. They refer to Norman & Campbell, 1983  
            %g_c = P/(GasConst*(Ta+273.15)) * D_c*(1 + 4.*U)/depth; %mol m-2 s-1, CO2
            %g_v = P/(GasConst*(Ta+273.15)) * D_v*(1 + 4.*U)/depth; %mol m-2 s-1, H2O

        end

    %% *********************************************************
        function [gb_c,gb_v,gb_h]=Soil_boundarylayer_conductance(z,zo,U,To,Ta)
            %Computes soil surface aerodynamic conductance (mol m-2 s-1) following Daamond & Simmons (1996)

            D_H=21.4e-6;    %Thermal diffusivity of air 20oC [m2/s]
            D_c=15.7e-6;    %Molecular diffusivity of CO2 in air at 20oC [m2/s]
            D_v=24.0e-6;     %Thermal diffusivity of water vapor in air at 20oC [m2/s]  

            rhoa=1013e2./(8.31*(Ta+273.15)); %mol m-3

            delta=5*9.81*z*(To-Ta)/((Ta+273.15)*U^2);
            if delta>0,
                d=-0.75;
            else
                d=-2;
            end
            rb=(log(z/zo))^2./(0.4^2.*U).*(1+delta).^d;
            gb_h=rhoa.*1/rb; %heat, mol m-2 s-1
            gb_v=D_v/D_H*gb_h; %water vapor
            gb_c=D_c/D_H*gb_h; %CO2

        end
    end

    end



