function [LWnet,LWleaf,LWup,LWdn] = CanopyLWRad(Lz,CLUMP,T,LWdn0,LWup0)
%
% Estimates long-wave radiation budget and net isothermal LW radiation within the canopy
% Assumes canopy elements as black bodies (es=1.0) at local air temperature
% T(z). Neglects scattering etc.
%
% INPUT: 
%   Lz - 1-sided LAI in each layer (m2m2(ground))
%   CLUMP - clumping factor (-), [0...1]
%   T: air temperature (degC)
%   LWdn0 - downwelling LW above uppermost gridpoint (Wm-2(ground)). LWdn0=eatm*b*Tatm^4
%   LWup0 - upwelling LW at surface (Wm-2(ground)). LWup0=esurf*b*Tsurf^4
% OUTPUT:
%   LWnet - net isothermal long-wave radiation Wm-2 (ground)
%   LWleaf - net isothermal long-wave absorbed by leaf (Wm-2 (leaf))
%   LWup - upwelling LW (Wm-2)
%   LWdn - downwelling LW (Wm-2)
%
% SOURCE:
%   Modified from Flerchinger et al. 2009. Simulation of within-canopy radiation exchange, NJAS 57, 5-15.
%   Assumes Tcan(z) = T(z) and neglects scattering (canopy elements black bodies)
%
% Samuli Launiainen (Luke). Last edit: 23.02.2015


%% check inputs
if any(T)<200, T=T+273.15; end %K

%% defining constants
b=5.6697e-8; %Stefan-Boltzman constant W m-2 K-4
es=1; %leaf emissivity


N=length(T); % Node 1 = ground, N=top
LWdn=zeros(N,1);
LWup=zeros(N,1);

LayerLAI=CLUMP*Lz; %plant-area m2m-2 in a layer addjusted for clumping
canopytop=find(LayerLAI>0, 1, 'last' ); % node at canopy top

%layerwise attenuation coeffcints
Kd=0.7815; % diffuse radiation, Flearchinger et al. 2009 NJAS
Tau=exp(-Kd.*LayerLAI);

% LW down
LWdn(canopytop+1:N)=LWdn0; %top layer
for k=canopytop:-1:1,
    LWdn(k)=Tau(k)*LWdn(k+1) +(1-Tau(k))*(es*b*T(k).^4);
end
clear k

% LW up
LWup(1)=LWup0;
for k=2:1:canopytop,
    LWup(k)=Tau(k)*LWup(k-1) + (1-Tau(k))*(es*b*T(k).^4);
end
clear k
LWup(canopytop+1:N)=LWup(canopytop);

%net isothermal LW per unit ground area (Wm-2)
LWnet=LWdn - LWup; 

%absorbed isothermal net radiation by the leaf (Wm-2(leaf))
LWleaf=Kd*(1-Tau).*es.*(LWdn + LWup - 2*b*T.^4)./(LayerLAI/CLUMP+eps); % isothermal net radiation on leaf
%Kd is mean projection of leaves 

