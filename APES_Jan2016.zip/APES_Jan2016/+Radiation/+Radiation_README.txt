**************************************************

Samuli Launiainen (Luke) 23.2.2015
samuli.launiainen@luke.fi

**************************************************

package '+Radiation' contains Matlab functions for computing solar and long-wave radiation within
and above plant canopies. See respective function for documentation and INPUTS / OUTPUTS.

Language: Matlab; most functions I have also in Python; its quite easy to convert.

CanopySWRad_ZhaoQualls: 
	computes short-wave radiation transfer within 1-d (homogenous porous media) vegetation canopy. 
	includes separate treatment of incoming direct and diffuse SW, and multiple-scattering within canopy.
	Optical parameters and 'clumping' of leaf-area are given as effective leaf or shoot (conifer) value.
	Zhao & Qualls, 2005. Water Respources Res. 41, W08409, doi:10.1029/2005WR004016, 2005.

CanopyLWRad_ZhaoQualls: 
	computes long-wave radiation transfer within 1-d (homogenous porous media) vegetation canopy. 
	includes separate treatment of incoming (downwelling) LW from the sky, and that emited from the canopy elements and soil.
	accounts for multiple scattering although its importance is small since leaves are near black bodies.
	Optical parameters and 'clumping' of leaf-area are given as effective leaf or shoot (conifer) values.
	Zhao & Qualls, 2006. WATER RESOURCES RESEARCH, VOL. 42, W08436, doi:10.1029/2005WR004581, 2006

CanopyLWRad_Spitters1968:
	computes short-wave radiation transfer within 1-d (homogenous porous media) vegetation canopy. 
	Analytical treatment of incoming direct and diffuse SW, and simplified scheme for multiple-scattering within canopy.
	Optical parameters and 'clumping' of leaf-area are given as effective leaf or shoot (conifer) value.
	Works ok for PAR but less well for NIR.
	Spitters, 1996. Agric. For. Meteorol. 38, 231-242.
	
CanopyLWRad :
	computes long-wave radiation transfer within 1-d (homogenous porous media) vegetation canopy. 
	includes separate treatment of incoming (downwelling) LW from the sky, and that emited from the canopy elements
	assuming them black bodies (i.e. emissivity == 1.0).
	Reference: S. Launiainen; simplified from several papers.

Compute_Clouds_Rad:
	Estimates cloud cover fraction, fraction of diffuse to total global radiation and atmospheric emissivity
	from surface observations (incoming global radiation, atmospheric water vapor pressure at surface level) and location
	(LAT, LON, doy).
	References: Campbell & Norman, 1998, Springer; Maykut and Church (1973), Niemelä et al., Song et al., 2009. J. Geophys. Res.

ComputeDiffuseFraction:
	Estimates ratio of diffuse-to-total global radiation at surface based on Doy, Lat, Lon and incoming total Global radiation.
	Spitters et al., 1986. Agric. For. Met. 38, 217-229.

BeamExtCoeff:
	Computes extinction coefficient for direct (beam) radiation to be used in Beer's law-type models.
	Campbell and Norman, 1998, Springer

ExtDiff
	Computes extinction coefficient for diffuse radiation to be used in Beer's law-type models.
	Campbell and Norman, 1998, Springer
	
