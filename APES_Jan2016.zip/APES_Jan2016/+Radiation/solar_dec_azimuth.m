function [ZEN, AZIM,dd,Lday]=solar_dec_azimuth(DOY, LAT1, LON1, tm)
% function[ZEN, AZIM, dd, Lday]=solar_dec_azimuth.m computes the solar zenith
% angle (ZEN), azimuth angle (AZIM) and declination angle (dd)
% from DOY, LAT (+ northern), longitude (+ east from Greenwich) and time of day
%
%INPUT:
%   DOY: day of year
%   LAT1: latitude (+ northern)
%   LON1: longitude (+eastern)
%   tm -decimal time of day, e.g. 13:45=13.75
%OUT:
%   ZEN: solar zenith angle (rad)
%   AZIM: solar adimuth angle (rad)
%   dd: solar declination angle
%   Lday: day length (hours)
%
%SOURCE:
%   Campbell & Norman, 1998: Introduction to environmental biophysics, Springer.
%
%Samuli Launiainen, Luke. Last edit 23.2.2015


    CF=pi/180; % conversion deg -->rad
    LAT=LAT1*CF;
    LON=LON1*CF;

    % ---> compute declination angle
    xx=278.97+0.9856*DOY+1.9165*sin((356.6+0.9856*DOY)*CF);
    dd=asin(0.39785*sin(xx*CF));

    % ---> compute Zenith angle
    LC=1/15*LON; % longitude correction, hours
    f=(279.575+0.9856*DOY)*CF;
    ET=(-104.7*sin(f)+596.2*sin(2*f)+4.3*sin(3*f)-12.7*sin(4*f)-429.3*cos(f)-2*cos(2*f)+19.3*cos(3*f))/3600;

    to=12-LC-ET; % local solar noon
    aa=sin(LAT)*sin(dd)+(cos(LAT))*cos(dd)*cos(15*(tm-to)*CF);
    ZEN=acos(aa);

    % ---> compute azimuth angle
    AZIM=acos(-(sin(dd)-(sin(LAT)).*cos(ZEN))./((cos(LAT)).*sin(ZEN)));
    
    %---> compute daylength
    aa=cos(pi/2); %sunrise, ZEN=90deg
    hs=acos( (aa -sin(LAT)*sin(dd)) / (cos(LAT)*cos(dd)) );
    
    Lday=2*hs/15; %in hours
end