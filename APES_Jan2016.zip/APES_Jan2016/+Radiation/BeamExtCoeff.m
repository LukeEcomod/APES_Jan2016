function Kb=BeamExtCoeff(x, ZEN)
% Define black leaf extinction coefficients for direct beam and diffuse radiation
% Model from Campbell & Norman, eq. 15.4
%IN:
%   x - leaf angle distribution parameter
%   ZEN - solar zenith angle (raf)
%OUT:
%   Kb - black leaf beam extiction coeffiecient (-)

XN1=(sqrt(x.*x+(tan(ZEN))^2));
XD1=(x+1.774*(x+1.182)^(-0.733));
Kb=XN1/XD1; % direct beam

Kb=min([50 Kb]);
if Kb<0,Kb=50; end
clear XN1 XD1