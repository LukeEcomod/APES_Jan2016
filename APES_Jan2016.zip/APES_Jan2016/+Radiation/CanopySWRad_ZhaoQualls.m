function [Q_sl,Q_sh, q_sl, q_sh, q_soil, f_sl, SWbo, SWdo, SWuo, alb] = CanopySWRad_ZhaoQualls(LAIz,CLUMP,leaf_angle_para,ZEN,IbSky,IdSky,leaf_albedo,soil_albedo)
% Estimates incident and absorbed SW radiation within plant canopies.
% Includes multiple scattering among the canopy layers and soil surface.
% Within-shoot scattering is included through effective leaf_albedo < leaf
% single-scattering albedo.
%
% Returns incident and absorbed SW separately for sunlit (sl) and shaded (sh) leaves.
%
% INPUT:
%   LAIz: leaf-area index per layer (m2(leaf) m-2(ground)), Nx1-array.
%   CLUMP: element clumping index (-), [ 0> CLUMP <=1], scalar
%   leaf_angle_para: leaf-angle distribution parameter (-), scalar: 1=spherical, 0=vertical, 'inf'=horizontal
%   ZEN: solar zenith angle (rad),scalar
%   IbSky: incident beam radiation above canopy (Wm-2),scalar
%   IdSky: downwelling diffuse radiation above canopy (Wm-2),scalar
%   leaf_albedo for considered waveband(-),scalar
%   soil_albedo for considered waveband(-),scalar
%
% OUTPUT:
%   Q_sl: incident SW at sunlit leaves (Wm-2(leaf))
%   Q_sh: incident SW at shaded leaves (Wm-2(leaf))
%   q_sl: absorbed SW by sunlit leaves (Wm-2(leaf))
%   q_sh: absorbed SW by shaded leaves (Wm-2(leaf))
%   q_soil: absorbed SW by soil surface (Wm-2(ground))
%   f_sl: Fraction of sunlit leaves (dimensionless)
%   SWbo: direct downward SW at z (Wm-2(ground))
%   SWdo: diffuse downward SW at z (Wm-2(ground))
%   SWuo: diffuse upward SW at z (Wm-2(ground))
%   alb: canopy albedo (-)
%
%
% CONTAINS:
%   1 internal function (ExtDiff)
%
% REFERENCES:
%   Zhao & Qualls, 2005 Water Resources Research. Multi-layer Multiple scattering model
%   Estimates SW attenuation inc. multiple scattering within the canopy.
%   Campbell & Norman (1998): An introduction to environmental biophysics.
%   Spitters, (1986): Separating the diffuse and direct component of global
%   radiation and its implications for modeling canopy photosynthesis part
%   II: Calculation of canopy photosynthesis. Agric. For. Meteorol. 38, 231-242.
%   Wang & Leuning (1998): A two-leaf model for canopy conductance, photosynthesis and partitioning of
%   available energy I: Model description and comparison with a multi-layered model. Agric. For. Meteorol. 91, 89-111.
%   Juang, Katul et al. 2008: Investigating a hierarchy of Eulerian Closure Models for Scalar Transfer Inside Forested Canopies. BLM 128:1-32.
%
% Samuli Launiainen (METLA) 2013-2015
%
% LAST EDIT: 23.02.2015


%% check inputs

if IbSky<0,IbSky=0; end
if IdSky<0,IdSky=0; end

% parameters
N=length(LAIz); %layers in original grid
M=max(100,N); % number of layers in the canopy % NOTE: needs to be larger or equal to length(LAIz)

x=leaf_angle_para; % x=1 (spherical), x=0 (vertical), x='inf' (very large) (horizontal) leaf-area distribution. See Campbell&Norman,1998.Introduction to Env. Biophysics

leaf_absorptivity=(1-leaf_albedo); % leaf absorptivity
% transmittance and reflection ratios are based on Zano & Qualls (2005); see Lukes et al. 2013 for Scots pine values at SMEAR II
leaf_transm_coeff=0.4; % leaf transmission coefficient as fraction of scattered radiation
leaf_refl_coeff=0.6; % leaf reflection coefficient as fraction of scattered radiation

aL=ones(M,1)*leaf_absorptivity; % absorptivity
tL=ones(M,1)*leaf_transm_coeff; % transmission coefficient
rL=ones(M,1)*leaf_refl_coeff; % reflection coefficient

%original and computational grid
PAI=CLUMP*sum(LAIz);  %total canopy plant area index corrected for clumping (m2 m-2)
PAIo=CLUMP*LAIz; %effective layerwise LAI (or PAI) in original grid

Lo=cumsum(flipud(PAIo)); %cumulative plant area index from canopy top
Lo=flipud(Lo); % node 1 is canopy bottom, N is top

% L vector to the radiation calculations need to be equally spaced
L(1:M,1)=PAI/M; % plant area index (m2m-2 in a layer

Lcum=cumsum(L); %cumulative PAI from canopy top
Lcum=flipud(Lcum);

%% Define black leaf extinction coefficients for direct beam and diffuse radiation
% Model from Campbell & Norman, eq. 15.4

XN1=(sqrt(x*x+(tan(ZEN))^2));
XD1=(x+1.774*(x+1.182)^(-0.733));
Kb=XN1/XD1; % direct beam

Kb=min([50 Kb]);
if Kb<0,Kb=50; end
clear XN1 XD1

% diffuse
Kd=ExtDiff(x, PAI); %

% % fraction of sunlit & shaded leaves in a layer
%
% f_sl=exp(-Kb.*Lcum); %sunlit fraction at each layer

% beam radiation at each layer
Ib=exp(-Kb.*Lcum)*IbSky;

% propability of contact with canopy elements in each layer, for direct and diffuse radiation
taub=exp(-Kb.*L); % beam
taud=exp(-Kd.*L); %diffuse

%backward-scattering functions (eq. 22-23)
rb=0.5 + 0.3334.*(rL-tL)./(rL+tL).*cos(ZEN); % beam
rd=2/3.*rL./(rL+tL) + 1/3*tL./(rL+tL); % diffuse

%% set up tridiagonal matrix A and solve SW from A*SW=C
%Zhao & Qualls, 2006. eq. 39 & 42.
%
%Solve SW from A*SW=C
%
%layer 1 is soil surface, 2 is lowest canopy layer
%layer M+1 is topmost canopy layer and M+2 is upper boundary (sky)

%soil BC (M=1)
aL0=1-soil_albedo; %soil absorptivity
%rd0=1; %reflection coefficient for diffuse
%rb0=1; %reflection coefficient for beam
taud0=0; % soil transmissivities
%taub0=0;

%atm BC (M=M+2)
aLSky=0; %absorptivity
taudSky=1; %transmissivities
%taubSky=1;
rdSky=0; %reflection coefficients are zero
%rbSky=0;


%A = coefficient matrix
A=zeros(2*M+2, 2*M+2);

A(1,1)=1; %soil

%k=1 accounts soil

A(2,1) = - ( taud(2) + (1-taud(2))*(1-aL(2))*(1-rd(2)) );
A(2,2) = -1*(taud(2) + (1-taud(2))*(1-aL(2))*(1-rd(2)))*(1-aL0);
A(2,3) = ( 1 - 1*rd(2)*(1-aL0)*1*(1-aL(2))*(1-taud(2)) );

A(3,2) = ( 1 - rd(3)*rd(4)*(1-aL(3))*(1-taud(3))*(1-aL(4))*(1-taud(4)) );
A(3,3) = -rd(4)*( taud(3) + (1-taud(3))*(1-aL(3))*(1-rd(3)) )* (1-aL(4))*(1-taud(4));
A(3,4) = -( taud(3) + (1-taud(3))*(1-aL(3))*(1-rd(3)) );

for k=2:M-1,
    A(2*k,2*k-1) = - ( taud(k) + (1-taud(k))*(1-aL(k))*(1-rd(k)) );
    A(2*k,2*k) = -rd(k-1)*(taud(k) + (1-taud(k))*(1-aL(k))*(1-rd(k)))*(1-aL(k-1))*(1-taud(k-1));
    A(2*k,2*k+1) = ( 1 - rd(k-1)*rd(k)*(1-aL(k-1))*(1-taud(k-1))*(1-aL(k))*(1-taud(k)) );
    
    A(2*k+1,2*k) = ( 1 - rd(k)*rd(k+1)*(1-aL(k))*(1-taud(k))*(1-aL(k+1))*(1-taud(k+1)) );
    A(2*k+1,2*k+1) = -rd(k+1)*( taud(k) + (1-taud(k))*(1-aL(k))*(1-rd(k)) )* (1-aL(k+1))*(1-taud(k+1));
    A(2*k+1,2*k+2) = -( taud(k) + (1-taud(k))*(1-aL(k))*(1-rd(k)) );
end
clear k;

%uppermost nodes

A(2*M,2*M-1) = - ( taud(M) + (1-taud(M))*(1-aL(M))*(1-rd(M)) );
A(2*M,2*M) = -rd(M-1)*(taud(M) + (1-taud(M))*(1-aL(M))*(1-rd(M)))*(1-aL(M-1))*(1-taud(M-1));
A(2*M,2*M+1) = (1 - rd(M-1)*rd(M)*(1-aL(M-1))*(1-taud(M-1))*(1-aL(M))*(1-taud(M)));

% A(2*M+1,2*M) = ( 1 - rd(M)*rdA*(1-aL(M))*(1-taud(M))*(1-aLSky)*(1-taudSky) );
% A(2*M+1,2*M+1) = -rdSky*( taud(M) + (1-taud(M))*(1-aL(M))*(1-rd(M)) )* (1-aLSky)*(1-taudSky);
% A(2*M+1,2*M+2) = -( taud(M) + (1-taud(M))*(1-aL(M))*(1-rd(M)) );
% A(2*M+2,2*M+2)=1;

%commented rows up reduce to
A(2*M+1,2*M) = 1;
A(2*M+1,2*M+1) = 0;
A(2*M+1,2*M+2) = -( taud(M) + (1-taud(M))*(1-aL(M))*(1-rd(M)) );
A(2*M+2,2*M+2)=1;

% RHS vector C
C=zeros(2*M+2,1);
C(1)=soil_albedo*Ib(1);
%k=1
C(2) = ( 1 - 1*rd(1)*(1-aL0)*(1-taud0)*(1-aL(1))*(1-taud(1)) )*rb(1)*(1-taub(1))*(1-aL(1))*Ib(2);
C(3) = ( 1 - rd(1)*rd(2)*(1-aL(1))*(1-taud(1))*(1-aL(2))*(1-taud(2)) )*(1-taub(1))*(1-aL(1))*(1-rb(1))*Ib(2);
n=4; % dummy variable
for k=2:M-1,
    C(n) = ( 1 - rd(k-1)*rd(k)*(1-aL(k-1))*(1-taud(k-1))*(1-aL(k))*(1-taud(k)) )*rb(k)*(1-taub(k))*(1-aL(k))*Ib(k+1);
    C(n+1) = ( 1 - rd(k)*rd(k+1)*(1-aL(k))*(1-taud(k))*(1-aL(k+1))*(1-taud(k+1)) )*(1-taub(k))*(1-aL(k))*(1-rb(k))*Ib(k+1); %here Ib(k+1) instead of Ib(k); we need Ib entering the layer
    n=n+2;
end
C(n) = ( 1 - rd(M-1)*rd(M)*(1-aL(M-1))*(1-taud(M-1))*(1-aL(M))*(1-taud(M)) )*rb(M)*(1-taub(M))*(1-aL(M))*IbSky;
%C(n+1) = ( 1 - rd(M)*rdSky*(1-aL(M))*(1-taud(M))*(1-aLSky)*(1-taudSky))*(1-taubSky)*(1-aL(M))*(1-rb(M))*Ib(M); %reduces to
C(n+1) = 0;
C(n+2)=IdSky;
clear n

% solve A*SW=C;
SW=A\C;

SWu0=SW(1:2:2*M+1); %upward hemispherical radiation (Wm-2 ground)
SWd0=SW(2:2:2*M+2); %downward hemispherical radiation (Wm-2 ground)

%% calculate multiple scattering, Zhao & Qualls, 2005. eq. 24 & 25.

% downwelling diffuse after multiple scattering, eq. 24
SWd=zeros(M+1,1);
for k=M-1:-1:1, % from layer k+1 to layer k
    
    X = SWd0(k+1) / (1 - rd(k)*rd(k+1)*(1-aL(k))*(1-taud(k))*(1-aL(k+1))*(1-taud(k+1)));
    Y = SWu0(k)*rd(k+1)*(1-aL(k+1))*(1-taud(k+1)) / ( 1 - rd(k)*rd(k+1)*(1-aL(k))*(1-taud(k))*(1-aL(k+1))*(1-taud(k+1)));
    SWd(k+1)= X + Y;
    
end

%topmost layer k=M
% X = SWd0(M+1) / (1 - rd(M)*rdSky*(1-aL(M))*(1-taud(M))*(1-aLSky)*(1-taudSky))
% Y = SWu0(M)*rdSky*(1-aLSky)*(1-taudSky) / ( 1 - rd(M)*rdSky*(1-aL(M))*(1-taud(M))*(1-aLSky)*(1-taudSky))
SWd(M+1)= SWd0(M+1);

% upwelling diffuse after multiple scattering, eq. 25
SWu=zeros(M+1,1);
for k=1:M-1, %from layer k to layer k+1
    
    X = SWu0(k) / (1 - rd(k)*rd(k+1)*(1-aL(k))*(1-taud(k))*(1-aL(k+1))*(1-taud(k+1)));
    Y = SWd0(k+1)*rd(k)*(1-aL(k))*(1-taud(k)) / ( 1 - rd(k)*rd(k+1)*(1-aL(k))*(1-taud(k))*(1-aL(k+1))*(1-taud(k+1)));
    
    SWu(k)= X + Y;
end

%topmost layers
X = SWu0(M) / (1 - rd(M)*0*(1-aL(M))*(1-taud(M))*(1-aLSky)*(1-taudSky));
Y = SWd0(M+1)*rd(M)*(1-aL(M))*(1-taud(M)) / ( 1 - rd(M)*rdSky*(1-aL(M))*(1-taud(M))*(1-aLSky)*(1-taudSky));
SWu(M)=X+Y;
SWu(M+1)=SWu(M);

% make M x 1 sized vectors
SWd=SWd(2:M+1); % SWd(k) is now incoming downward to layer k
SWu=SWu(1:M); % SWu(k) is now incoming upward to layer k
SWu(1)=SWu(2);

%% absorbed components

aDiffuse=aL.*Kd.*(SWd + SWu); % shaded (and sunlit) leaves recieve diffuse radiation from above and below, average intensity on leaves is Kd*(SWd+SWu)
aBeam=aL.*Kb.*IbSky; % all sunlit leaves recieve beam radiation, its average intensity on leaves is Kb*IbSky

%% ******************** NOW return values to original grid ****************************************
% Node 1 is now lowest layer and N uppermost here
f_sl=exp(-Kb.*Lo); %fraction of beam radiation penetrated to layer

SWbo=IbSky*f_sl; % average beam radiation at each layer

%incident components
SWdo=zeros(N,1);
SWuo=zeros(N,1);
%absorbed components
aDIRo=zeros(N,1);
aDIFo=zeros(N,1);

% interpolate back to original grid
clear k
k=find(Lo==0,1,'first'); %canopy layer is from bottom to k-1

SWdo(1:k-1,1)=interp1(Lcum,SWd,Lo(1:k-1),'linear','extrap');
SWdo(k:N,1)=IdSky;
SWuo(1:k-1,1)=interp1(Lcum,SWu,Lo(1:k-1),'linear', 'extrap');
SWuo(k:N,1)=SWuo(k-1);
SWuo(1)=SWuo(2);

aDIFo(1:k-1,1)=interp1(Lcum,aDiffuse,Lo(1:k-1),'linear','extrap');
aDIFo(k:N,1)=0;
aDIRo(1:k-1,1)=interp1(Lcum,aBeam,Lo(1:k-1),'linear','extrap');
aDIRo(k:N,1)=0;
clear k

%---------------------------------------------------------------------
% % check that interpolation is ok
% figure(100)
% plot(SWd,-Lcum,'r-',SWdo,-Lo,'ko', SWu,-Lcum,'b-',SWuo,-Lo,'ks'); title('incident');
% legend('SWd','SWdo','SWu','SWuo')
% figure(101);
% plot(aBeam,-Lcum,'r-',aDIRo,-Lo,'ko', aDiffuse,-Lcum,'b-',aDIFo,-Lo,'ks'); title('absorbed')
%---------------------------------------------------------------------

% soil absorption (Wm-2 (ground) )
q_soil = (1-soil_albedo)*(SWdo(1) + SWbo(1));

%stand albedo
alb=SWuo(N)./(IbSky + IdSky +eps); %(-)

%correction to match absorption-based and flux-based estimates of canopy albedo (in rare cases <3% error can occur)
aa= (sum(aDIFo.*PAIo + f_sl.*aDIRo.*PAIo)+q_soil)./(IbSky+IdSky); %stand absorption as fraction of incident rad.
F=(1-alb)/aa;
F(isnan(F)==1 | F<0)=1;

aDIFo=F*aDIFo; aDIRo=F*aDIRo;

%Now compute absorbed radiation per unit total (un-clumped) shaded and sunlit leaves (Wm-2(leaf)).
%This is due simple sunlit-shaded -division when computing leaf gas-exchange.
%Rationale: clumping means that foliage elements shade each other.
%Thus here sunlit fraction of foliage f_sl=f_sl_unclumped*CLUMP where CLUMP=1 for un-clumped canopies.
%Following adjustment is required for energy conservation, i.e. total absorbed radiation in a layer must equal difference between total radiation(SWup, SWdn) entering
%and leaving the layer. Note that this is not always fullfilled in canopy rad. models.

f_sl=f_sl*CLUMP; %sunlit fraction of foliage
q_sh=aDIFo*CLUMP; %absorbed SW by shaded foliage
q_sl=q_sh + aDIRo; %-"- by sunlit foliage

%incident radiation on leaves; account for mean projections Kb, Kd
Q_sh=Kd.*(SWdo + SWuo);
Q_sl=Kb.*IbSky + Q_sh;


%% internal function definitions

    function Kd = ExtDiff(x,l)
        % function Kd = ExtDiff(x,l) Estimates extinction coefficient of diffuse radiation
        % depending on leaf-angle distribution and total canopy LAI
        %
        % INPUT: x is shape parameter, l = LAItotal
        % OUTPUT: Kd extinction coefficient (diffuse)
        %
        % Based on Campbell & Norman, 1998.
        
        dang=0.01*pi/360; % zenith angle increment 0.01 deg
        ang=0.0:dang:pi/2;
        
        % beam attenuation coefficient
        a1=(sqrt(x*x+(tan(ang)).^2));
        b1=(x+1.774*(x+1.182).^(-0.733));
        K=a1./b1;
        
        YY=exp(-K.*l).*sin(ang).*cos(ang);
        Taud=2*trapz(ang,YY); % Campbell & Norman (1998, eq. 15.5)
        Kd=-log(Taud)./l; % extinction coefficient for diffuse radiation
    end

% %---------------------------------------------------------------------
% %%% plot figures etc. for testing
%
% figure(10);
% plot(f_sl,z,'r-',f_sun,z,'go'), pause, close

% figure(11)

% subplot(221); plot(SWbo,-Lcum,'k-',SWdo,-Lcum,'r-',SWuo,-Lcum,'b-'); ylabel('-Lcum'), xlabel('SW Wm^{-2} (ground)');
% legend('SWb','SWd','SWu');
% subplot(222); plot(q_sl,-Lcum,'k-',q_sh,-Lcum,'r-'); ylabel('z'), xlabel('absorbed Wm^{-2} (leaf)');
% legend('sl','sh')
% subplot(223); plot(f_sl,-Lcum,'k-'); ylabel('-Lcum'), xlabel('f_{sl} (-)');
%
% % Fractions of incoming radiation absorbed in canopy. L is leaf-area in each layer
% aDIR=sum(aBeam.*L)/IbSky % ratio of absorbed to incoming beam in canopy
% aDIF=sum(aDiffuse.*L)./(IbSky+IdSky) % ratio of absorbed diffuse radiation to total incoming radiation above canopy
% aTOT=sum(aDiffuse.*L + aBeam.*L)./(IbSky+IdSky) % ratio of absorbed diffuse radiation  to total incoming radiation above canopy
% % surface absorption
% aSURF=(1-soil_albedo)*(SWd(2) + Ib(2))./(IbSky+IdSky) % ratio of radiation absorbed at surface to total incoming radiation above canopy
%
% aALL=aTOT + aSURF % 1-aALL should equal canopy albedo. Works about ok when soil albedo is small (problem due to wrong boundary condition in SW*A=C
%
% CanALB=SWu(M)/(IbSky+IdSky) % canopy albedo is the ratio of outgoing vs. incoming radiation at canopy top
% pause
%
%
% figure(1)
% Id=IdSky.*exp(-Kd.*Lcum);
% %plot(SWd0,-Lcum,'r-',SWu0,-Lcum,'b-'); hold on
% plot(SWd,-Lcum,'g.-',SWu,-Lcum,'c.-',Ib,-Lcum,'k.--',Id,-Lcum,'r.--')%, S,Lcum, 'k-'); hold on
% ylabel('-L_{cum} m^2m^{-2}'); xlabel('radiation W m^{-2}(ground)')
% legend('SWd','SWu','Beam: exp(-Kb*L)*Ib0','Diffuse: exp(-Kd*L)*Id0')
%
% figure(2);
% plot(aBeam, -Lcum,'r.-', aDiffuse, -Lcum,'b.-')
% ylabel('-L_{cum} m^2m^{-2}'); xlabel('absorbed radiation in layer W m^{-2}(leaf)')
% legend('Beam','Diffuse')


end
