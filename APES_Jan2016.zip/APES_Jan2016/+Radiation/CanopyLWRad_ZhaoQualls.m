function [LWnet,LWdn,LWup,LWleaf] = CanopyLWRad_ZhaoQualls(LAIz,CLUMP,leaf_angle_para,T,LWdn0,LWup0,leaf_emi, soil_emi)
% Estimates incident and absorbed SW radiation within plant canopies.
% Includes multiple scattering among the canopy layers and soil surface.
% Within-shoot scattering is included through effective leaf_albedo < leaf
% single-scattering albedo.
%
% Returns incident and absorbed SW separately for sunlit (sl) and shaded (sh) leaves.
%
% INPUT:
%   LAIz: leaf-area index per layer (m2(leaf) m-2(ground)), Nx1-array.
%   CLUMP: element clumping index (-), [ 0> CLUMP <=1], scalar
%   leaf_angle_para: leaf-angle distribution parameter (-), scalar: 1=spherical, 0=vertical, 'inf'=horizontal
%   Tleaf: leaf (or air) temperature (degC)
%   LWdn0: downwelling LW at canopy top (Wm-2)
%   LWup0: upwelling LW at soil surface (Wm-2);
%
% OUTPUT:
%   LWnet: net long-wave radiation (Wm-2(ground))
%   LWdn: downward long-wave (Wm-2(ground))
%   LWup: upward long-wave (Wm-2(ground))
%   LWleaf: net longwave radiation per unit un-clumped leaf-area in a canopy layer(Wm-2(leaf))
%
% CONTAINS:
%   1 internal function (ExtDiff)
%
% REFERENCES:
%   Zhao & Qualls, 2005 Water Resources Research. Multi-layer Multiple scattering model
%   Estimates SW attenuation inc. multiple scattering within the canopy.
%   Campbell & Norman (1998): An introduction to environmental biophysics.
%   Spitters, (1986): Separating the diffuse and direct component of global
%   radiation and its implications for modeling canopy photosynthesis part
%   II: Calculation of canopy photosynthesis. Agric. For. Meteorol. 38, 231-242.
%   Wang & Leuning (1998): A two-leaf model for canopy conductance, photosynthesis and partitioning of
%   available energy I: Model description and comparison with a multi-layered model. Agric. For. Meteorol. 91, 89-111.
%   Juang, Katul et al. 2008: Investigating a hierarchy of Eulerian Closure Models for Scalar Transfer Inside Forested Canopies. BLM 128:1-32.
%Flerchinger et al. 2009. Simulation of within-canopy radiation exchange, NJAS 57, 5-15
% Samuli Launiainen (METLA) 2013-2015
%
% LAST EDIT: 23.02.2015

%-------

StefBolz=5.6697e-8; %Stefan-Boltzman constant W m-2 K-4

if T<200,T=T+273.15; end 

% --- set computation grid
N=length(LAIz); %layers in original grid
M=max(10,N); % number of layers in the canopy % NOTE: needs to be larger or equal to length(LAIz)

%LAI in original and computational grid
LAI=CLUMP*sum(LAIz);  %total canopy plant area index corrected for clumping (m2 m-2)
LAIo=CLUMP*LAIz; %effective layerwise LAI (or PAI) in original grid

Lo=cumsum(flipud(LAIo)); %cumulative plant area index from canopy top
Lo=flipud(Lo); % node 1 is canopy bottom, N is top

% L vector to the radiation calculations need to be equally spaced
L(1:M,1)=LAI/M; % plant area index (m2m-2 in a layer

Lcum=cumsum(L); %cumulative PAI from canopy top
Lcum=flipud(Lcum);


%------ leaf distribution properties
x=leaf_angle_para; % x=1 (spherical), x=0 (vertical), x='inf' (very large) (horizontal) leaf-area distribution. See Campbell&Norman,1998.Introduction to Env. Biophysics

%back-scattering fraction, approximation
if x==1, rd=2/3; end %spherical leaf distrib.
if x==0, rd=0.5; end %vertical leafs
if x>100, rd=1; end %horizontal leafs

rd=ones(M,1)*rd; %back-scattering fraction
eL=ones(M,1)*leaf_emi; % leaf emissivity

%------ Define black leaf extinction coefficients for  diffuse radiation
Kd=ExtDiff(x, LAI); %

%------ propability of contact with canopy elements in each layer
taud=exp(-Kd.*L); %diffuse

%% set up tridiagonal matrix A and solve LW from A*LW=C
%Zhao & Qualls, 2006. eq. 23-25.
%
%layer 1 is soil surface, 2 is lowest canopy layer
%layer M+1 is topmost canopy layer and M+2 is upper boundary (sky)

%soil BC (M=1)
eL0=soil_emi; 
taud0=0; % soil transmissivity

%atm BC (M=M+2)
eLSky=0; %absorptivity
taudSky=1; %transmissivities
%taubSky=1;
rdSky=0; %reflection coefficients are zero
%rbSky=0;


%A = coefficient matrix
A=zeros(2*M+2, 2*M+2);

%k=1 accounts soil
A(1,1)=1; %soil

A(2,1) = - ( taud(2) + (1-taud(2))*(1-eL(2))*(1-rd(2)) );
A(2,2) = -1*(taud(2) + (1-taud(2))*(1-eL(2))*(1-rd(2)))*(1-eL0);
A(2,3) = ( 1 - 1*rd(2)*(1-eL0)*1*(1-eL(2))*(1-taud(2)) );

A(3,2) = ( 1 - rd(3)*rd(4)*(1-eL(3))*(1-taud(3))*(1-eL(4))*(1-taud(4)) );
A(3,3) = -rd(4)*( taud(3) + (1-taud(3))*(1-eL(3))*(1-rd(3)) )* (1-eL(4))*(1-taud(4));
A(3,4) = -( taud(3) + (1-taud(3))*(1-eL(3))*(1-rd(3)) );

for k=2:M-1,
    A(2*k,2*k-1) = - ( taud(k) + (1-taud(k))*(1-eL(k))*(1-rd(k)) );
    A(2*k,2*k) = -rd(k-1)*(taud(k) + (1-taud(k))*(1-eL(k))*(1-rd(k)))*(1-eL(k-1))*(1-taud(k-1));
    A(2*k,2*k+1) = ( 1 - rd(k-1)*rd(k)*(1-eL(k-1))*(1-taud(k-1))*(1-eL(k))*(1-taud(k)) );
    
    A(2*k+1,2*k) = ( 1 - rd(k)*rd(k+1)*(1-eL(k))*(1-taud(k))*(1-eL(k+1))*(1-taud(k+1)) );
    A(2*k+1,2*k+1) = -rd(k+1)*( taud(k) + (1-taud(k))*(1-eL(k))*(1-rd(k)) )* (1-eL(k+1))*(1-taud(k+1));
    A(2*k+1,2*k+2) = -( taud(k) + (1-taud(k))*(1-eL(k))*(1-rd(k)) );
end
clear k;

%uppermost nodes
A(2*M,2*M-1) = - ( taud(M) + (1-taud(M))*(1-eL(M))*(1-rd(M)) );
A(2*M,2*M) = -rd(M-1)*(taud(M) + (1-taud(M))*(1-eL(M))*(1-rd(M)))*(1-eL(M-1))*(1-taud(M-1));
A(2*M,2*M+1) = (1 - rd(M-1)*rd(M)*(1-eL(M-1))*(1-taud(M-1))*(1-eL(M))*(1-taud(M)));

% A(2*M+1,2*M) = ( 1 - rd(M)*rdA*(1-eL(M))*(1-taud(M))*(1-eLSky)*(1-taudSky) );
% A(2*M+1,2*M+1) = -rdSky*( taud(M) + (1-taud(M))*(1-eL(M))*(1-rd(M)) )* (1-eLSky)*(1-taudSky);
% A(2*M+1,2*M+2) = -( taud(M) + (1-taud(M))*(1-eL(M))*(1-rd(M)) );
% A(2*M+2,2*M+2)=1;

%commented rows up reduce to
A(2*M+1,2*M) = 1;
A(2*M+1,2*M+1) = 0;
A(2*M+1,2*M+2) = -( taud(M) + (1-taud(M))*(1-eL(M))*(1-rd(M)) );
A(2*M+2,2*M+2)=1;

% RHS vector C
LWsource=leaf_emi*StefBolz.*T.^4; %emitted LW at each layer
%LWsource=zeros(M,1);

C=zeros(2*M+2,1);
C(1)=LWup0;
%k=1
C(2) = ( 1 - 1*rd(1)*(1-eL0)*(1-taud0)*(1-eL(1))*(1-taud(1)) )*(1-taud(1))*LWsource(1);
C(3) = ( 1 - rd(1)*rd(2)*(1-eL(1))*(1-taud(1))*(1-eL(2))*(1-taud(2)) )*(1-taud(1))*LWsource(1);
n=4; % dummy variable
for k=2:M-1,
    C(n) = ( 1 - rd(k-1)*rd(k)*(1-eL(k-1))*(1-taud(k-1))*(1-eL(k))*(1-taud(k)) )*(1-taud(k))*LWsource(k);
    C(n+1) = ( 1 - rd(k)*rd(k+1)*(1-eL(k))*(1-taud(k))*(1-eL(k+1))*(1-taud(k+1)) )*(1-taud(k))*LWsource(k); 
    n=n+2;
end
C(n) = ( 1 - rd(M-1)*rd(M)*(1-eL(M-1))*(1-taud(M-1))*(1-eL(M))*(1-taud(M)) )*(1-taud(M))*LWsource(M);
C(n+1) = (1-taud(M))*LWsource(M);
C(n+2)=LWdn0; %atm boundary
clear n k LWsource

% solve A*LW=C;
LW=A\C;

LWu0=LW(1:2:2*M+1); %upward hemispherical radiation (Wm-2 ground)
LWd0=LW(2:2:2*M+2); %downward hemispherical radiation (Wm-2 ground)

% figure()
% plot(LWu0,'k-'); hold on
% plot(LWd0,'r-'); pause, close

%% calculate multiple scattering, Zhao & Qualls, 2005. eq. 8 & 9.

% downwelling diffuse after multiple scattering, eq. 24
LWd=zeros(M+1,1);
for k=M-1:-1:1, % from layer k+1 to layer k
    
    X = LWd0(k+1) / (1 - rd(k)*rd(k+1)*(1-eL(k))*(1-taud(k))*(1-eL(k+1))*(1-taud(k+1)));
    Y = LWu0(k)*rd(k+1)*(1-eL(k+1))*(1-taud(k+1)) / ( 1 - rd(k)*rd(k+1)*(1-eL(k))*(1-taud(k))*(1-eL(k+1))*(1-taud(k+1)));
    LWd(k+1)= X + Y;
    
end
%topmost layer
LWd(M+1)= LWd0(M+1);

% upwelling diffuse after multiple scattering, eq. 25
LWu=zeros(M+1,1);
for k=1:M-1, %from layer k to layer k+1
    
    X = LWu0(k) / (1 - rd(k)*rd(k+1)*(1-eL(k))*(1-taud(k))*(1-eL(k+1))*(1-taud(k+1)));
    Y = LWd0(k+1)*rd(k)*(1-eL(k))*(1-taud(k)) / ( 1 - rd(k)*rd(k+1)*(1-eL(k))*(1-taud(k))*(1-eL(k+1))*(1-taud(k+1)));
    
    LWu(k)= X + Y;
end
%topmost layers
X = LWu0(M);
Y = LWd0(M+1)*rd(M)*(1-eL(M))*(1-taud(M));
LWu(M)=X+Y;
LWu(M+1)=LWu(M);

% make M x 1 sized vectors
LWd=LWd(2:M+1); % SWd(k) is now incoming downward to layer k
LWu=LWu(1:M); % SWu(k) is now incoming upward to layer k
LWu(1)=LWup0;

%absorbed LW per unit clumped leaf area (Wm-2(leaf)), 
%Flerchinger et al. 2009. Simulation of within-canopy radiation exchange, NJAS 57, 5-15

LWl=(1-taud).*eL.*(LWd + LWu - 2*StefBolz*T.^4)./L;

%% ******************** NOW return values to original grid ****************************************
% Node 1 is now lowest layer and N uppermost here

%incident components
LWdn=zeros(N,1);
LWup=zeros(N,1);
LWleaf=zeros(N,1);

% interpolate back to original grid
clear k
k=find(Lo==0,1,'first'); %canopy layer is from bottom to k-1

LWdn(1:k-1,1)=interp1(Lcum,LWd,Lo(1:k-1),'linear','extrap');
LWdn(k:N,1)=LWdn0;
LWup(1:k-1,1)=interp1(Lcum,LWu,Lo(1:k-1),'linear', 'extrap');
LWup(k:N,1)=LWup(k-1);
LWup(1)=LWup0;

LWleaf(1:k-1)=interp1(Lcum,LWl,Lo(1:k-1),'linear','extrap');
clear k LWl

%---------------------------------------------------------------------
% check that interpolation is ok
% figure(100)
% plot(LWd,-Lcum,'r-',LWdn,-Lo,'ko', LWu,-Lcum,'b-',LWup,-Lo,'ks'); title('incident LW');
% legend('LWd','LWdo','LWu','LWuo')

%---------------------------------------------------------------------

%outputs:
LWnet=LWdn-LWup;
LWleaf=LWleaf*CLUMP; %account for leaf clumping since gas-exchange and ebalance computations are per 1-sided un-clumped leaf area.


%% internal function definitions

    function Kd = ExtDiff(x,l)
        % function Kd = ExtDiff(x,l) Estimates extinction coefficient of diffuse radiation
        % depending on leaf-angle distribution and total canopy LAI
        %
        % INPUT: x is shape parameter, l = LAItotal
        % OUTPUT: Kd extinction coefficient (diffuse)
        %
        % Based on Campbell & Norman, 1998.
        
        dang=0.01*pi/360; % zenith angle increment 0.01 deg
        ang=0.0:dang:pi/2;
        
        % beam attenuation coefficient
        a1=(sqrt(x*x+(tan(ang)).^2));
        b1=(x+1.774*(x+1.182).^(-0.733));
        K=a1./b1;
        
        YY=exp(-K.*l).*sin(ang).*cos(ang);
        Taud=2*trapz(ang,YY); % Campbell & Norman (1998, eq. 15.5)
        Kd=-log(Taud)./l; % extinction coefficient for diffuse radiation
    end

% %---------------------------------------------------------------------
% %%% plot figures etc. for testing
%
% figure(10);
% plot(f_sl,z,'r-',f_sun,z,'go'), pause, close

% figure(11)

% subplot(221); plot(SWbo,-Lcum,'k-',SWdo,-Lcum,'r-',SWuo,-Lcum,'b-'); ylabel('-Lcum'), xlabel('SW Wm^{-2} (ground)');
% legend('SWb','SWd','SWu');
% subplot(222); plot(q_sl,-Lcum,'k-',q_sh,-Lcum,'r-'); ylabel('z'), xlabel('absorbed Wm^{-2} (leaf)');
% legend('sl','sh')
% subplot(223); plot(f_sl,-Lcum,'k-'); ylabel('-Lcum'), xlabel('f_{sl} (-)');
%
% % Fractions of incoming radiation absorbed in canopy. L is leaf-area in each layer
% aDIR=sum(aBeam.*L)/IbSky % ratio of absorbed to incoming beam in canopy
% aDIF=sum(aDiffuse.*L)./(IbSky+IdSky) % ratio of absorbed diffuse radiation to total incoming radiation above canopy
% aTOT=sum(aDiffuse.*L + aBeam.*L)./(IbSky+IdSky) % ratio of absorbed diffuse radiation  to total incoming radiation above canopy
% % surface absorption
% aSURF=(1-soil_albedo)*(SWd(2) + Ib(2))./(IbSky+IdSky) % ratio of radiation absorbed at surface to total incoming radiation above canopy
%
% aALL=aTOT + aSURF % 1-aALL should equal canopy albedo. Works about ok when soil albedo is small (problem due to wrong boundary condition in SW*A=C
%
% CanALB=SWu(M)/(IbSky+IdSky) % canopy albedo is the ratio of outgoing vs. incoming radiation at canopy top
% pause
%
%
% figure(1)
% Id=IdSky.*exp(-Kd.*Lcum);
% %plot(SWd0,-Lcum,'r-',SWu0,-Lcum,'b-'); hold on
% plot(SWd,-Lcum,'g.-',SWu,-Lcum,'c.-',Ib,-Lcum,'k.--',Id,-Lcum,'r.--')%, S,Lcum, 'k-'); hold on
% ylabel('-L_{cum} m^2m^{-2}'); xlabel('radiation W m^{-2}(ground)')
% legend('SWd','SWu','Beam: exp(-Kb*L)*Ib0','Diffuse: exp(-Kd*L)*Id0')
%
% figure(2);
% plot(aBeam, -Lcum,'r.-', aDiffuse, -Lcum,'b.-')
% ylabel('-L_{cum} m^2m^{-2}'); xlabel('absorbed radiation in layer W m^{-2}(leaf)')
% legend('Beam','Diffuse')


end
