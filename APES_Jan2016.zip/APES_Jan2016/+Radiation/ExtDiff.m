function Kd = ExtDiff(x,l)
    % function Kd = ExtDiff(x,l) Estimates extinction coefficient of diffuse radiation
    % depending on leaf-angle distribution and total canopy LAI
    %
    % INPUT: x is shape parameter, l = LAItotal
    % OUTPUT: Kd extinction coefficient (diffuse)
    %
    % Based on Campbell & Norman, 1998.

    dang=0.01*pi/360; % zenith angle increment 0.01 deg
    ang=0.0:dang:pi/2;

    % beam attenuation coefficient
    a1=(sqrt(x*x+(tan(ang)).^2));
    b1=(x+1.774*(x+1.182).^(-0.733));
    K=a1./b1;

    YY=exp(-K.*l).*sin(ang).*cos(ang);
    Taud=2*trapz(ang,YY); % Campbell & Norman (1998, eq. 15.5)
    Kd=-log(Taud)./l; % extinction coefficient for diffuse radiation
end

