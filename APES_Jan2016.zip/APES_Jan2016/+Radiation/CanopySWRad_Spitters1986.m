function [Q_sl, Q_sh, q_sl1, q_sh1, q_soil, f_sl, Qb1, Qd1, alb1] = CanopySWRad_Spitters1986(LAIz,CLUMP,leaf_angle_para,ZEN,Ib1,Id1,LeafAlbedo,SoilAlbedo)
%
% Estimates profiles of incident and absorbed PAR and NIR within the canopy. Absorptition is calculated separately for sunlit (sl) and 
% shaded (sh) leaves. 
%
% INPUT: 
%   LAIz: leaf (or plant) area index in layer (m2(leaf)/m2(ground)), Nx1 array
%   CLUMP: element clumping index (-), [ 0> CLUMP <=1], scalar
%   leaf_angle_para: leaf-angle distribution parameter (-), scalar: 1=spherical, 0=vertical, 'inf'=horizontal
%   ZEN: solar zenith angle (rad)
%   Ib1: incident beam radiation in PAR/NIR-waveband, above canopy (Wm-2)
%   Id1: diffuse radiation in PAR/NIR-waveband, above canopy (Wm-2)
%   LeafAlbedo (-)
%   SoilAlbedo (-)
%   
% OUTPUT: 
%   q_sl1: absorbed PAR/NIR by sunlit leaves (Wm-2(leaf))
%   q_sh1: absorbed PAR/NIR by sunlit leaves (Wm-2(leaf))
%   q_soil: absorbed PAR/NIR by soil surface (Wm-2(ground))
%   f_sl: Fraction of sunlit leaves (dimensionless)
%   Qb1: direct PAR/NIR at z (Wm-2(ground))
%   Qd1: diffuse PAR/NIR at z (Wm-2(ground))
%   alb: canopy albedo (-)
%
% CONTAINS:
%   1 internal function (ExtDiff)
%
%   Based on Campbell & Norman (1998): An introduction to environmental biophysics.
%   Spitters, (1986): Separating the diffuse and direct component of global
%   radiation and its implications for modeling canopy photosynthesis part
%   II: Calculation of canopy photosynthesis. Agric. For. Meteorol. 38, 231-242.
%   Wang & Leuning (1998): A two-leaf model for canopy conductance, photosynthesis and partitioning of 
%   available energy I: Model description and comparison with a multi-layered model. Agric. For. Meteorol. 91, 89-111.
%   Juang, Katul et al. 2008: Investigating a hierarchy of Eulerian Closure Models for Scalar Transfer Inside Forested Canopies. BLM 128:1-32.
%
% NOTE: Describes PAR absorption and profiles well while NIR-waveband is poorly represented especially during clear days when large fraction of
% radiation is direct beam!!!!
%
% Samuli Launiainen (METLA) 3/2011 - 9/2013, last edit: 23.2.2015


%% check inputs

if Ib1<0,Ib1=0; end
if Id1<0,Id1=0; end


%% defining constants
s1=LeafAlbedo;
rs1=SoilAlbedo;

x=leaf_angle_para;
    %x=1; % ~ Spherical leaf angle distribution
    %x=infinity ~ horizontal angle leaf distribution
    %x=0 ~ vertical leaf angle distribution

L=cumsum(flipud(LAIz))*CLUMP; % cumulative distribution of hemi-surface leaf area from top to bottom taking account clumping effect
Lt=max(L); % total PAI

%Black leaf extinction coefficients for direct beam and diffuse radiation
%(Campbell & Norman, eq. 15.4)
XN1=(sqrt(x*x+(tan(ZEN))^2));
XD1=(x+1.774*(x+1.182)^(-0.733));
Kb=XN1/XD1; % direct beam

Kb=min([50 Kb]);
if Kb<0,Kb=50; end
clear XN1 XD1

%diffuse
Kd=ExtDiff(x, max(L)); % 

% fraction of sunlit & shaded leaves
f_sl=exp(-Kb.*L);

%% canopy reflection coefficient: Campbell & Norman (1998)

rcpy1=(1-(1-s1)^0.5)/(1+(1-s1)^0.5); % canopy hemispherical reflection coefficient

% in case canopy is deep, soil reflections have small impact and canopy reflection coefficients are:
rb1=2*Kb/(Kb+1)*rcpy1; %direct
rd1=2*Kd/(Kd+1)*rcpy1; %diffuse

% in sparse canopies soil reflectance has to be taken account

AA=((rb1 - rs1)/(rb1*rs1 -1))*exp(-2*(1-s1)^0.5*Kb*Lt);
rb1= (rb1 + AA)/(1+rb1*AA); % direct
clear AA 

AA=((rd1 - rs1)/(rd1*rs1 -1))*exp(-2*(1-s1)^0.5*Kd*Lt);
rd1= (rd1 + AA)/(1+rd1*AA); % diffuse
clear AA


%% incident PAR/NIR as a funtion of L

qd1=(1-rd1)*Id1.*exp(-(1-s1)^0.5*Kd.*L); %diffuse
qb1=Ib1*exp(-Kb.*L); % beam
qbt1=(1-rb1)*Ib1.*exp(-(1-s1)^0.5*Kb.*L); % total beam

qsc1=qbt1 - (1-rb1)*qb1; % scattered beam

% at each layer 
Qd1=qd1 + qsc1; % total diffuse
Qb1=qb1; % total direct beam

%Q1=Qb1 + Qd1; % total PAR

%% absorbed components: A = dq/dL

Ad1=(1-rd1)*Id1*(1-s1)^0.5*Kd.*exp(-(1-s1)^0.5*Kd.*L); %diffuse
Abt1=(1-rb1)*Ib1*(1-s1)^0.5*Kb.*exp(-(1-s1)^0.5*Kb.*L); % total beam
%Asc1=Ib1*( (1-rb1).*(1-s1)^0.5.*Kb.*exp(-(1-s1)^0.5*Kb.*L) -(1-s1).*Kb.*exp(-(1-s1)^0.5*Kb.*L) );

Ab1=(1-rb1)*(1-s1)*Ib1.*Kb.*exp(-(1-s1)^0.5*Kb.*L); % direct beam

%% absorbed at sunlit & shaded leaves (Wm-2(leaf))

q_sh1= Ad1 + (Abt1 - Ab1); %Ad1 + Asc1;
q_sl1= q_sh1 + (1-s1)*Kb*Ib1; % Spitters eq. 14


%% absorbed by soil surface (Wm-2(ground))

q_soil=(1-SoilAlbedo)*(Qb1(end)+Qd1(end));

%% canopy albedos

alb1=(rb1*Ib1 + rd1*Id1) /(Ib1 + Id1); % canopy albedo

%% flip all vectors so that index 1 is ground

f_sl=flipud(f_sl); q_sl1=flipud(q_sl1); q_sh1=flipud(q_sh1); Qb1=flipud(Qb1); Qd1=flipud(Qd1); L=flipud(L);

%incident radiation on shaded and sunlit leaves

%incident radiation on leaves
Q_sh=Kd.*Qd1;
Q_sl=Kb.*Ib1 + Q_sh;

%% internal function definitions 

    function Kd = ExtDiff(x,l)
    % function Kd = ExtDiff(x,l) Estimates extinction coefficient of diffuse radiation 
    % depending on leaf-angle distribution and total canopy LAI
    % INPUT: x is shape parameter, l = LAItotal
    % OUTPUT: Kd extinction coefficient (diffuse)
    
    dang=0.01*pi/360; % zenith angle increment 0.01 deg
    ang=0.0:dang:pi/2;
    
    % beam attenuation coefficient
    a1=(sqrt(x*x+(tan(ang)).^2));
    b1=(x+1.774*(x+1.182).^(-0.733));
    K=a1./b1;
    
    Y=exp(-K.*l).*sin(ang).*cos(ang);
    taud=2*trapz(ang,Y); % Campbell & Norman (1998, eq. 15.5)
   	Kd=-log(taud)./l; % extinction coefficient for diffuse radiation
    end

% 
    % %% plot test figures

%     figure(12)
% 
%     subplot(221); plot(qb1,-flipud(L), 'r-', qd1,-flipud(L),'k-',qsc1,-flipud(L),'b-'); xlabel('PAR(NIR (Wm^{-2} ground)'); ylabel('-L_t (m^2m^{-2})')
%     legend('beam','dif','scatt','Orientation','horizontal'); title('CanopySWRad Spitters1986')
%     subplot(222); plot(q_sl1,-L,'r-',q_sh1,-L,'k-');ylabel('L_t (m^2m^{-2})'); xlabel('absorbed Q (Wm^{-2} leaf)');
%     legend('sl','sh')
%     subplot(223); plot(Qb1,-L, 'r-', Qd1,-L,'k-');ylabel('L_t (m^2m^{-2})'); xlabel('incident Q (Wm^{-2} ground)');
%     legend('Beam', 'Diffuse')
%     pause
end