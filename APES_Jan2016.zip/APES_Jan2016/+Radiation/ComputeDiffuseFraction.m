function f_diff=ComputeDiffuseFraction(Doy,Lat,Lon,Rglob)
%function f_diff=EstimateDiffuseFraction(Doy,tm,Lat,Lon,Rglob,Model)) computes
%fraction of diffuse global radiation from measured Global radiation (Rglob,Wm-2)
%
%INPUT:
%   Doy - julian day, include decimals
%   Lat - latitude (deg)
%   Lon - longitude (deg)
%   Rglob - measured global radiation (Wm-2)
%OUTPUT:
%   f_diff: fraction of diffuse to total radiation (0-1) [-]
%SOURCE: Spitters et al. (1986), Appendix eq. 20a-20d
%
%Samuli Launiainen, 2014


    f_diff=ones(size(Rglob))*NaN;

    %use hourly model, Spitters et al. 1986 Appendix eq. 20a-20d
    tm=(Doy-floor(Doy))*24;
    Doy=floor(Doy)-1;
    ZEN=SolarAngles(Doy,Lat,Lon,tm);
    Beta=pi/2 - ZEN; %elevation angle

    Sg=1367.*(1.0 + 0.033.*cos(2*pi.*(Doy-10)./365)).*sin(Beta); %clear sky Global radiation at surface

    X=min(max(0,Rglob./Sg),1); %atm transmissivity

    R=0.847 - 1.61*sin(Beta) +1.04*(sin(Beta)).^2;
    K=(1.47-R)/1.66;

    f_diff(X<=0.22)=1;
    f_diff(X>0.22 & X<=0.35) = 1 -6.4*(X - 0.22).^2;
    f_diff(X>0.35 & X<= K) = 1.47 - 1.66*X;
    f_diff(X>K)=R;




    function [ZEN, AZIM,dd]=SolarAngles(DOY, LAT1, LON1, tm)
        % function[ZEN, AZIM, dd]=solar_dec_azimuth.m computes the solar zenith
        % angle (ZEN), azimuth angle (AZIM) and declination angle (dd)
        % from DOY, LAT (+ northern), longitude (+ east from Greenwich) and time of day
        %
        % Campbell & Norman, 1998: Introduction to environmental biophysics, Springer.
        %
        
        CF=pi/180; % conversion deg -->rad
        LAT=LAT1*CF;
        LON=LON1*CF;
        
        % ---> compute declination angle
        xx=278.97+0.9856*DOY+1.9165*sin((356.6+0.9856*DOY)*CF);
        dd=asin(0.39785*sin(xx*CF));
        
        % ---> compute Zenith angle
        LC=1/15*LON; % longitude correction, hours
        f=(279.575+0.9856*DOY)*CF;
        ET=(-104.7*sin(f)+596.2*sin(2*f)+4.3*sin(3*f)-12.7*sin(4*f)-429.3*cos(f)-2*cos(2*f)+19.3*cos(3*f))/3600;
        
        to=12-LC-ET; % local solar noon
        aa=sin(LAT)*sin(dd)+(cos(LAT))*cos(dd)*cos(15*(tm-to)*CF);
        ZEN=acos(aa);
        
        % ---> compute azimuth angle
        AZIM=acos(-(sin(dd)-(sin(LAT)).*cos(ZEN))./((cos(LAT)).*sin(ZEN)));
    end

end
