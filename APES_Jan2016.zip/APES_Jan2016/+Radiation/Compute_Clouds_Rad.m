function [f_cloud, f_diff, emi_sky]=Compute_Clouds_Rad(DOY, ZEN, Qtop, H2O)
% function [f_cloud, f_diff]=Compute_Clouds_Rad(DOY, ZEN, Qtop)
% estimates atmospheric transmissivity (tau_atm [-]), cloud cover fraction
% (f_cloud (0-1), [-]) and fraction of diffuse to total SW radiation (f_diff, [-])
%
%INPUT:     DOY - julian day
%           ZEN - sun zenith angle (rad)
%           Qtop - total measured Global radiation above canopy (Wm-2)
%           H2O - water vapor pressure (Pa)
%OUTPUT:    f_cloud - cloud cover fraction (0-1) [-]
%           f_diff - fraction of diffuse to total radiation (0-1), [-]
%           emi_sky - atmospheric emissivity (0-1) [-]
%
% Cloudiness estimate is based on Song et al. 2009 JGR 114, 2009, Appendix A & C
% Clear-sky emissivity as in Niemel� et al. 2001 Atm. Res 58: 1-18.
% eq. 18 and cloud correction as Maykut & Church 1973. 
% Reasonable fit against Hyyti�l� data (tested 20.6.13)
%
% Samuli Launiainen, METLA, 2011-2013

So=1367; % solar constant at top of atm.
Qclear=(So.*(1.0 + 0.033.*cos(2*pi.*(DOY-10)./365)).*cos(ZEN)); %clear sky Global radiation at surface
tau_atm=Qtop./Qclear;
tau_atm(tau_atm<0)=0;

f_cloud=max(0, 1.0-tau_atm/0.7); % cloud cover fraction

% calculate fraction of diffuse to total Global radiation: Song et al. 2009 JGR eq. A17.
f_diff=ones(size(f_cloud));
f_diff(tau_atm>0.7)=0.2;

ind=find(tau_atm>=0.3 & tau_atm<=0.7);
f_diff(ind)=1-2*(tau_atm(ind)-0.3);

% Clear-sky atmospheric emissivity

ea = H2O/100; %near-surface vapor pressure (hPa)
if ea>=2,
    emi0=0.72 + 0.009*(ea-2);
else
    emi0= 0.72 -0.076*(ea-2);
end

%all-sky emissivity (cloud-corrections)
emi_sky=(1 + 0.22*f_cloud.^2.75)*emi0; % Maykut & Church (1973)

%other emissivity formulas tested
%emi_sky=(1 + 0.2*f_cloud)*emi0;
%emi_sky=(1 + 0.3*f_cloud.^2.75)*emi0; % Maykut & Church (1973)
%emi_sky=(1 + (1./emi0 -1)*0.87.*f_cloud^3.49).*emi0; % Niemel� et al. 2001 eq. 15 assuming Ts = Ta and surface emissivity = 1
%emi_sky=(1-0.84*f_cloud)*emi0 + 0.84*f_cloud; % atmospheric emissivity (Unsworth & Monteith, 1975)
