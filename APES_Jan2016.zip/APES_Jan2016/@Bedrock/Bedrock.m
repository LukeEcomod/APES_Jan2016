classdef Bedrock
    %Bedrock -object describes homogenous bedrock layer properties that are used in APES for calculating
    %lower boundary conditions for soil heat balance equation.
    %
    %CONTAINS: class-dependent function Fourier_Homogenous to solve temperature profile in Bedrock.
    %
    % Samuli Launiainen METLA 14.11.2013
    
    properties (SetAccess = public, GetAccess = public)
        zs; % soil node depth (<0, m)
        dzs; % soil node thickness (m)
        NrOfLayers; % number of soil layers
        Density; %kg m-3
        SpecificHeat; %specific heat capacity J kg-1 K-1
        ThermalConductivity; % W m-1 K-1
        ThermalDiffusivity; %thermal diffusivity (m2 s-1)

        T; % temperature profile
        Tannual; % annual mean temperature (degC)

    end
    
    methods
       % class constructor
        function obj=Bedrock(zs,To,Tannual,Ktherm,SpecificHeat,Density) 
            obj.zs=zs;
            obj.dzs=abs(zs(1)-zs(2));
            obj.Tannual=Tannual;
            obj.ThermalConductivity=Ktherm;
            obj.SpecificHeat=SpecificHeat;
            obj.ThermalDiffusivity=Ktherm/(SpecificHeat*Density);
            
            obj.T=interp1(To(:,1),To(:,2),zs,'linear','extrap'); %  interpolate initial temperature profile to grid
            obj.NrOfLayers=length(zs);
        end
        
        
        % *********** Heat transport equation for homogenous soil layer ****************************************
        %(could be used in MLCM to create realistic lower BC for heat balance in the computational domain.
        
        function U = Fourier_Homogenous(obj,tm,c1,c2)
        % function U = Fourier_Homogenous(obj,tm,c1,c2,ubctype,lbctype)
        % Solves heat equation in homogenous soil using explicit Eulerian method:
        % Forward difference in time, centered in space

        % INPUT:    obj - Bedrock -object
        %           tm - time when result is expected
        %           c1 - Upper boundary condition 


        % OUTPUT:   U - temperature profile in the computational domain
        % Samuli Launiainen 22.02.2011
        
        %           ubctype & lbctype - Type of boundary condition (1 = Dirchlet, specific
        %           value, 2 = Neumann, dU/dx specified)
            ubctype=1;
            lbctype=1;
               
            x=obj.zs;
            K=obj.ThermalDiffusivity;
            Uxo=obj.T; %initial condition
            
            n=length(x); %number of gridpoints
            
            dx=abs(x(1) - x(2)); % space increment

            % ensure mesh Fourier number is <0.4
            m=10;
            dt=tm/m; % time increment for model
            
            R= K*dt/(dx^2); % mesh Fourier number
            
            if abs(R>0.5),
                disp('Bedrock.Fourier_Homogenous: solution unstable, check mesh Fourier number R<0.5')
                return
            end
            
            S=zeros(size(x)); %sink/source term set here to zero

            
            %% solve FTCS-difference equation: explicit Eulerian method: Forward difference in time, centered in space

            if ubctype==1 && lbctype ==1 % Dirchlet boundary conditions (specified value at boundary)
                U=Uxo;
                U(1)=c1;
                U(n)=c2;

                for j=2:m %time-loop
                    for i=2:n-1 % x-loop
                        %d2tdx=(U(i-1,j-1) - 2*U(i,j-1) + U(i+1,j-1))/(dx^2) 
                        U(i)=Uxo(i) + R*( U(i-1) - 2*U(i) + U(i+1) ) +dt*S(i);
                    end
                    Uxo=U; %new temperature
                    %pause
                end

            end

            if ubctype==2 && lbctype ==2 % Neumann (dU/dx specified at upper & lower grid point)
                U=Uxo; % initial condition at to

                for j=2:m %t-loop
                    %upper boundary   
                     U(1)=Uxo(1) + R*( 2*U(2) -2*U(1) -2*dx*c1);
                     for i=2:n-1 % nodes 2 to n-1
                       U(i)=Uxo(i) + R*( U(i+1) -2*U(i) + U(i-1)) +dt*S(i);
                     end
                        %lower boundary   
                     U(n)=Uxo(n) + R*( 2*U(n-1) -2*U(n) +2*dx*c2);
                     Uxo=U; % new temperature
                end
               
            end
        end % end Fourier_Homogenous
        
        %% *****************************************************************************************

        function Fheat = HeatFlux(obj,T)
        % calculates heat conduction (Wm-2) between nodes using central difference
        % approximation in middle nodes and forward/backward diffence at
        % upper/lower boundaries

        % OUTPUT: Fheat - vertical heat fluxes (K/s/m) 
        %   
            N=obj.NrOfLayers;

            % gradient, central difference
            dT(2:N-1)=(T(3:N) - T(1:N-2))/(2*obj.dzs);
            %forward/backward differences at boundaries
            dT(1)=(T(2)-T(1))/obj.dzs;
            dT(N)=(T(N)-T(N-1))/obj.dzs;

            Fheat = -obj.ThermalConductivity.*dT; %

        end
    end % methods
end

