09.02.2015 Samuli Launiainen Luke

Folder @Bedrock contains Bedrock.m, APES -model Bedrock class-definition file.

  Bedrock

  Properties:
                     zs: [26x1 double]
                    dzs: 0.4000
             NrOfLayers: 26
                Density: []
           SpecificHeat: 820
    ThermalConductivity: 3
     ThermalDiffusivity: 1.3806e-006
                      T: [26x1 double]
                Tannual: 4.5000

  Methods

 Bedrock -object describes homogenous bedrock layer properties that are used in APES for calculating
 lower boundary conditions for soil heat balance equation.
 
 CONTAINS: class-dependent function Fourier_Homogenous: to solve temperature profile in Bedrock, HeatFlux: to obtain
 
  Samuli Launiainen METLA 14.11.2013


Methods for class Bedrock:

Bedrock             Fourier_Homogenous  HeatFlux     

