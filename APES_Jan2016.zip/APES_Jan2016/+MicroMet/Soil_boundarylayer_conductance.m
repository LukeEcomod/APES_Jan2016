    function [ga, scorr]=Soil_boundarylayer_conductance(z,zo,U,To,Ta)
        %soil surface aerodynamic conductance for heat and water vapor
        % Daamond & Simmons (1996); Baldocchi Biometeorology-notes

        rho=41.6;       %Density of air (mol/m3) at 20oC
        
        delta=5*9.81*z*(To-Ta)./((Ta+273.15).*U.^2);
        if delta>=0,
            a=-0.75;
        else
            a=-2;
        end
        scorr=max((1-delta).^a,0.2);
        rb=(log(z/zo))^2./(0.4^2*U).*scorr;
        ga=1./rb*rho; % mol m-2 s-1
        
    end