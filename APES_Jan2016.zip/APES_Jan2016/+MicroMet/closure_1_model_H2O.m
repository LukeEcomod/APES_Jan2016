function H2O=closure_1_model_H2O(z,Kc,H2Oref,Tref,P,Esource,Eg)
    %INPUT:
    %   z - vertical grid (m), evenly spaced
    %   Kc - eddy diffusivity (m2/s) for H2O
    %   H2Oref - H2O mixing ratio at highest gridpoint(mol mol-1)
    %   T - air temperature (degC)
    %   P - ambient pressure (Pa)
    %   Esource - H2O sink/source profile (mol m-3 s-1)
    %   Eg - H2O flux at lower boundary (mol m-2 (ground) s-1)
    %OUTPUT:
    %   H2O - H2O mixing ratio (mol mol-1)
    %NOTES:
    %   upper BC = fixed concentration
    %   lower BC = flux at ground
    %
    %Gaby Katul 2009, Samuli Launiainen 2012

    dz=z(2)-z(1); % vertical increment (m): need to be constant!
    N=length(z); % number or gridpoints

    rhoair=P./(287.05*(Tref+273.15)); % air density, kg/m3
    CF=rhoair./(29e-3); % molar consentration of air, mol/m3

    Eg=Eg/CF; % Lower boundary flux (mol m-2(ground) s-1) /(mol m-3) --> m s-1
    Esource=Esource/CF; % initial source profile (mol m-3 s-1) / (mol m-3) --> s-1. 
    
    %In ODE-solver, multiplying this by dz gives consistent units.

    %------Set up coefficients for ODE

    a1=Kc;
    a2(2:N)=diff(Kc)./dz;
    a2(1)=a2(2);
    a2=a2';
    a3=0*z;
    a4=-Esource;

    %------ Set the elements of the Tri-diagonal Matrix
    upd=(a1./(dz*dz)+a2./(2*dz));
    dia=(-a1.*2/(dz*dz)+a3);
    lod=(a1./(dz*dz)-a2./(2*dz));
    rhs=a4;

    %lower BC, flux-based
    lod(1)=0;
    dia(1)=1;
    upd(1)=-1;
    rhs(1)=Eg*dz/(Kc(1)+0.00001);

%     %lower BC, fixed concentration
%     upd(1)=0;
%     dia(1)=1;
%     lod(1)=0;
%     rhs(1)=lBC_value;
    
    %upper BC
    lod(N)=0;
    dia(N)=1;
    upd(N)=0;
    rhs(N)=H2Oref;

    %------Use the Thomas Algorithm to solve the tridiagonal matrix
    H2O=Thomas(lod,dia,upd,rhs);


    %% Tridiagonal solver
    function [q] = Thomas(aa,bb,cc,dd)
        % Tridiagonal solver. Solves equation CX=B, where C is tridiagonal matrix,
        % X solution vector and B constant vector of the linear system
        %
        % aa = sub diagonal of C
        % bb = main diagonal of C
        % cc = super diagonal of C
        % dd = constant vector of linear system
        % output q is the solution vector

        n=length(bb);
        bet=ones(n,1).*NaN;
        gam=ones(n,1).*NaN;
        q=ones(n,1).*NaN;

        bet(1)=bb(1);

        gam(1)=dd(1)/bb(1);

        for i=2:n
            bet(i)=bb(i)-(aa(i)*cc(i-1)/bet(i-1));
            gam(i)=(dd(i)-aa(i)*gam(i-1))/bet(i);
        end 

        q(n)=gam(n);

        for i=n-1:-1:1
           q(i)=gam(i)-(cc(i)*q(i+1)/bet(i));   
        end

    end
end
