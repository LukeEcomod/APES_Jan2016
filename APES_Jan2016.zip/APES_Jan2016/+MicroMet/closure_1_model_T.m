function T=closure_1_model_T(z,Kc,Tref,P,Hsource,Hg)
    %INPUT:
    %   z - vertical grid (m), evenly spaced
    %   Kc - eddy diffusivity (m2/s) for heat
    %   Tref - air temperature at highest gridpoint (degC)
    %   P - ambient pressure (Pa)
    %   Hsource - heat sink/source profile (J m-3 s-1 = W m-3)
    %   Hg - heat flux at lower boundary (J m-2 (ground) s-1 = W m-2(ground))
    %OUTPUT:
    %   T - air temperature profile (degC)
    %NOTES:
    %   upper BC = fixed temperature
    %   lower BC = flux at ground
    %
    %Gaby Katul 2009, Samuli Launiainen 2012

    dz=z(2)-z(1); % vertical increment (m): need to be constant!
    N=length(z); % number or gridpoints

    rhoair=P./(287.05*(Tref+273.15)); % air density, kg/m3
    cp=1004; %J kg-1 K-1
    CF=cp*rhoair; % (J kg-1 K-1)*(kg m-3) = J m-3 K-1

    Hg=Hg/CF; % Lower boundary flux (J m-2(ground) s-1) /(J m-3 K-1) --> K m s-1

    Hsource=Hsource/CF; % initial source profile (J m-3 s-1) / (J m-3 K-1) --> K s-1. In ODE-solver, multiplying this by dz gives consistent units.
    Hsource=smoothing(Hsource,10); %smooth slightly
    
    %------Set up coefficients for ODE

    a1=Kc;
    a2(2:N)=diff(Kc)./dz;
    a2(1)=a2(2);
    a2=a2';
    a3=0*z;
    a4=-Hsource;
    
    %------ Set the elements of the Tri-diagonal Matrix
    upd=(a1./(dz*dz)+a2./(2*dz));
    dia=(-a1.*2/(dz*dz)+a3);
    lod=(a1./(dz*dz)-a2./(2*dz));
    rhs=a4;
    
    %lower BC, flux-based
    lod(1)=0;
    dia(1)=1;
    upd(1)=-1;
    rhs(1)=Hg*dz/(Kc(1)+0.00001);

%     %lower BC, fixed concentration
%     upd(1)=0;
%     dia(1)=1;
%     lod(1)=0;
%     rhs(1)=lBC_value;
    
    %upper BC
    lod(N)=0;
    dia(N)=1;
    upd(N)=0;
    rhs(N)=Tref;

    %------Use the Thomas Algorithm to solve the tridiagonal matrix
    T=Thomas(lod,dia,upd,rhs);
    
    %T(1)=T(2);
%% Tridiagonal solver
    function [q] = Thomas(aa,bb,cc,dd)
        % Tridiagonal solver. Solves equation CX=B, where C is tridiagonal matrix,
        % X solution vector and B constant vector of the linear system
        %
        % aa = sub diagonal of C
        % bb = main diagonal of C
        % cc = super diagonal of C
        % dd = constant vector of linear system
        % output q is the solution vector

        n=length(bb);
        bet=ones(n,1).*NaN;
        gam=ones(n,1).*NaN;
        q=ones(n,1).*NaN;

        bet(1)=bb(1);

        gam(1)=dd(1)/bb(1);

        for i=2:n
            bet(i)=bb(i)-(aa(i)*cc(i-1)/bet(i-1));
            gam(i)=(dd(i)-aa(i)*gam(i-1))/bet(i);
        end 

        q(n)=gam(n);

        for i=n-1:-1:1
           q(i)=gam(i)-(cc(i)*q(i+1)/bet(i));   
        end
    end

%% smoothing
    function x = smoothing(y,ndp)
            n=length(y);
            B=ones(1,ndp)/ndp; 
            x=filter(B,1,y); % nn point running mean
            x(1:n-10)=x(10:n-1); % center back 
            x(n-10:n)=y(n-10:n);
    end
end
