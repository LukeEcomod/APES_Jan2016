function [tau,U,Km,l_mix,d,zo]=closure_1_model_U_dPdx (z,Cd, as, h, Ulow, Uhi,dPdx)
%function [tau,U,Km,l_mix,d,zo]=closure_1_model_U_dPdx (z,Cd, as, h, Ulow, Uhi,dPdx)
%
%Computes flow field etc. inside plant canopies using 1st order closure.
%Accounts for horizontal pressure gradient force dPdx
%
%IN:
%   z - height (m), constant increments!
%   Cd - drag coefficient (0.1-0.3)
%   as - plant area density (m2m-3)
%   h - canopy height (m)
%   Ulow - u*-normalized velocity at the ground (0.0 for no-slip)
%   Uhi - u*-normalized velocity at reference height
%   dPdx - u*-normalized horizontal pressure gradient (OPTIONAL)
%OUT:
%   tau - momentum flux 
%   U - mean wind speed (U/ustar) (-) 
%   Km - eddy diffusivity for momentum (m2s-1) 
%   l_mix - mixing length (m)
%   d - zero-plane displacement height (m)
%   zo - roughness lenght for momentum (m)
%
%Gaby Katul, Samuli Launiainen 2008-2015
    
    if nargin==6, dPdx=0; end
    
    dz=z(2)-z(1);
    N=length(z);
    U=linspace (Ulow,Uhi,N);
    U=U';
    nn1=floor(N/100)+1;
    %-------- Start iterative solution
    err=10^9;
    eps1=0.1;
    dPdx_m=0;
    
    while err>0.01

        Fd=Cd*as.*U.^2; % drag force
        d=sum(z.*Fd)/sum(Fd); % displacement height determined as a centroid of the drag force
        [l_mix]=mixing_length(h, d,z); % mixing length

        %-------- dU/dz
        y=our_central_diff(U,dz);
        %y=gradient_fwd(U,dz);
        %y=SmoothData(y,nn1);    
        %figure(1111);
        %plot(y,z,'r-'), pause

        %------Add model for diffusivity (Km)
        Km=((l_mix).^2).*abs(y);

        %Km=SmoothData(Km,nn1);
        tau=-Km.*y;

        %------Set up coefficients for ODE

        a1=-Km;
        a2=our_central_diff(-Km,dz);
        %a2=gradient_fwd(-Km,dz);
        a3=Cd*as.*U;
        dx=dz;

        %------ Set the elements of the Tri-diagonal Matrix
        upd=(a1./(dx*dx)+a2./(2*dx)); %upper diagonal
        dia=(-a1.*2/(dx*dx)+a3); %diagonal
        lod=(a1./(dx*dx)-a2./(2*dx)); %subdiagonal
        rhs=ones(1,N)*dPdx_m;

        %upper BC
        
        upd(N)=0;
        dia(N)=1;
        lod(N)=0;
        rhs(N)=Uhi;

        %lower BC
        upd(1)=0;
        dia(1)=1;
        lod(1)=0;
        rhs(1)=Ulow;

        %------Use the Thomas Algorithm to solve the tridiagonal matrix
        Un=Thomas(lod,dia,upd,rhs);
        %Un=SmoothData(Un,nn1);
        err=max(abs(Un-U));
      
        %-----Use successive relaxations in iterations
        U=(eps1*Un+(1-eps1)*U);
        dPdx_m=eps1*dPdx+(1-eps1)*dPdx_m;

%         figure(101);
%         subplot(221);plot(Un,z,'r-')
%         subplot(222);plot(y,z,'b-'); title('dUdz')
%         subplot(223);plot(l_mix,z,'r-')
%         subplot(224);plot(Km,z,'r-')    
    
    end
    %return values
    tau=tau/tau(N); %normalized momentum flux
    zo=(z(N)-d)*exp(-0.4*U(N)); %roughness length
    
    l_mix=mixing_length(h,d,z); %mixing length
    
    y=gradient_fwd(Un,dz);
    Kmr=l_mix.^2.*abs(y); %eddy diffusivity
    Km=SmoothData(Kmr,nn1);
    
%     figure(101);
%     subplot(221);plot(Un,z,'r-')
%     subplot(222);plot(y,z,'b-'); title('dUdz')
%     subplot(223);plot(l_mix,z,'r-')
%     subplot(224);plot(Km,z,'r-',Kmr,z,'k-'),

end

    function [l_mix]=mixing_length(h, d,z)
        %computes mixing length: linear above the canopy, constant within and
        %decreases linearly close the ground (below z< alpha*h/kv)

        dz=z(2)-z(1);
        kv=0.4; %von Karman

        alpha=(h-d)*kv/h;
        I_F=sign(z-h)+1;
        l_mix=alpha*h*(1-I_F/2)+(I_F/2).*(kv*(z-d));
        sc=(alpha*h)/kv;
        l_mix(z<sc)=kv*(z(z<sc)+dz/2);

        l_mix=l_mix + 0.4*0.2; % set finite value at ground
    end

    function [q] = Thomas(aa,bb,cc,dd)
        % Tridiagonal solver. Solves equation CX=B, where C is tridiagonal matrix,
        % X solution vector and B constant vector of the linear system
        %
        % aa = sub diagonal of C
        % bb = main diagonal of C
        % cc = super diagonal of C
        % dd = constant vector of linear system
        % output q is the solution vector

        n=length(bb);
        bet=ones(n,1).*NaN;
        gam=ones(n,1).*NaN;
        q=ones(n,1).*NaN;

        bet(1)=bb(1);

        gam(1)=dd(1)/bb(1);

        for i=2:n
            bet(i)=bb(i)-(aa(i)*cc(i-1)/bet(i-1));
            gam(i)=(dd(i)-aa(i)*gam(i-1))/bet(i);
        end 

        q(n)=gam(n);

        for i=n-1:-1:1
           q(i)=gam(i)-(cc(i)*q(i+1)/bet(i));   
        end

    end
    
    function [dydx] = gradient_fwd(y,dx)
       N=length(y);
       dydx=ones(N,1).*NaN;
       dydx(1:N-1)=diff(y)/dx;
       dydx(N)=dydx(N-1);
    end
    
    function [dydx]=our_central_diff(y,dx)
        %computes gradient with central difference method
        N=length(y);
        dydx=ones(size(y)).*NaN;
        %---------- use central difference for estimating derivatives
        dydx(2:N-1)=(y(3:N)-y(1:N-2))/(2*dx);
        %--------- use forward difference at lower boundary
        dydx(1)=(y(2)-y(1))/dx;
        
        %--------- use backward difference at upper boundary
        dydx(N)=(y(N)-y(N-1))/dx;
        %dydx(N)=dydx(N-1);
    end

    function yy = SmoothData(y, nn)
        %function yy = SmoothData(y,nn) returns "smoothed" vector yy using nn-point
        %moving filter
        %INPUT: y - vector to be smoothed
        %       nn - span (must be odd)
        %OUTPUT: yy - smoothed data
        %
        %Samuli Launiainen 17.3.2014

        K=length(y);
        yy=ones(K,1).*NaN;

        dn=(nn-1)/2;

        %first elements
        yy(1)=y(1);
        for k=2:dn,
            yy(k)=sum(y(1:k))/(2*k-1);
        end

        %last elements
        for k=K-dn:K
            yy(k)=sum(y(k:K))/(K-k+1);
        end
        %middle
        for k=(dn+1):1:(K-dn)
            yy(k)=sum(y(k-dn:k+dn))/nn;
        end
    end
    