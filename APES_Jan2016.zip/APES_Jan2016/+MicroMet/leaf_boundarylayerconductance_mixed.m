function [gb_h,gb_v,gb_c,gb_O3]=leaf_boundarylayerconductance_mixed(U,lt,T,dT)
%
% Computes 2-sided leaf boundary layer conductance assuming mixed forced and free
% convection form two parallel pathways for transport through leaf boundary layer. 
% 
%INPUT: U - mean velocity (m/s)
%       lt - characteristic dimension of the leaf in parallell to wind
%       T - ambient temperature (degC)
%       dT - temperature difference between leaf and air (degC)
%OUTPUT: boundary-layer conductances (mol m-2 s-1)
%
%Reference: Campbell, S.C., and J.M. Norman (1998), 
%An introduction to Environmental Biophysics, Springer, 2nd edition, Ch. 7

%Gaby Katul & Samuli Launiainen

    grav=9.81;      %Acceleration due to gravity (m/s2)
    rho=41.6;       %Density of air (mol/m3) at 20oC
    mu=15.1e-6;     %kinematic Viscosity of air at 20oC [m2/s]

    D_H=21.4e-6;    %Thermal diffusivity of air 20oC [m2/s]
    D_c=15.7e-6;    %Molecular diffusivity of CO2 in air at 20oC [m2/s]
    D_v=24.0e-6;     %Molecular diffusivity of water vapor in air at 20oC [m2/s]
    D_O3=14.4e-6;   %Molecular diffusivity of O3 in air at 20 oC [m2/s]

    Pr=mu/D_H;             %Prandtl number
    Re=lt.*(U+eps)/mu;      %Reynolds number
    Sc_c=mu/D_c;            % Schmidt numbers
    Sc_v=mu/D_v;
    Sc_O3=mu/D_O3;

    Gr=grav*lt.^3.*abs(dT)./((T+273.15).*mu.^2); % Grashoff number (ratio of buyoant force times inertial force to the square of viscous force)

    %--------- conductance for heat ----------------

    gb_hfo=(0.664*rho*D_H*Pr^(1/3))*(Re.^(1/2))./(lt+eps); %laminar forced convection molm-2s-1
    gb_hfr=0.54*rho*D_H*(Gr.*Pr).^(1/4)./(lt+eps); % free convection molm-2s-1

    gb_h=2*gb_hfo + 1.5*gb_hfr; % conductors in parallel
    %factor 2 accounts for upper and lower sides of leaf, factor 1.5 is since
    %convection from cooler surface facing up or hotter facing down is ~0.5
    %times that of free convection (Campbell and Norman, 1998)

    %---------- conductance for CO2
    gb_cfo=0.664*rho*D_c*Sc_c^(1/3)*(Re.^(1/2))./(lt+eps);
    gb_cfr=0.54*rho*D_c*(Gr*Sc_c).^(1/4)./(lt+eps); % free convection molm-2s-1

    gb_c=2*gb_cfo + 1.5*gb_cfr; % conductors in parallel
    %---------- conductance for H2O
    gb_vfo=0.664*rho*D_v*Sc_v^(1/3)*(Re.^(1/2))./(lt+eps);
    gb_vfr=0.54*rho*D_v*(Gr*Sc_v).^(1/4)./(lt+eps); % free convection molm-2s-1

    gb_v=2*gb_vfo + 1.5*gb_vfr; % conductors in parallel
    %---------- conductance for O3
    gb_O3fo=0.664*rho*D_O3*Sc_O3^(1/3)*(Re.^(1/2))./(lt+eps); %laminar forced convection molm-2s-1
    gb_O3fr=0.54*rho*D_O3*(Gr*Sc_O3).^(1/4)./(lt+eps); % free convection molm-2s-1

    gb_O3=2*gb_O3fo + 1.5*gb_O3fr; % conductors in parallel

end
