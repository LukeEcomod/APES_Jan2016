    function [tau,U,Km]=closure_1_model_U (z,l_mix,Cd, as, Ulow, Uhi)
    % solves stress, mean wind speed and eddy diffusivity profiles for given
    % boundary conditions and l_mix
    %
    %IN:
    %   z - vertical grid (m)
    %   l_mix - mixing length(m)
    %   Cd - drag coefficient (-)
    %   as - frontal plant area density (m2m-3)
    %   Ulow - lower BC, U/ustar
    %   Uhi - upper BC, U/ustar
    %OUT:
    %   tau - normalized (tau/tau(N)) Reynold's stress
    %   U - normalized mean wind speed (U/ustar)
    %   Km - eddy diffusivity for momentum (m2s-1)
    %

        dz=z(2)-z(1);
        N=length(z);
        U=linspace (Ulow,Uhi,N);

        %-------- Start iterative solution
        err=10^9;

        while err>0.0001

        %-------- y=dU/dz
        y=[];
        y(2:N)=diff(U)./dz;
        y(1)=y(2);

        %------Add model for diffusivity (Km)
        Km=((l_mix).^2).*abs(y);
        tau=-Km.*y; % momentum flux at each height

        %------Set up coefficients for ODE

        a1=-Km;
        a2(2:N)=-diff(Km)./dz;
        a2(1)=a2(2);
        a3=Cd*as.*U;
        dx=dz;

        %------ Set the elements of the Tri-diagonal Matrix
        upd=(a1./(dx*dx)+a2./(2*dx));
        dia=(-a1.*2/(dx*dx)+a3);
        lod=(a1./(dx*dx)-a2./(2*dx));
        rhs=ones(1,N)*0;

        %lower BC
        lod(1)=0;
        dia(1)=1;
        upd(1)=0;
        rhs(1)=Ulow;

        %upper BC
        lod(N)=0;
        dia(N)=1;
        upd(N)=0;
        rhs(N)=Uhi;


        %------Use the Thomas Algorithm to solve the tridiagonal matrix
        Un=Thomas(lod,dia,upd,rhs);
        err=max(abs(Un-U));

        %-----Use successive relaxations in iterations
        eps1=0.5;
        U=(eps1*Un+(1-eps1)*U);
        end
    end