classdef MixingLengthFunctions
    %Collections of mixing-length functions. Not tested
    %
    %Samuli Launiainen, 24.2.2015
    properties
    end
    
    methods
        function obj=MixingLengthFunctions()
            obj;
        end
    end
    
    methods (Static)
        
        function [l_mix]=mixing_length_Huang2014(z,h,d,as,Cd)
            %IN:z (m)
            %   h (m)
            %   d (m)
            %   as (m2m-3)
            %   Cd (-)
            %OUT: l_mix (m)
            
            beta=0.3; %attn coeff (-)
            kv=0.4; % von Karman const (-)
            Lc=(Cd.*as).^(-1); % adjustment length scale (m)
            
            zf=6;
            zv=0.7;
            
            nn=length(z);
            l_mix=zeros(nn,1);
            
            f=find(z>=h);
            %l_mix(f)=kv*(z(f)-d); clear f
            l_mix(f)=kv*z(f);
            %l_mix(z>h)=kv*(z(z>h)-d); %above canopy
            
            f=find(z>=zf & z< zf + (h-zf)/2);
            l_mix(f) = min(2*beta^3*Lc(f), kv*(h-d)); clear f
            
            f=find(z>=(zf + (h-zf)/2) & z<h);
            l_mix(f) = min(2*beta^3*Lc(f), kv*z(f)); clear f
            
            f=find(z>=zv & z<zf);
            l_mix(f)=kv*z(f); clear f
            
            f=find(z<zv);
            l_mix(f)=kv*zv; clear f
            
            l_mix=smoothing(l_mix,20);
        end
        
        function [l_mix]=mixing_length(z,h,d)
            %computes mixing length within and above canopies.
            %Linear above the canopy, constant within and linear close the ground (below z< alpha*h/kv)
            %INPUT: z - vertical grid (m)
            %       h - canopy height (m)
            %       d - displacement height (m)
            
            kv=0.4;
            %dldz=[];l_mix1=[];
            m=length(z);
            alpha=(h-d)*kv/h;
            I_F=sign(z-h)+1;
            l_mix=alpha*h*(1-I_F/2)+(I_F/2).*(kv*(z-d));
            sc=(alpha*h)/kv;
            %l_mix1(z<sc)=kv*(z(z<sc)+dz/2);
            l_mix(z<=sc)=alpha*h - 0.9.*alpha*h*(sc-z(z<=sc))/sc;
            
            
            figure(2)
            plot(l_mix,z, 'r-'),pause
        end
        
        function [l_mix]=mixing_length_alpha(z,h,alpha)
            
            I_F=sign(z-h)+1;
            l_mix=alpha*h*(1-I_F/2)+(I_F/2).*(0.4*(z-h)+alpha*h);
            
            figure()
            plot(l_mix,z/h,'r-')
        end
        
        function [l_mix]=mixing_length_Mahrt(z,h,d)
            
            b=0.4*(1- (d/h)/(2-d/h)); %Lee and Mahrt, 2005 AFM
            l_mix(z<h)= b*z(z<h);
            f=find(z>=h);
            l_mix(f)=l_mix(min(f)-1) + 0.4*(z(f)-h);
            l_mix=l_mix' +0.05;
            
            figure()
            plot(l_mix,z/h,'r-')
        end
    end
    
end

