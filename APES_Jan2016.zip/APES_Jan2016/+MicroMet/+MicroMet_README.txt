*********************************************

Samuli Launiainen, Luke 24.2.2015

samuli.launiainen@luke.fi
*********************************************
Used as part of APES -model

Package '+MicroMet' contains Matlab-codes for:

1) computing 1-dimensional momentum & scalar transfer within plant canopies.

2) general micrometeorological functions

