function [U,Kmn,uw,d,zo,l_mix] = generate_flow(za,pad,h,Cd,Utop,Ulow,dPdx)
% function [U,Kmn,uw,d,zo,l_mix]  = generate_flow(za,pad,h,Cd,Utop,Ulow,dPdx)
% generates mean wind speed (U) and eddy diffusivity (for momentum, Kmn)
% profiles for near-neutral stratification
%
%INPUT: 
%   za - height vector (m)
%   pad - plant area density (m2/m3)
%   h - canopy height (m)
%   Cd - drag coefficient for momentum (scalar)
%   Utop - U/ustar at highest gridpoint
%   Ulow - U/ustar at lowest gridpoint
%   dPdx - ustar-normalized horizontal pressure gradient force (OPTIONAL)
%
%OUTPUT:
%   U - mean wind speed profile (m/s)
%   Kmn - eddy diffusivity for momentum (m2/s)
%   d - zero-plane displacement height (m), as centroid of drag force
%   zo - roughness length for momentum (m)
%   l_mix - mixing length (m)
%
%USES:
%   closure_1_model_dPdx
%
% Gaby Katul -2010, Samuli Launiainen 2012-2015
%LAST EDIT 24.2.2015
%----------------------------------------------------------------------
import MicroMet.closure_1_model_U_dPdx

if nargin==6, dPdx=0; end

as=0.5*pad; % frontal plant area density (m2/m3); assumed half of one-sided pad
LAIm=sum(as).*abs((za(2)-za(1))); % total plant area index (m2m-2)

%---- Generate computational grid

N=2000;
zmax=max(za);
zmin=min(za);
dz=(zmax-zmin)/(N-1);
z=[zmin:dz:zmax]';

% interpolated LAD-profile to computational grid
a=interp1(za,as,z);
LAI_temp=sum(a)*dz;
lad=(LAIm*a/LAI_temp); % plant-area profile, gives LAI_m when integrated

%Utop=5.0850;   % u*-normalized measured velocity at the highest gridpoint (near-neutral)
Uhi=1.01*Utop; % upper boundary condition
%Ulow=0.0; % no-slip      % 
%Ulow=0.01*Utop; % flow at lower boundary


%call 1st order closure model
[uw_MOD,Un_MOD,Kmn_MOD,l_mix_MOD,d,zo]=closure_1_model_U_dPdx(z,Cd, lad, h, Ulow, Uhi,dPdx);

%% return in asked grid (za)
 
U=interp1(z,Un_MOD,za);
Kmn=interp1(z,Kmn_MOD,za);
uw=interp1(z,uw_MOD,za);
l_mix=interp1(z,l_mix_MOD,za);

end

% %
% % [l_mix_MOD1]=mixing_length(z,h,d); % mixing length lin-const-lin
% % [uw_MOD,Un_MOD,Kmn_MOD]=closure_1_model_U(z,l_mix_MOD1,Cd, lad, Ulow, Uhi);
% 
% 
% % [l_mix_MOD]=mixing_length_alpha(z,h,d,0.13); % mixing length const below d
% % [uw_MOD,Un_MOD,Kmn_MOD]=closure_1_model_U(z,l_mix_MOD,Cd, lad, Ulow, Uhi);
% % % 
% % [l_mix_MOD]=mixing_length_SMEAR(z,h,d); % mixing length "smear"
% % [uw_MOD,Un_MOD,Kmn_MOD]=closure_1_model_U(z,l_mix_MOD,Cd, lad, Ulow, Uhi);
% % % 
% % [l_mix_MOD]=mixing_length_Mahrt(z,h,d); % mixing length is linear
% % [uw_MOD,Un_MOD,Kmn_MOD]=closure_1_model_U(z,l_mix_MOD,Cd, lad, Ulow, Uhi);
% % % 
% % %[tau,U,Km,l_mix,d,zo]=closure_1_model_U_displacement (z,Cd, lad, h, Ulow, Uhi);
% % [tau,U,Km,l_mix,d,zo]=closure_1_model_U_Huang2014(z,Cd, lad, h, Ulow, Uhi);
% % % 
% % figure(1);
% % subplot(221); plot(l_mix_MOD/h,z/h,'r-',l_mix_MOD1/h,z/h,'g-',l_mix_MOD2/h,z/h,'b-',l_mix_MOD4/h,z/h,'r:',l_mix/h,z/h,'k:'); title('l_m')
% % subplot(222); plot(Un_MOD,z,'r-',Un_MOD1,z,'g-',Un_MOD2,z,'b-',Un_MOD4,z,'r:',U,z,'k:'); title('U')
% % subplot(223); plot(Kmn_MOD,z,'r-',Kmn_MOD1,z,'g-',Kmn_MOD2,z,'b-',Kmn_MOD4,z,'r:',Km,z,'k:'); title('K_m')
% % legend('tuned for smear II','lin-const-lin','lin-const','Lee&Mahrt04','dynamic')
% % pause
% 
% 
% %% Internal function definitions: INCLUDES mixing_length and closure_1_model_U
% 
%     function [l_mix]=mixing_length(z,h,d)
%         %computes mixing length within and above canopies.
%         %Linear above the canopy, constant within and linear close the ground (below z< alpha*h/kv)
%         %INPUT: z - vertical grid (m)
%         %       h - canopy height (m)
%         %       d - displacement height (m)
%         dz=z(2)-z(1);
%         kv=0.4;
%         %dldz=[];l_mix1=[];
%         m=length(z);
%         nn=floor(m/11);
% 
%         alpha=(h-d)*kv/h;
%         I_F=sign(z-h)+1;
%         l_mix=alpha*h*(1-I_F/2)+(I_F/2).*(kv*(z-d));
%         sc=(alpha*h)/kv;
%         %l_mix1(z<sc)=kv*(z(z<sc)+dz/2);
%         l_mix(z<=sc)=alpha*h - 0.9.*alpha*h*(sc-z(z<=sc))/sc;
% 
% 
%         figure(2)
%         plot(l_mix,z, 'r-'),pause
%     end
% 
%     function [l_mix]=mixing_length_alpha(z,h,d,alpha)
%         dz=z(2)-z(1);
%         I_F=sign(z-h)+1;
%         l_mix=alpha*h*(1-I_F/2)+(I_F/2).*(0.4*(z-h)+alpha*h);
%         figure()
%         plot(l_mix,z/h,'r-'), pause
%     end
% 
%     function [l_mix]=mixing_length_Mahrt(z,h,d)
%         
%         b=0.4*(1- (d/h)/(2-d/h)); %Lee and Mahrt, 2005 AFM
%         l_mix(z<h)= b*z(z<h);
%         f=find(z>=h);
%         l_mix(f)=l_mix(min(f)-1) + 0.4*(z(f)-h);
%         l_mix=l_mix' +0.05;
% % 
%         figure()
%         plot(l_mix,z/h,'r-')
%     end
% 
%     function [tau,U,Km]=closure_1_model_U(z,l_mix,Cd, as, Ulow, Uhi)
%     % solves Reynols stress, mean wind speed and eddy diffusivity profiles for given
%     % boundary conditions and l_mix
%     %
%     %IN:
%     %   z - vertical grid (m)
%     %   l_mix - mixing length (m)
%     %   Cd - drag coefficient (-)
%     %   as - frontal plant-area density (m2m-3)
%     %   Ulow - lower BC, U/ustar (-)
%     %   Uhi - upper BC, U/ustar (-)
% 
%         dz=z(2)-z(1);
%         N=length(z);
%         U=linspace (Ulow,Uhi,N);
%         U=U';
% 
%         %-------- Start iterative solution
%         err=10^9;
%         eps1=0.5;
%         
%         while err>0.0001
% 
%         %-------- dU/dz ----------
% 
%         dU=zeros(N,1);
%         dU(2:N)=diff(U)./dz;
%         dU(1)=dU(2);
% 
%         %------Add model for diffusivity (Km)
%         Km=((l_mix).^2).*abs(dU);
%         %Km=smoothing(Km,10);
%         tau=-Km.*dU; % momentum flux at each height
% 
%         %------Set up coefficients for ODE
% 
%         a1=-Km;
%         a2=zeros(N,1);
%         
%         a2(2:N)=-diff(Km)./dz;
%         a2(1)=a2(2);
%         a3=Cd*as.*U;
% 
%         %------ Set the elements of the Tri-diagonal Matrix
%         upd=(a1./(dz*dz)+a2./(2*dz));
%         dia=(-a1.*2/(dz*dz)+a3);
%         lod=(a1./(dz*dz)-a2./(2*dz));
%         rhs=ones(1,N)*0; %lhs
%         
%         %lower BC
%         lod(1)=0;  
%         dia(1)=1;
%         upd(1)=0;        
%         rhs(1)=Ulow;
%         
%         %upper BC
%         lod(N)=0;
%         dia(N)=1;
%         upd(N)=0;
%         rhs(N)=Uhi;
% 
%         %------Use the Thomas Algorithm to solve the tridiagonal matrix
%         Un=Thomas(lod,dia,upd,rhs);
%         err=max(abs(Un-U));
% 
%         %-----Use successive relaxations in iterations
%         U=(eps1*Un+(1-eps1)*U);
%         end
%     end
% 
%     function [q] = Thomas(aa,bb,cc,dd)
%         % Tridiagonal solver. Solves equation CX=B, where C is tridiagonal matrix,
%         % X solution vector and B constant vector of the linear system
%         %
%         % aa = sub diagonal of C
%         % bb = main diagonal of C
%         % cc = super diagonal of C
%         % dd = constant vector of linear system
%         % output q is the solution vector
% 
%         n=length(bb);
%         bet=ones(n,1).*NaN;
%         gam=ones(n,1).*NaN;
%         q=ones(n,1).*NaN;
% 
%         bet(1)=bb(1);
% 
%         gam(1)=dd(1)/bb(1);
% 
%         for i=2:n
%             bet(i)=bb(i)-(aa(i)*cc(i-1)/bet(i-1));
%             gam(i)=(dd(i)-aa(i)*gam(i-1))/bet(i);
%         end 
% 
%         q(n)=gam(n);
% 
%         for i=n-1:-1:1
%            q(i)=gam(i)-(cc(i)*q(i+1)/bet(i));   
%         end
% 
%     end
% 
%     function [dydx]=our_central_diff(y,dx)
%         %computes gradient with central difference method
%         N=length(y);
%         dydx=[];
%         %---------- use central difference for estimating derivatives
%         dydx(2:N-1)=(y(3:N)-y(1:N-2))/(2*dx);
%         %--------- use forward difference at lower boundary
%         dydx(1)=(y(2)-y(1))/dx;
%         %--------- use backward difference at upper boundary
%         dydx(N)=(y(N)-y(N-1))/dx;
%     end
% 
%     function x = smoothing(y,ndp)
%             n=length(y);
%             B=ones(1,ndp)/ndp; 
%             x=filter(B,1,y); % nn point running mean
%             x(1:n-10)=x(10:n-1); % center back 
%             x(n-10:n)=y(n-10:n);
%     end
            


