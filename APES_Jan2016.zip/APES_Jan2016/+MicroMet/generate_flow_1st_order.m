function [U,Kmn,uw,l_mix] = generate_flow_1st_order(za,as,h,d,Cd,Utop,Ulow)
% function [U,Kmn] = generate_flowfield(za,as,h,d,Cd)
% generates mean wind speed (U) and eddy diffusivity (for momentum, Kmn)
% profiles for near-neutral stratification
%
%INPUT:
%   za - height vector (m)
%   as - plant area density (m2/m3)
%   h - canopy height (m)
%   d - displacement height (m)
%   Cd - drag coefficient for momentum (scalar)
%
%   Utop - U/ustar at highest gridpoint
%   Ulow - U/ustar at lowest gridpoint
%
%OUTPUT:
%   U - mean wind speed profile (m/s)
%   Kmn - eddy diffusivity for momentum (m2/s)
%   uw - normalized Reynolds stress profile (-)
%   l_mix - mixing length (m)
%
%INCLUDES: Internal functions: mixing_length and closure_1_model_U
%USES: Thomas.m (tri-diagonal solver)
%
% Gaby Katul -2010, Samuli Launiainen 2012
%----------------------------------------------------------------------
as=0.5*as; %frontal plant-area density ~half of 1-sided

%---- Generate computational grid

N=2000;
zmax=max(za);
zmin=min(za);
LAIm=sum(as).*abs((za(2)-za(1))); % total leaf area
dz=(zmax-zmin)/(N-1);
z=[zmin:dz:zmax];

% interpolated LAD-profile to computational grid

a=interp1(za,as,z);
LAI_temp=sum(a)*dz;
LAD=(LAIm*a/LAI_temp); % Leaf-area profile, gives LAI_m when integrated
a=LAD;

%Untop=5.0850;   % normalized measured velocity at the highest gridpoint (near-neutral)
Uhi=1.01*Utop; % upper boundary condition
%Ulow=0.0;       % no-slip
%Ulow=0.05; % flow at lower boundary
[l_mix_MOD]=mixing_length(z,h,d);

[uw_MOD,Un_MOD,Kmn_MOD]=closure_1_model_U (z,l_mix_MOD,Cd, a, Ulow, Uhi);

%% return in asked grid (za)
%
U=interp1(z,Un_MOD,za);
uw=interp1(z,uw_MOD,za);
Kmn=interp1(z,Kmn_MOD,za);
l_mix=interp1(z,l_mix_MOD,za);


%% Internal function definitions: INCLUDES mixing_length and closure_1_model_U

    function [l_mix]=mixing_length(h, d,z)
        %computes mixing length: linear above the canopy, constant within and
        %decreases linearly close the ground (below z< alpha*h/kv)
        dz=z(2)-z(1);
        kv=0.4;
        
        alpha=(h-d)*kv/h;
        I_F=sign(z-h)+1;
        l_mix=alpha*h*(1-I_F/2)+(I_F/2).*(kv*(z-d));
        sc=(alpha*h)/kv;
        l_mix(z<sc)=kv*(z(z<sc)+dz/2);
        
        l_mix=l_mix + 0.4*0.2; % set finite value at ground
    end



    function [tau,U,Km]=closure_1_model_U (z,l_mix,Cd, as, Ulow, Uhi)
        % solves stress, mean wind speed and eddy diffusivity profiles for given
        % boundary conditions and l_mix
        %
        %IN:
        %   z - vertical grid (m)
        %   l_mix - mixing length(m)
        %   Cd - drag coefficient (-)
        %   as - frontal plant area density (m2m-3)
        %   Ulow - lower BC, U/ustar
        %   Uhi - upper BC, U/ustar
        %OUT:
        %   tau - normalized (tau/tau(N)) Reynold's stress
        %   U - normalized mean wind speed (U/ustar)
        %   Km - eddy diffusivity for momentum (m2s-1)
        %
        
        dz=z(2)-z(1);
        N=length(z);
        U=linspace (Ulow,Uhi,N);
        
        %-------- Start iterative solution
        err=10^9;
        
        while err>0.0001
            
            %-------- y=dU/dz
            y=[];
            y(2:N)=diff(U)./dz;
            y(1)=y(2);
            
            %------Add model for diffusivity (Km)
            Km=((l_mix).^2).*abs(y);
            tau=-Km.*y; % momentum flux at each height
            
            %------Set up coefficients for ODE
            
            a1=-Km;
            a2(2:N)=-diff(Km)./dz;
            a2(1)=a2(2);
            a3=Cd*as.*U;
            dx=dz;
            
            %------ Set the elements of the Tri-diagonal Matrix
            upd=(a1./(dx*dx)+a2./(2*dx));
            dia=(-a1.*2/(dx*dx)+a3);
            lod=(a1./(dx*dx)-a2./(2*dx));
            rhs=ones(1,N)*0;
            
            %lower BC
            lod(1)=0;
            dia(1)=1;
            upd(1)=0;
            rhs(1)=Ulow;
            
            %upper BC
            lod(N)=0;
            dia(N)=1;
            upd(N)=0;
            rhs(N)=Uhi;
            
            
            %------Use the Thomas Algorithm to solve the tridiagonal matrix
            Un=Thomas(lod,dia,upd,rhs);
            err=max(abs(Un-U));
            
            %-----Use successive relaxations in iterations
            eps1=0.5;
            U=(eps1*Un+(1-eps1)*U);
        end
    end

    function [q] = Thomas(aa,bb,cc,dd)
        % Tridiagonal solver. Solves equation CX=B, where C is tridiagonal matrix,
        % X solution vector and B constant vector of the linear system
        %
        % aa = sub diagonal of C
        % bb = main diagonal of C
        % cc = super diagonal of C
        % dd = constant vector of linear system
        % output q is the solution vector

        bet(1)=bb(1);

        gam(1)=dd(1)/bb(1);

        n=length(bb);

        for i=2:n

            bet(i)=bb(i)-(aa(i)*cc(i-1)/bet(i-1));

            gam(i)=(dd(i)-aa(i)*gam(i-1))/bet(i);

        end

        q(n)=gam(n);

        for i=n-1:-1:1

            q(i)=gam(i)-(cc(i)*q(i+1)/bet(i));

        end
    end

end
