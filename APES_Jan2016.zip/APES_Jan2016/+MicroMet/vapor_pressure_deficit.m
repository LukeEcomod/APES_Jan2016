function [VPD]=vapor_pressure_deficit (T, RH);
% ---------------------------------------------constants
a = 0.611; %kPa
b = 17.502; %unitless
c = 240.97 ;%C

esa = a .* exp((b.*T)./(T + c)); %Kpa
ea=(RH/100).*esa;
VPD = (esa-ea); %KPa