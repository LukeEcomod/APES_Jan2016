function [gb_c,gb_v,gb_h,gb_O3]=boundary_layer_conductance (U,lt)
%function:  [rb_c,rb_v,rb_h,rb_O3]=boundary_layer_conductance (U,lt)
%
%Purpose: Computes the laminar boundary layer resistance on leaves in units m2 s/mol 
%for CO2 (rb_c), H2O (rb_v) and O3 (rb_O3) and m2 s/mol of air for heat (rb_h) assuming 
%laminar forced convection. Formulation assumes that the Reynolds number 
%Re is below a critical transition value of 5 x 10^5 for a smooth flat plate.
%
%INPUT: U = mean velocity (m/s)
%       lt = length of the laminar flat plate (m) ~characteristic dimension
%       of the leaf
%      ~ diameter of needles for pines when flow is orthogonal to needle
%        length
%OUTPUT: Boundary-layer resistances in units m2 s/mol 
%Reference: Campbell, S.C., and J.M. Norman (1998), 
%An introduction to Environmental Biophysics, Springer, 2nd edition, p.101

% Gaby Katul, 2010.

% Define units / constants (Campbell & Norman, 1998)

rho=41.6;       %Density of air (mol/m3) at 20oC
mu=15.1e-6;     %Viscosity of air at 20oC [m2/s]

D_H=21.4e-6;    %Thermal diffusivity of air 20oC [m2/s]
D_c=15.7e-6;    %Molecular diffusivity of CO2 in air at 20oC [m2/s]
D_v=24.0e-6;     %Molecular diffusivity of water vapor in air at 20oC [m2/s]
D_O3=14.4e-6;   %Molecular diffusivity of O3 in air at 20 oC [m2/s]

Pr=mu/D_H;             %Prandtl number
Re=lt.*(U+eps)/mu;      %Reynolds number


%---------- conductance and resistance for CO2
gb_c=0.664*rho*D_c*Pr^(1/3)*(Re.^(1/2))./(lt+eps);
%rb_c=1./(gb_c+eps);

%---------- conductance and resistance for H2O
gb_v=0.664*rho*D_v*Pr^(1/3)*(Re.^(1/2))./(lt+eps);
%rb_v=1./(gb_v+eps);

%---------- conductance and resistance for Heat
gb_h=(0.664*rho*D_H*Pr^(1/3))*(Re.^(1/2))./(lt+eps);
%rb_h=1./gb_h;

%---------- conductance and resistance for O3
gb_O3=0.664*rho*D_O3*Pr^(1/3)*(Re.^(1/2))./(lt+eps);
%rb_O3=1./gb_O3;
