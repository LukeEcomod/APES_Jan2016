function [h,Wliq,Wice,CumIn,CumEvap,CumDrain,Roff,h_pond,FL, KLh, MaxEva, RHsoil, GWL, MBE,topBCh]...
    =Soil_WaterFlow(PRF,t_final,dto,So,HFo,q_top,h_atm,lBCh,lBCtype)
%
% Solves water transport in 1-D in variably saturated soils and in above
% and below-zero temperatures using Richard's equation solved by fully
% implicit scheme (van Dam and Feddes (2000), J. Hydrol. 233,p. 72-85.). 
% Boundary conditions are here formulated always as flux-based while their 
% respective values can vary during calculation.
%
%
% INPUT:
%   PRF - soil profile object
%   t_final - final time of solution (s)
%   dto - initial time step (s)
%	Column vectors of N x 1:
    %   So - Liquid water sink/source term (m3/m3/s = 1/s), e.g. root uptake
    %   HFo - horizontal water flux (1/s), e.g. horizontal drainage
    %   q_top - potential water flux to (-, throughfall/condensation to the soil surface) or from the surface (+, evaporation) (m/s)
    %   h_atm - pressure head with equilibrium to atm. humidity and temperature (m)
    %   lBCh - Richards equation lower boundary condition [q_bot (m/s), downward flux is negative] or [h_bot (m)] for prescribed head at fictious node N+1
    %   lBCtype - boundary condition type [1=flux + gravity, 0=prescribed
    %   value at i=N+1, -1=impermeable boundary]. These are converted to flux-based for implementation of numerical algorithm!
%
% OUTPUT: 
%   Column vectors of N x 1
    %   h - pressure head (m) at t_final 
    %   Wliq - volumetric liquid water content (m3/m3)
    %   Wice - volumetric ice content (m3/m3)
    %   CumIn - Cumulative infiltration (m)
    %   CumEvap - Cumulative evaporation (m)
    %   CumRoff - Cumulative surface runoff (m)
    %   CumDrain - Cumulative drainage (m)
    %   h_pond - depth of ponded water at surface (m)
    %   FL=[FLh FLT Fvh FvT] - vertical water fluxes (m/s) isothermal and thermal liquid and vapor fluxes 
    %   MaxEva - maximum evaporation rate (m/s) based on soil supply
    %   RHsoil - top soil relative humidity (-)
    %   MBE - mass balance error (mm)
%
% USES: 
    %  SoilProfile (static) methods defined in Clasdef -file: 
    %   HydraulicConductivities.m 
    %   SpatialAverage.m
% NOTE:
    %   USES ad-hoc assumption for macropore flow in wet conditions (h<-1m, i.e. above field capacity)
    %   In cases top layer Ksat is order or magnitude smaller than in lower
    %   layers, Ksmacro need to be included to cope infiltration!
% Samuli Launiainen, Metla 7/2011 - 4/2012
    
%% ------------------ constants--------------------------------------------

    GasConst=8.314; % universal gas constant, Jmol-1
    Mwater=18.015e-3; % molar mass of water, kg mol-1
    grav=9.81; % acceleration due gravity, kgm/s2
    rhow=1000; %water density, kg/m3
    rhoi=917;  %ice density, kg/m3
    % Lf=333700; % latent heat of freezing, J/kg; % Lv is latent heat of vaportization
    %cosalfa=0; % cosine of flow angle, 1=vertical, 0 = horizontal
    % rhoa=1.25; % density of air (kg/m3)
    % ca=1297; %specific heat capacity of air (J/kg/K)
    % cw=4.18e6; %specific heat capacity of water (J/kg/K)
    % ci=1.9e6;  %specific heat capacity of ice (J/kg/K)
    %T0=0; % freezing point of water (degC)
    
    NT=273.15; 
    
    % %not needed if more sophisticated equation is used for Wliq=f(T,Wice)
    fp=PRF.FreezingCurvePara; %  parameter of freezing curve, fp = 2..4 clay soils,  0.5..1.5 sandy soils... (Femma-code / Koivusalo)


    %% -------------Get grid and make local copy of soil description from PRF -------------

    z=PRF.zs;
    N=length(z); % nr of nodal points, N is deepest node

    %distances between grid points: dzu is between point i-1 and i, dzl between point i and i+1
    dzu(2:N)=z(1:N-1) - z(2:N); dzu(1)=-z(1); 
    dzl(1:N-1)=z(1:N-1) - z(2:N); dzl(N)=(z(N-1) - z(N))/2;

    %layer thicknesses
    dz=dzu/2 + dzl/2; 
    dz(1)=dzu(1) + dzl(1)/2;
    
    cosalfa=PRF.cosalfa;
    MaxPond=PRF.MaxPondDepth;

    pF=PRF.pF; %ThetaSat (m3/m3),ThetaRes (m3/m3),alfa(-),n(-),m,Kzsat(m/s)
%     Wsat=pF(:,1);
%     Wres=pF(:,2);
    
    Ksat=PRF.Ksat; %saturated hydraulic conductivity (m/s)
    poros=PRF.porosity; % soil porosity (m3/m3) ~== saturated water content 

    vClay=PRF.vClay; % volume fraction of clay (-)
    vOrganic=PRF.vOrganic; % volume fraction of organic material(-)
    GwT=PRF.GwT;% gain factor (-), temperature dependency of pF -curve (order of 7 for sand)

    Kmacro=PRF.Kmacro; % macropore conductivity when Wliq=Wsat

    %% -------initial & boundary conditions

    T=PRF.T; %degC
    h=PRF.h; % m
    Wliq=PRF.Wliq; % m3/m3
    Wice=PRF.Wice; % m3/m3

    h_pond=PRF.h_pond; % initial pond depth (m)
    S=So; % 1/s sink/source term of Richards
    Rsink=sum(So.*dz');
    HM=HFo; % m/s, horizontal moisture flux (drainage)
    %FLh=zeros(N,1);
    
    botBCh=lBCtype;

    Conv_crit1= 0.001; % Wliq (m3/m3)
   
    %% -------- find solution at t_final ------------------------

    dt=dto; % initial time step [s]
    t=0; %start time [s]

    CumIn=0;
    CumEvap=0;
    CumDrain=0;
    Roff=0; 

    while t<t_final % loop until t_final in time steps "dt"

        %these will stay constant during iteration over time step "dt"
        Wliq_old=Wliq;
        Wice_old=Wice;
        
        %these quantities will change during iteration until convergence
        h_iter=h;
        h_iterold=h;
        Wliq_iter=Wliq;
        Wice_iter=Wice;
        Wtot_iter=Wliq_iter + Wice_iter; % + Wvap_iter;
        Wair_iter=poros - Wtot_iter;
        
        % -------------------- estimate hydraulic conductivities -------------------------
        [KLh, KLT, Kvh, KvT] = SoilProfile.HydraulicConductivities(h_iter,T,Wliq,Wice, pF, GwT, vClay,vOrganic,0, 0,1,Kmacro);

        KLh=SoilProfile.SpatialAverage(z,KLh,1); %xu=SpatialAverage(z,x,method) (1==arithmetic, 2==resistances in series, depth weithted)

        KLT=SoilProfile.SpatialAverage(z,KLT,1);
        Kvh=SoilProfile.SpatialAverage(z,Kvh,1);
        KvT=SoilProfile.SpatialAverage(z,KvT,1);

        Kh=KLh + Kvh; % head gradient multiplier 
        KT=KLT + KvT; % T-gradient multiplier        
        
        % start iterative solution of Richards equation
        err1=99999;
        err2=99999;
        NoIter=0;
        dt=dto;
        
        if any(h<-1e-7)==1, Conv_crit2 =1e-7; else Conv_crit2 = 1e-4; end
            
        while (err1>Conv_crit1 || err2>Conv_crit2) 

            NoIter=NoIter+1;
            
%             % -------------------- estimate hydraulic conductivities -------------------------
%             [KLh, KLT, Kvh, KvT] = SoilProfile.HydraulicConductivities(h_iter,T,Wliq,Wice, pF, GwT, vClay, vOrganic,0, 0,1,Ksmacro);
% 
%             KLh=SoilProfile.SpatialAverage(z,KLh,1); %xu=SpatialAverage(z,x,method) (1==arithmetic, 2==resistances in series, depth weithted)
% 
%             KLT=SoilProfile.SpatialAverage(z,KLT,1);
%             Kvh=SoilProfile.SpatialAverage(z,Kvh,1);
%             KvT=SoilProfile.SpatialAverage(z,KvT,1);
% 
%             Kh=KLh + Kvh; % head gradient multiplier 
%             KT=KLT + KvT; % T-gradient multiplier
            
            % fluxes through bottom boundary (m/s)
            if botBCh==0, % head boundary NOTE: NOT ACCURATE APPROXIMATION!!! This affects returned MBE while the model still conserves mass!!
                h_bot=lBCh;
                %q_bot=-Kh(N)*(h_iter(N) - h_bot)/(2*dz(N)) -KLh(N);
                q_bot=-Kh(N)*(h_iter(N) - h_bot)/(dzl(N)) -KLh(N);
                clear h_bot
            end %fixed head
            
            if botBCh==1, % free drainage at lower boundary
                q_bot=-KLh(N)*cosalfa; 
                if h_iter(N)<-1, q_bot=0; end % allow free drainage until field capacity  
            end 
            
            if botBCh==-1,  q_bot=lBCh; end % impermeable boundary
            
            % --------------------- check upper boundary condition ------------
            [topBCh, q_sur]=Check_uBCh();
            
            % if dt very small, set infiltration/soil evap. to zero
            if dt<2,
                q_sur=0;
                HM=zeros(N,1);
            %    disp('set top flux to zero')
            end
            
            if topBCh~=-2,

                %---- save old iteration values     
                Wtot_iterold=Wtot_iter;

                C = SoilProfile.DiffCapa(h_iter,h_iterold,pF); % differential water capacity (dWl/dh) (1/m)
                
                %get new estimate for h
                h_iterold=h_iter;
                h_iter= SolveRichards();
                
                %GWL and add pressure head to matrix potential
                [h_iter,GWL] = GetGWL(h_iter,z);
                %[~,GWL] = GetGWL(h_iter,z);
                
                Wtot_iter=SoilProfile.ThetaFromHead(h_iter,pF);
                Wliq_iter=Wtot_iter - Wice_iter;% - Wvap_iter;
                Wair_iter=poros - Wtot_iter;

                err1=max(abs(Wtot_iter - Wtot_iterold));
                err2=max(abs(h_iter - h_iterold));
                
                if NoIter==7
                    dt=dt/3;
                    fprintf('WatFlow: decreasing dt to %.5g\n',dt)
                    NoIter=0;
                    continue % break current iteration loop and start loop again with smaller dt
                end

            else % case matrix has become saturated, no inflow of outflow
                disp('Saturated matrix - no iterations done')
                h_iter=h_iterold;
                q_bot=0;
                dt=t_final-t;
                NoIter=1;
                err1=0;
                err2=0;
                GWL=z(1);
            
            
            end % end of iteration loop when convergence
        end % end of iteration
        
        if any(isnan(h_iter)==1) || any(abs(h_iter)>1e12) % if numerical problem, break and return previous values to calling function
            disp('WatFlow: numerical problem - return previous values')
            Wtot=SoilProfile.ThetaFromHead(h,pF);
            Wice=SoilProfile.FrozenWater(T,Wtot,fp);
            Wliq=Wtot - Wice;
            % set all water fluxes to zero and route all to surface runoff
            FL=zeros(N,4); 
            CumIn = 0; CumEvap = 0; CumDrain = 0; 
            Roff = q_top*t_final; % all 
            KLh=KLh';
            RHsoil=exp((Mwater*grav.*h(1))./(GasConst.*(T(1)+NT))); % top soil RH(-)
            %PRF.Wliq & PRF.Wice are from previous time step
            MBE= 0 ; % mass balance error (m)
            GWL=PRF.GWL;
            return
        end
        
        %new state variables
        h=h_iter;
        Wtot=SoilProfile.ThetaFromHead(h,pF);
        Wice=SoilProfile.FrozenWater(T,Wtot,fp);
        Wliq=Wtot - Wice; 
        
        clear h_iter Wtot_iterold Wtot_iter Wice_iter Wair_iter err1
        
        %------- update cumulative Infiltration, evaporation, drainage and h_pond --------------

        if q_sur<=0,
            CumIn=CumIn + q_sur*dt; %m
            h_pond=max([0; h_pond - (q_top-q_sur)*dt]); % m
            rr=max([0; h_pond - MaxPond]);
            h_pond=h_pond - rr;
            Roff=Roff + rr; clear rr
        end

        if q_sur>0  
            CumEvap=CumEvap + q_sur*dt; %m
            h_pond=max([0; h_pond - (q_top - q_sur)*dt]); %m
        end

        CumDrain= CumDrain - q_bot*dt + sum(HM.*dz')*dt;  %sum of vertical bottom flux + horizontal drainage (m)

    %     figure(33)
    %     subplot(411); plot(t,q_sur, 'k.'); title('qsur (m/s)');hold on
    %     subplot(412); plot(t,CumIn, 'r.', t, CumEvap, 'g.'); title('CumInf & Evap (m)');hold on
    %     subplot(413); plot(t,Roff, 'b.'); title('Roff (m)');hold on
    %     subplot(414); plot(t,h_pond, 'c.'); title('hpond (m)');hold on

        % set new dt based on NoIter on previous round, if 2<=NoIter<=4 dt=dt;  
        
        t=t + dt; %running time of solution
        
        if NoIter<2
            dt=dt*1.25;
        elseif NoIter>4,
            dt=dt/1.25;
        end

        dt=min(dt, t_final-t);

    end % end of timestep

    % vertical water fluxes
    [FLh,FLT,Fvh,FvT]=WaterFluxesBetweenNodes(h,T);
    FL=[FLh; FLT; Fvh; FvT;]';
    
    % liquid hydraulic conductivity of matrix (m/s)
    [KLh,~,~,~] = SoilProfile.HydraulicConductivities(h,T,Wliq,Wice, pF, GwT, vClay,vOrganic,0, 0,0,Kmacro);
    %KLh=SoilProfile.SpatialAverage(z,KLh,1)'; %xu=SpatialAverage(z,x,method) (1==arithmetic, 2==resistances in series, depth weithted)
    
    % top soil relative humidity
    RHsoil=exp((Mwater*grav.*h(1))./(GasConst.*(T(1)+NT))); % (-)

    % mass balance error (m)
    %PRF.Wliq & PRF.Wice are from previous time step
%     Wsto=1e3*sum((PRF.Wliq + PRF.Wice).*dz')
%     Wste=1e3*sum(Wtot.*dz')
%     dste=Wste-Wsto
%     Inf=CumIn*1e3
%     Dr=CumDrain*1e3
%     Evap=CumEvap*1e3
%     Ru=1e3*sum(S.*dz')*t_final
    
    MBE= 1e3*((sum((PRF.Wliq + PRF.Wice).*dz') -sum(Wtot.*dz')) -sum(S.*dz')*t_final - CumIn - CumDrain - CumEvap); %mm
  
%% internal function definitions

   function [topBCh, q_sur]=Check_uBCh()
       % calculates upper flux boundary condition value (m/s)

        Airvol=max([0; sum(Wair_iter.*dz')]); % maximum inflow (m) tolerated by soil column   
        FractAir=Airvol/sum(poros.*dz');
        q0=q_top -h_pond/dt; % maximum available infiltration (m/s, negative) or evaporative demand (m/s, positive) at surface
        
       % MaxInf=-Ksat(1)*(h_pond-h_iter(1) - z(1))/dz(1); % max Infiltration rate to 1st node [m/s]
        MaxEva=-Kh(1)*(h_atm - h_iter(1) - z(1))/dz(1); % max evaporation rate from 1st node limited by soil supply [m/s]
        
        % controls of infiltration rate
  
        MaxInf=-Ksat(1)*(h_pond-h_iter(1) - z(1))/dz(1); % max Infiltration rate to 1st node [m/s]
        
        %% MUUTA T�T� NIIN ETT� ORSIVESITILANTEESSA EI TAPAHDU INFILTRAATIOTA!!
        % if there is wetting front / ground water formation at top, layers deeper in the profile may limit
            %infiltration        
        if h_iter(1)>-eps, 
            critlayer=find(h_iter<-eps,1,'first'); %first unsaturated node
            
            if critlayer<=N,
                MaxInfInProfile=-KLh(critlayer);
                MaxInf=max([MaxInf MaxInfInProfile]); %
            end
        end
        
        % infiltration
        if q0<0,
            % downward fluxes are negative, upward positive
            Qin=(-q_bot - q0)*dt; % + sum(S.*dz' + HM.*dz'))*dt %net inflow to column (m)
            %initially saturated column
            if Airvol<=eps 
                if Qin>=0 && FractAir<0.001, %infiltration exceeds outflows and matrix stays saturated
                    %disp('loop saturated remains saturated')
                    topBCh=1; %topBCh=-2; %
                    q_sur= 0; % in this case Richards is not solved
                elseif Qin<=0, %outflows exceed inflows
                    %disp('loop saturated becomes unsaturated')
                    topBCh=1; % flux boundary
                    q_sur=q0;
                    %q_sur=max([q0; -Ksat(1)]);%max([MaxInf; q0]);
                end
            end
        
            % initially non-saturated column
            if Airvol>eps,       
                if Qin>=Airvol, %only part Qin - Airvol infiltrates
                    %disp('loop non-saturated & Qin>Airvol')
                    topBCh=1;
                    q_sur=max([MaxInf;-0.9*(Qin -Airvol)]); % q_sur [m/s] is limited either by infiltration capacity or free space
                end

                if Qin<Airvol, % all fits to profile
                    topBCh=1;
                    % infiltration limited either by supply (q0) or capacity of 1st node to take water
                    %q_sur=q0;
                    q_sur=max([MaxInf; -Ksat(1);q0]); 
                end 
            end
        end
        
        %evaporation
        if q0>=0,
            topBCh=1;
            q_sur=min([MaxEva; q0]); % limited either by soil supply or atm. demand.
        end
   end
        
        
 %------------------------------------------------------------------------
 
    function x= SolveRichards()
    % sets tridiagonal matrix to solve MASS BALANCE EQUATION
    
        %---------- set up elements of tridiagonal matrix
        %
        % b = diagonal
        % a = subdiagonal
        % g = superdiagonal
        % f = known rhs vector

        % dzu = z(n-1)-z(n), dzl= z(n) - z(n+1) 
        % compartment thickness dz=(dzu+dzl)/2 = (z(n-1) -z(n+1))/2
        a=zeros(N,1); b=a; g=a; f=a;
        
        %--------------- intermediate nodes i=2:N-1
        clear i
        for i=2:N-1

            %dzu = z(i-1)-z(i); 
            %dzl = z(i) - z(i+1); 
            %dz =(dzu + dzl)/2; %layer thickness
            
            b(i) = C(i) + dt/dz(i)*(Kh(i)/dzu(i) + Kh(i+1)/dzl(i));
            a(i) = - dt/(dz(i)*dzu(i))*Kh(i);
            g(i) = -dt/(dz(i)*dzl(i))*Kh(i+1);            
            f(i) = C(i)*h_iter(i) - (Wliq_iter(i) - Wliq_old(i)) -rhoi/rhow*(Wice_iter(i) - Wice_old(i)) + ...
                dt/dz(i)*( (KLh(i) - KLh(i+1))*cosalfa +  KT(i)/dzu(i)*(T(i-1) - T(i)) - KT(i+1)/dzl(i)*(T(i) - T(i+1)) ) ...
                -S(i)*dt -HM(i)*dt;
            % S(i) water sink/source, HM(i) horizontal transport (drainage) (m/s)
        end
        clear i
        %---------- top node (i=1)-----------------------------
         %assume water flows due to temperature gradient are zero at i=1
    
        if topBCh==1 % flux boundary %%

            b(1) = C(1) + dt/(dz(1)*dzl(1))*Kh(2);
            a(1) = 0;
            g(1) = -dt/(dz(1)*dzl(1))*Kh(2); 
            f(1) = C(1)*h_iter(1) - (Wliq_iter(1) - Wliq_old(1)) -rhoi/rhow*(Wice_iter(1) - Wice_old(1)) + ...
                dt/dz(1)*( -q_sur -KLh(2)*cosalfa ) -S(1)*dt;
        end

%         if topBCh==0 % head boundary
% 
%             b(1) = C(1) + dt/(dz(1)*dzu(1))*Kh(1) + dt/(dz(1)*dzl(1))*Kh(2);
%             a(1) = 0;
%             g(1) = -dt/(dz(1)*dzl(1))*Kh(2); 
%             f(1) = C(1)*h_iter(1) - (Wliq_iter(1) - Wliq_old(1)) -rhoi/rhow*(Wice_iter(1) - Wice_old(1)) + ...
%                 dt/dz(1)*( (KLh(1) - KLh(2))*cosalfa + Kh(1)/dzu(1)*h_sur) -S(1)*dt;     
%         end
        
        
        %------ bottom node (i=N)
        %assume water flows due to temperature gradient are zero at i=N
        
        if botBCh==-1 %impermeable boundary

            b(N) = C(N) + dt/(dz(N)*dzu(N))*Kh(N-1);
            a(N) = -dt/(dz(N)*dzu(N))*Kh(N-1);
            g(N) = 0;
            f(N) = C(N)*h_iter(N) - (Wliq_iter(N) - Wliq_old(N)) - rhoi/rhow*(Wice_iter(N) - Wice_old(N)) + ...
                dt/dz(N)*(KLh(N-1)*cosalfa + q_bot) - S(N)*dt -HM(N)*dt;  
        end
        if botBCh==1 %flux boundary

            b(N) = C(N) + dt/(dz(N)*dzu(N))*Kh(N-1);
            a(N) = -dt/(dz(N)*dzu(N))*Kh(N-1);
            g(N) = 0;
            f(N) = C(N)*h_iter(N) - (Wliq_iter(N) - Wliq_old(N)) - rhoi/rhow*(Wice_iter(N) - Wice_old(N)) + ...
                dt/dz(N)*(KLh(N-1)*cosalfa + q_bot) - S(N)*dt -HM(N)*dt;  
        end
%         if botBCh==0 % head boundary, fixed head "at node N+1"
% 
%             b(N) = C(N) + dt/(dz(N)*dzu(N))*Kh(N-1) + dt/(dz(N)*dzl(N))*Kh(N);
%             a(N) = -dt/(dz(N)*dzu(N))*Kh(N-1);
%             g(N) = 0;
%             f(N) =  C(N)*h_iter(N) - (Wliq_iter(N) - Wliq_old(N)) -rhoi/rhow*(Wice_iter(N) - Wice_old(N)) + ...
%                 dt/dz(N)*( (KLh(N-1) - KLh(N))*cosalfa + Kh(N)/dzl(N)*h_bot) -S(N)*dt -HM(N)*dt;        
%         end
        
        %-------coefficients set--------------------------------------------
        
        %solve tridiagonal matrix and return new head
        x=Thomas(a,b,g,f);
        
        x(x>0)=0;
        clear a b g f
        
    end


%-------------------------------------------------------------------------

    function [FLh,FLT,Fvh,FvT]=WaterFluxesBetweenNodes(y,Ts)
    % calculates liquid water anv water vapor fluxes due to head (FLh, Fvh)) and temperature gradients (FLT, FvT)
    % at the interfaces between nodes.
    % INPUT: y - pressure head (m), Ts - temperature (degC), z vertical grid (m), z<0, z(1)-z(2)>0.
    % q_surf - liquid water infiltration or evaporation rate (m/s)
    %
    % OUTPUT: Fluxes (m/s). Soil interface: FLh(1)=q_sur; FLT(1)=FLT(2),Fvh(1)=Fvh(2),FvT(1)=FvT(2)
    %
    % Uses hydraulic conductivities at the interface directly from calling function!
     
        %dzz=-central_diff(z);
        yyy=central_diff(y);
        ttt=central_diff(Ts);
        
        FLh(1:N) = KLh(1:N).*(yyy -cosalfa); % matrix potential gradient and gravity terms create liquid flux
        %FLh(1)=FLh(2); % m/s 
        FLh(1)=q_sur; % m/s 
        FLT (1:N) = KLT(1:N).*(ttt); % liquid flux due to temperature gradient is from warm to cold.
        Fvh(1:N) = Kvh(1:N).*(yyy -cosalfa);
        FvT (1:N) = KvT(1:N).*(ttt);

%         figure(101);
%         subplot(331);plot(y,z,'r-'); title('head')
%         subplot(332);plot(Ts,z,'k-'); title('T')
%         subplot(333);plot(yyy, z,'r--'); title('dh/dz')
%         subplot(334);plot(ttt,z,'r--'); title('dT/dz')
%         subplot(335);plot(FLh,z,'r-',Fvh,z,'c-'); title('FLh, Fvh')
%         subplot(336);plot(FLT,z,'r-',FvT,z,'c-'); title('FLT, FvT')
%         subplot(337);plot(KLh,z,'r-',KLT,z,'c-'); title('KLh, KLT')
%         subplot(338);plot(KLT,z,'r-',KvT,z,'c-'); title('KLT, KvT')        

        clear dzz y Ts 
    end
%-----------------------------------------------------------------------
    function [dydx]=central_diff(y)
        y=y';
        dydx=[];
        %---------- use central difference for estimating derivatives
        dydx(2:N-1)=(y(3:N)-y(1:N-2))./(dzu(2:N-1) + dzl(2:N-1));
        %--------- use forward difference at upper boundary
        dydx(1)=(y(2)-y(1))/dzl(1);
        %--------- use backward difference at lower boundary
        dydx(N)=(y(N)-y(N-1))/dzu(N);
    end

%-------------------------------------------------------------------------
    function [head,GWL] = GetGWL(head,zz)
        % calculates ground water level (GWL,m) and addjusts head by adding
        % hydrostatic pressure (m) if node is saturated
        %
        satnodes=find(head>=0);%-eps); %saturated nodes
        fsatnode=min(satnodes); %uppermost saturated node
        
        if isempty(satnodes)==0 %GWL found in computational layer
            if fsatnode>1,
                GWL=zz(fsatnode-1) + head(fsatnode-1);  % immediately above saturated node h is assumed to be in hydrostatic equilibrium 
                                                        % and GWL = Z(1st unsat node) + head(1st unsat node)
            else
                GWL = zz(fsatnode); % gwl is at first layer
            end
            %pressure head (depth below gwl)
            head(satnodes) = GWL - zz(satnodes); % m, >=0
        else
            GWL = head(N) + zz(N); %else set gwl equal to the hydrostatic equilibrium between last node and GWL
        end     
    end
%------------------------------------------------------------------------

    function q = Thomas(aa,bb,cc,dd)
    % Tridiagonal solver. Solves equation CX=B, where C is tridiagonal matrix,
    % X solution vector and B constant vector of the linear system
    %
    % aa = subdiagonal of C
    % bb = main diagonal of C
    % cc = superdiagonal of C
    % dd = constant (rhs) vector of the linear system
    % output q is the solution vector
        
        %initialize vectors
        M=length(aa);
        bet=ones(M,1).*NaN;
        gam=bet; q=bet;
        
        bet(1)=bb(1);
        gam(1)=dd(1)/bb(1);
        k=length(bb);
        %elimination of coefficients
        for m=2:k
            bet(m)=bb(m)-(aa(m)*cc(m-1)/bet(m-1));
            gam(m)=(dd(m)-aa(m)*gam(m-1))/bet(m);
        end 

        q(k)=gam(k);
        %back-substitution
        for m=k-1:-1:1
            q(m)=gam(m)-(cc(m)*q(m+1)/bet(m));   
        end 
        %q=q';
        clear M bet gam k m aa bb cc dd
    end


end