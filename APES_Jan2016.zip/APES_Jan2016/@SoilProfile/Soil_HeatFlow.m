function [Wliq, Wice, T, Fheat, R]=Soil_HeatFlow(PRF,t_final,dto,P,InfRate,Tinf,uBCt,lBCt)
% function [Wliq, Wice, T, Fheat, R]=Soil_HeatFlow(PRF,t_final,dto,P,InfRate,Tinf,uBCt,lBCt)
% Solves heat transport equations in 1-D in variably saturated soils and in presense of liquid-solid phase changes 
%
% INPUT:
%   PRF - soil profile object
%   t_final - final time of solution (s)
%   dto - initial time step (s)
%   InfRate - infiltration rate (m/s)
%   Tinf - temperature of infiltrating water (degC)
%   uBCt - Heat equation upper boundary condition [type value], type: (1= flux, 0 = prescribed value at i=1) 
%           [flux(m/s), downward flux is negative] or [T_sur] for prescribed head at fictious node 0
%   lBCt - Heat equation lower boundary condition [type value], type: (1= flux, 0 = prescribed value at i=N+1) 
%           [flux(m/s), downward flux is negative] or [T_sur] for prescribed head at fictious node N+1
%
% OUTPUT: 
%   Column vectors of N x 1
    %   Wliq - volumetric liquid water content (m3/m3)
    %   Wice - volumetric ice content (m3/m3)
    %   T - temperature profile (degC)
    %   Fheat - vertical heat flux (W/m2) 
    %   R - thermal conductivity (Wm-1K-1)
%
% USES: 
    %  SoilProfile (static) methods defined in Clasdef -file: 
    %   ThermalConductivity.m 
    %   SpatialAverage.m
    %   ThetaFromHead
    %   FrozenWater
%
%   Samuli Launiainen, Metla 7/2011 - 4/2012
%
%% ------------------ constants--------------------------------------------

%T0=0; % freezing point of water (degC)
grav=9.81; % acceleration due gravity, kgm/s2
Lf=333700; % latent heat of freezing, J/kg; % Lv is latent heat of vaportization
%GasConst=8.314; % universal gas constant, Jmol-1
%Mwater=18.015e-3; % molar mass of water, kg mol-1

%rhow=1000; %water density, kg/m3
rhoi=917;  %ice density, kg/m3
%rhoa=1.25; % density of air (kg/m3)
ca=1297; %volumetric heat capacity of air (J/m3/K)
cw=4.18e6; %volumetric heat capacity of water (J/m3/K)
ci=1.9e6;  %volumetric heat capacity of ice (J/m3/K)

%not needed if more sophisticated equation is used for Wliq=f(T,Wice)
fp=PRF.FreezingCurvePara; %  parameters of freezing curve, fp(1) = temperature, fp(2) = 2..4 clay soils,  0.5..1.5 sandy soils... (Femma-code / Koivusalo)


%% -------------Get grid and make local copy of soil description from PRF -------------

z=PRF.zs;
N=length(z); % nr of nodal points, N is deepest node

%distances between grid points: dzu is between point i-1 and i, dzl between point i and i+1
dzu(2:N)=z(1:N-1) - z(2:N); dzu(1)=-z(1); 
dzl(1:N-1)=z(1:N-1) - z(2:N); dzl(N)=(z(N-1) - z(N))/2;

%layer thicknesses
dz=dzu/2 + dzl/2; 
dz(1)=dzu(1) + dzl(1)/2;


pF=PRF.pF; %ThetaSat (m3/m3),ThetaRes (m3/m3),alfa(-),n(-),Kzsat(m/s), poreconn
poros=PRF.porosity; % soil porosity (m3/m3) ~= saturated water content 

vClay=PRF.vClay; % volume fraction of clay (-)
vQuartz=PRF.vQuartz; % volume fraction of quartz (-)
vMineral=PRF.vMineral; % volume fraction of other minerals (-)
vOrganic=PRF.vOrganic; % volume fraction of organic material (-)
%GwT=PRF.GwT;% gain factor (-), temperature dependency of pF -curve (order of 7 for sand)

%rhos= 2650*(vQuartz +vMineral + vClay) + 1300*vOrganic; %soil parent material (kg/m3)
cs = (2.2e6.*(vMineral + vClay) +2.5e6*vOrganic)./(1-poros); % soil parent material volumetric heat capacity (J/(m3*K), Campbell & Norman 1998


%% -------initial & boundary conditions

T=PRF.T; %degC
h=PRF.h; % m
Wliq=PRF.Wliq; % m3/m3
Wice=PRF.Wice; % m3/m3

%HS=-cw*So.*T./dz'; %  Heat sink term due to root water uptake & horizontal drainage (J/(m3*s) = W m-3)

HS=zeros(N,1);
%LH(1)=cw*InfRate*(Tinf-T(1))/dz(1); % heat advection with infiltration to 1st node (J/(m3s) = W m-3)
%LH(1)=cw*InfRate*(Tinf)/dz(1); % heat advection with infiltration to 1st node (J/(m3s) = W m-3)
LH(1)=0;

%-- boundary conditions
topBCT=uBCt(1); botBCT=lBCt(1);
if topBCT==1; F_sur=uBCt(2);  else T_sur=uBCt(2); end
if botBCT==1; F_bot=lBCt(2);  else T_bot=lBCt(2); end

Conv_crit1=0.001; % T (degC)
Conv_crit2=0.001; % Wliq (m3/m3)

%% -------- find solution at t_final ------------------------

dt=dto; % initial time step [s]
t=0; %start time [s]


while t<t_final
    
    %these will stay constant during iteration over time step "dt"
    
    T_old=T;
    Wliq_old=Wliq;
    Wice_old=Wice;
    CP_old= SoilHeatCapa(Wliq_old,Wice_old); % volumetric heat capacity of soil (J m-3 K-1)
                
    %---------- Thermal conductivity -------------------------------- 
    
    %last input is method: 1: volume-weighted ave, 2:Campbell, 1995 & Hansson et al. 2004,
    %3: deVries -model (according to Campbell & Norman, 1998).
    %R=SoilProfile.ThermalConductivity(Wliq,Wice,poros,vQuartz,vMineral,vClay,vOrganic,2); 
    
    R=SoilProfile.ThermalConductivity(P,T,h,Wliq,Wice,poros,vQuartz,vMineral,vClay,vOrganic,3); %(Wm-1K-1)
    
    R=SoilProfile.SpatialAverage(z,R,2); 
    %xu=SoilProfile.SpatialAverage(z,x,method) (1==arithmetic, 2==resistances in series, depth weithted, 3=geom. average)
%     figure(1)
%     plot(R,z,'r-'); title('\lambda')

  
    %these quantities will change during iteration until convergence 
    Wliq_iter=Wliq;
    Wice_iter=Wice;
    Wtot=Wliq_iter + Wice_iter; % + Wvap_iter;
    T_iter=T;
    
    % start iterative solution of Heat equation
    err1=99999; err2=99999;
    NoIter=0;
    while (err1>Conv_crit1) && (err2>Conv_crit2)
        
        %% --------------------- calculate heat transfer and phase changes -----------------
        
        NoIter=NoIter+1;
               
        %---- save old iteration values
        T_iterold=T_iter;
        Wliq_iterold=Wliq_iter;
        
        C = SoilProfile.DiffCapa(h, h -1e-5,pF); % differential water capacity (dWl/dh) (1/m)
        CP= SoilHeatCapa(Wliq_iter,Wice_iter); % volumetric heat capacity of soil (J m-3 K-1) 
        
        A=Lf^2*rhoi./(grav*(T_iter+273.15)).*C; % additional term due to phase-changes (liq <--> solid) (J m-3 K-1)
        A(T_iter>=0)=0; % thus, neglect if above-zero temperatures
        
%         figure()
%         subplot(221), plot(A,z,'r-'); title('A')
%         subplot(222), plot(CP,z,'r-'); title('CP')
%         subplot(223), plot(C,z,'r-'); title('Cc')
%         pause
       
        % ------ new estimate for temperature
        T_iter=SolveHeat();
        
        Wice_iter=SoilProfile.FrozenWater(T_iter,Wtot,fp);
        
        Wliq_iter=Wtot - Wice_iter; 
        
        err1=max(abs(T_iter-T_iterold));
        err2=max(abs(Wliq_iter - Wliq_iterold));
        clear T_iterold Wliq_iterold
    
        if NoIter==7
            dt=dt/3;
            %disp('Break inner while')
            NoIter=0;
            continue % break current iteration loop and start loop again with smaller dt
        end
        
    end % end of iteration loop when convergence
    
    if any(isnan(T_iter))==1 || any(abs(T_iter))>100 % if numerical problem, break and return previous values to calling procedure
        disp('numerical problem - previous values retuned')
        T=PRF.T;
        % set  fluxes to zero and return previous values
        Fheat=zeros(N,1); 
        R=PRF.Ktherm;
        Wliq=PRF.Wliq;
        Wice=PRF.Wice; 
        return
    end
    % set new values

    
    T=T_iter;     
    Wliq=Wliq_iter;
    Wice=Wtot - Wliq;
   
    clear T_iter Wliq_iter Wice_iter err1 err2
    
    t=t + dt; %running time of solution
    
%     %------- update cumulative heat inflow --------------
%     if topBCT==0, %surface
%         Gflux0=Gflux0 - R(1)*(T_sur-T(1))/dzu(1)*dt;
%     else
%         Gflux0=Gflux0 + F_sur*dt;
%     end
    
    % set new dt based on NoIter on previous round, if 2<=NoIter<=4 dt=dt;  
    if NoIter<2
        dt=dt*1.25;
    elseif NoIter>4,
        dt=dt/1.25;
    end
    
    dt=min(dt, t_final-t);
%     figure(2)
%     subplot(221); plot(Wliq,z,'r.-', Wice,z,'b.-', Wtot,z,'g.-'); ylabel('Wliq,Wice,Wtot');
%     subplot(222); plot(T,z,'k.-'); ylabel('T');
%     subplot(223); plot(R,z,'g-')
%     %pause, %close all
       
end

%-------- Vertical heat fluxes by conduction ----------
[Fheat]=HeatFluxesBetweenNodes(T);
%Fheat(1)=Gflux0/t_final;
R=SoilProfile.ThermalConductivity(P,T,h,Wliq,Wice,poros,vQuartz,vMineral,vClay,vOrganic,3);
    
%% internal function definitions

% ------------------------------------------------------------------------------------------------

    function x=SolveHeat()
        % sets tridiagonal matrix to solve HEAT EQUATION
        % here simplified based on Li et al. (2010) JGR: latent heat release due vapor phase changes (Lv*dWvap/dt) and contribution of vapor
        % fluxes to energy balance are negligible
    
        a=zeros(N,1); b=a; g=a; f=a;    
        %---------- set up elements of tridiagonal matrix
        %
        % b = diagonal
        % a = subdiagonal
        % g = superdiagonal
        % f = known rhs vector

        % dzu = z(n-1)-z(n), dzl= z(n) - z(n+1) 
        % compartment thickness dz=(dzu+dzl)/2 = (z(n-1) -z(n+1))/2    
        
        %--------------- intermediate nodes i=2:N-1 
        clear i
        for i=2:N-1           
            b(i) = CP(i) + A(i) + dt/dz(i)*(R(i)/dzu(i) + R(i+1)/dzl(i));
            a(i) = - dt/(dz(i)*dzu(i))*R(i); 
            g(i) = -dt/(dz(i)*dzl(i))*R(i+1);
            f(i) = CP_old(i)*T_old(i) + A(i)*T_iter(i) + Lf*rhoi*(Wice_iter(i) - Wice_old(i)) -dt*HS(i);
            %dt*HS(i) is direct heat sink/source as input vector) 
        end
        clear i
        %---------- top node (i=1)-----------------------------
        % how gradient of sensible heat advection with liquid flow should be at the boundary?
        % HS(1) assumed to be zero; heat sink/source at boundary through F_sur
        % LH is heat input by infiltration/ loss by evaporation

        
        if topBCT==1 % flux boundary; heat exchange through the surface is given as term "F_sur"
            b(1) = CP(1) + A(1) + dt/(dz(1)*dzl(1))*R(2);
            a(1) = 0;
            g(1) = -dt/(dz(1)*dzl(1))*R(2);
            f(1) = CP_old(1)*T_old(1) + A(1)*T_iter(1) + Lf*rhoi*(Wice_iter(1) - Wice_old(1)) - dt/dz(1)*F_sur ...
                - dt*LH(1);
        end

        if topBCT==0 % temperature boundary (Tsurf)
            b(1) = CP(1) + A(1) + dt/dz(1)*(R(1)/dzu(1) + R(2)/dzl(1));
            a(1) = 0;
            g(1) = -dt/(dz(1)*dzl(1))*R(2);
            f(1) = CP_old(1)*T_old(1) + A(1)*T_iter(1) + Lf*rhoi*(Wice_iter(1) - Wice_old(1)) + dt/(dz(1)*dzu(1))*R(1)*T_sur ...
                - dt*HS(1) - dt*LH(1);
        end

        %------ bottom node (i=N)

%         dzu = z(N-1) - z(N);
%         dzl = dzu; % this should be distance from last node to bottom of last layer --> use same depth of two last layers!
%         dz=(dzu + dzl)/2;

        if botBCT==1 % flux boundary; heat flux through bottom is given as term "Fbot"

            b(N) = CP(N) + A(N) + dt/(dz(N)*dzu(N))*R(N-1);
            a(N) = -dt/(dz(N)*dzu(N))*R(N-1);
            g(N) = 0;
            f(N) = CP_old(N)*T_old(N) + A(N)*T_iter(N) + Lf*rhoi*(Wice_iter(N) - Wice_old(N)) - dt/dz(N)*F_bot -dt*HS(N);
        end

        if botBCT==0 % temperature boundary (fixed temperature, Tbot "at node N+1")

            b(N) = CP(N) + A(N) + dt/dz(N)*(R(N-1)/dzu(N) + R(N)/dzl(N));
            a(N) = -dt/(dz(N)*dzu(N))*R(N-1);
            g(N) = 0;
            f(N) = CP_old(N)*T_old(N) + A(N)*T_iter(N) + Lf*rhoi*(Wice_iter(N) - Wice_old(N)) + dt/(dz(N)*dzl(N))*R(N)*T_bot -dt*HS(N);
        end

        %-------coefficients set--------------------------------------------

        %--------- solve tridiagonal matrix by gaussian elimination----
        
        x=Thomas(a,b,g,f);
        clear a b g f 
    end

% ---------------------------------------------------------------------

    function x=SoilHeatCapa(Wl,Wi)
    %calculates soil volumetric heat capacity x (J/m3/K)
    %INPUT: liquid water content Wl (m3/m3) and ice content Wi (m3/m3)
    %OUTPUT: volumetric heat capacity (J/m3/K)
    %See e.g. Hansson et al. (2004) eq. 8
    
        x=cs.*(1-poros) + cw.*Wl + ci.*Wi + ca.*(poros-Wl-Wi); %J/m3/K
    end

%-------------------------------------------------------------------------

    function [Fheat]=HeatFluxesBetweenNodes(Ts)
    % calculates heat conduction flux (Wm-2) between nodes using central difference
    % approximation in middle nodes and forward/backward diffence at
    % upper/lower boundaries
    % INPUT: Ts - temperature (degC)
    % OUTPUT: Fheat - vertical heat fluxes (W m-2) 
    %
    % Uses thermal conductivities R directly from calling function!
        
        ttt=central_diff(Ts);       
        Fheat = -R.*ttt; %
        
%         figure(101);
%         subplot(221);plot(T,z,'r-'); title('T')
%         subplot(222); plot(ttt, z,'r--'); title('dT/dz')
%         subplot(223);plot(Fheat,z,'r-'); title('Hflux')
%         subplot(224);plot(R,z,'r-'); title('R')      
%         clear ttt Ts 
    end
%-----------------------------------------------------------------------
    function [dydx]=central_diff(y)
        y=y';
        dydx=[];
        %---------- use central difference for estimating derivatives
        dydx(2:N-1)=(y(3:N)-y(1:N-2))./(dzu(2:N-1) + dzl(2:N-1));
        %--------- use forward difference at upper boundary
        dydx(1)=(y(2)-y(1))/dzl(1);
        %--------- use backward difference at lower boundary
        dydx(N)=(y(N)-y(N-1))/dz(N);
    end
%------------------------------------------------------------------------

    function q = Thomas(aa,bb,cc,dd)
    % Tridiagonal solver. Solves equation CX=B, where C is tridiagonal matrix,
    % X solution vector and B constant vector of the linear system
    %
    % aa = subdiagonal of C
    % bb = main diagonal of C
    % cc = superdiagonal of C
    % dd = constant (rhs) vector of the linear system
    % output q is the solution vector
        
        %initialize vectors
        M=length(aa);
        bet=ones(M,1).*NaN;
        gam=bet; q=bet;
        
        bet(1)=bb(1);
        gam(1)=dd(1)/bb(1);
        k=length(bb);
        %elimination of coefficients
        for m=2:k
            bet(m)=bb(m)-(aa(m)*cc(m-1)/bet(m-1));
            gam(m)=(dd(m)-aa(m)*gam(m-1))/bet(m);
        end 

        q(k)=gam(k);
        %back-substitution
        for m=k-1:-1:1
            q(m)=gam(m)-(cc(m)*q(m+1)/bet(m));   
        end 
        
        clear M bet gam k m aa bb cc dd
    end


end