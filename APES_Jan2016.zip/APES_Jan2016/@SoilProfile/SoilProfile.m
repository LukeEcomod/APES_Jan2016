classdef SoilProfile
    %SoilProfile describes soil matrix physical properties,preserves values
    %of state variables and contains SoilProfile method definitions
    %
    % Modified 26.7: (initialization and added properties) / Samuli
     
    properties (SetAccess = private, GetAccess = public)
        zs; % soil node depth (<0, m)
        dzs; % soil node thickness (m)
        cosalfa; % cosine of normal to soil surface (rad) [1 = vertical flow, 2 = horizontal flow]
        NrOfLayers; % number of soil layers
    end
    
    properties (SetAccess = public, GetAccess = public)
        
        pF; % soil water retention parameters (van Genuchten model) 
        %[ThetaS(m3/m3),ThetaR(m3/m3),alfa(-),n(-),compressibility(1/m) Kzsat(m/s) Lambda(-)]
        Ksat; % saturated hydraulic conductivity (m/s)
        KsatH; %horizontal saturated hydraulic conductivity (m/s)
        Kmacro; %conductivity of macropores (m/s)
        GwT; % gain factor, temperature dependency of pF -curve
        vQuartz; %volume fraction of quartz (-)
        vMineral; % volume fraction of other minerals (-)
        vClay; % volume fraction of clay (-)
        vOrganic; % volume fraction of organic material (-)
        vStones; % volumetric fraction of stones (-)
        FreezingCurvePara; % freezing curve parameters [Tfreeze para]

        MaxPondDepth; % maximum allowed ponding depth (m)
        porosity; % soil porosity (m3/m3)
        Wsat; % saturated water content
        
        % soil respiration parameters
        Rsoil_Q10; % Temp. sensitivity (-)
        Rsoil_R10; % Base respiration rate at 10degC(mumolm-2s-1)
        %Rsoil_MoistResp; % moisture-response parameters (Skopp et al. 1990) NOW given in function
        
        zo_soil; % soil roughness length (m)
        PARalb; % PAR albedo of top soil
        NIRalb; % NIR albedo of top soil
        emissivity; %soil emissivity (-)

        % ********** state variables ************************************
        
        T; % soil temperature (degC)
        h; % matrix potential (m)
        Wliq; % liquid water content (m3/m3)
        Wice; % ice content (m3/m3)
        Wtot; % total water content (m3/m3)
        GWL; % ground water level depth (m)
        h_pond; % ponding depth (m)
        Tsurf; % soil surface temperature (degC)
        KLh; % hydraulic conductivity (m/s)
        Ktherm; %thermal conductivity (Wm-1K-1)
        
        DitchDepth=[];
        DitchSpacing=[];
    end
    
    methods % SoilProfile class constructor
        function obj=SoilProfile(SP,IniCond)
                
            if nargin>0
                
                obj.zs=SP.zs;
                N=length(obj.zs);
                dz(2:N)=obj.zs(1:N-1) - obj.zs(2:N); dz(1)=-2*obj.zs(1);% m
                
                obj.dzs=dz'; clear dz
                obj.cosalfa=SP.cosalfa;
                obj.NrOfLayers=N; clear N
         
                obj.MaxPondDepth=SP.MaxPondDepth;
                
                %ditch spacing and depths
                obj.DitchDepth=SP.DitchDepth;
                obj.DitchSpacing=SP.DitchSpacing;
                
                %pF-curves & hydraulic & thermal properties
                obj.pF=SP.pF;
                obj.Ksat=obj.pF(:,6);
                obj.KsatH=SP.KsatH;
                
                obj.Kmacro=SP.Kmacro;
                obj.Wsat=obj.pF(:,1);
                obj.porosity=obj.pF(:,1);
                obj.GwT=SP.GwT;
                obj.FreezingCurvePara=SP.FreezingCurvePara;
                
                %soil composition
                obj.vQuartz=SP.vQuartz;
                obj.vMineral=SP.vMineral;
                obj.vClay=SP.vClay;
                obj.vOrganic=SP.vOrganic;
                obj.vStones=SP.vStones;
                %physical properties of soil surface
                obj.zo_soil=SP.zo; 
                obj.PARalb=SP.PARalb;
                obj.NIRalb=SP.NIRalb;
                obj.emissivity=SP.emi;

                %soil respiration
                obj.Rsoil_Q10=SP.Q10;
                obj.Rsoil_R10=SP.R10;
                
                %initial conditions
                obj.T=IniCond.T;
                obj.Tsurf=obj.T(1);
                
                if isempty(IniCond.Wtot)~=1,
                    obj.Wtot=IniCond.Wtot;
                    [obj.h, obj.Wliq, obj.Wice]=SoilProfile.InitializeMatrixFromTheta(obj.pF,obj.FreezingCurvePara,obj.T,obj.Wtot);
                    
                elseif isempty(IniCond.h)~=1,
                    obj.h=IniCond.h;
                    [obj.Wtot, obj.Wliq, obj.Wice]=SoilProfile.InitializeMatrixFromHead(obj.pF,obj.FreezingCurvePara,obj.T,obj.h);
                else
                    disp('Error creating SoilProfile - check initial conditions')
                end
%                 
%                 figure(1000);
%                 subplot(221);plot(obj.Wtot,obj.zs);
%                 subplot(222);plot(obj.h,obj.zs);
%                 pause, close
                
                obj.h_pond=IniCond.h_pond;
                
                if any(obj.h>0),
                    obj.GWL=obj.zs(find(obj.h>=0,1,'first'));
                elseif all(obj.h<=0),
                    obj.GWL=obj.zs(end)+obj.h(end);
                else
                    obj.GWL=IniCond.GWL;
                end
                %initial values for hydraulic & thermal conductivities
                [obj.KLh,obj.Ktherm]=SoilProfile.InitializeConductivities(obj.pF,obj.Ksat,obj.Wliq,obj.Wice,obj.vQuartz,obj.vMineral,obj.vOrganic);

            else
               
                disp('Error when Creating SoilProfile - check inputs')    
            end
            
        end
        
    end
    
    methods %class-instance dependent methods
 %% *********************************************************************
 
         function Rsoil=SoilRespiration(obj)
            %estimates soil respiration rate (auto+heterotrophic) from soil T, Wliq and AFP:
            % Rsoil=fT*fM as in Pumpanen et al. (2003) Soil.Sci.Soc.Am
            %assumes all respiration is from top 10cm of soil
            %
            %INPUT: 
            %   SoilProfile-object (obj)
            %OUTPUT: 
            %   Rsoil - soil respiration rate (umol m-2(ground) s-1)
            %
            %REFERENCES:
            %   Pumpanen et al. (2003) Soil.Sci.Soc.Am
            %   Skopp et al. (1990),Soil.Sci.Soc.Am
            %
            %Samuli Launiainen, 8-9 / 2013
            
            %temperature response fT
            
            TT=mean(obj.T(obj.zs>=-0.1)); % mean temperature of topmost 10cm layer
            fT=obj.Rsoil_R10*obj.Rsoil_Q10.^((TT - 10)/10); %umolm-2 (ground) s-1    
            clear TT
            
            %moisture response fM based on Skopp et al. (1990),Soil.Sci.Soc.Am,
            a=3.83; % parameters for mixed fine silty soil
            b=4.43;
            d=1.25;
            g=0.854;
            
            AFP=obj.porosity - obj.Wliq; %air-filled porosity m3/m3
            %stone correction; 'look conditions in soil matrix only'
            f=find(obj.vStones>0);
            AFP(f)=AFP(f)./obj.vStones(f);%calculate air-filled porosity and liquid water content
            W=obj.Wliq;
            W(f)=W(f)./obj.vStones(f); %liquid water content
            
            % limitations at each layer either by Wor AFP
            fM=min([a*W.^d  b*AFP.^g ones(obj.NrOfLayers,1)],[],2);
            
            fM=mean(fM(obj.zs>=-0.1)); % mean moisture scaling factor at top 10cm of soil
            
            % respiration rate umolm-2(ground) s-1
            Rsoil=fT*fM;
         end        
        
  %% **********************************************************************      
        function [H,LE,G,To]=SurfaceEnergyBalance_Linearized(obj,Q1,Q2,LW,Ta,U,H2O,P,z)
            %solves surface temperature from linearized energy balance equation for previously known soil conditions. 
            % Assumptions: 
            %   1) soil state (h, T, hydraulic and thermal conductivities) is known from prev. time step
            %   2) evaporation rate is controlled either by atmospheric demand & transport or by soil supply
            %   3) energy balance equation is linearized using isotermal net radiation
            %
            % INPUTS:
            %   obj - soil profile object
            %   Q1, Q2 - incident PAR and NIR (Wm-2)
            %   LW - net isothermal long-wave radiation at the ground (Wm-2)
            %   Ta - air temperature (deg C)
            %   U - wind speed (m/s)
            %   H2O - water vapor mixing ratio in air (mol/mol)
            %   P - ambient pressure (Pa)
            %   z - height where U and Ta are measured (m)
            % OUTPUTS:
            %   H - sensible heat flux (Wm-2)
            %   LE - latent heat flux (Wm-2)
            %   G - soil heat flux (negative value = from surface to deeper soil)(Wm-2)
            %   To - soil surface temperature (degC)
            %
            % Samuli Launiainen, METLA 19.3.2014
            
            %---------- Constants -----------------------
            cp=29.3; % J/mol/K heat capacity of air at constant pressure
            L_molar=44100; %J/mol latent heat of vaporization at 20 deg C
            Mwater=18.0153e-3; % Molecular weight of water kg/mol
            GasConst=8.314; % universal gas constant, Jmol-1
            b = 5.6697e-8; % Stefan-Boltzmann constant (W m-2 K-4)
            %NT=273.15; %K

            %--------- Instance-dependent properties-----------------
            emi=obj.emissivity; %0.98
            Ts=obj.T(1); %soil temperature at 1st node
            ks=obj.Ktherm(1)/abs(obj.zs(1)); %soil thermal conductance to/from 1st layer(Wm-2K-1) 
             
            % soil boundary layer conductances 
            units=1; % return conductances in mol m-2 s-1
            % compute soil boundary layer resistance assuming dT = 0, i.e. Ts=Ta
            dT=0;
            [~,gb_v,gb_h]=SoilProfile.Soil_boundarylayer_conductance(z,obj.zo_soil,U,Ta,dT,units);
            
            gr=4*emi*b*Ta^3/cp +eps; % radiative conductance (mol m-2 s-1)

            % max latent heat flux sustained by soil supply from 1st soil node (Wm-2)
            RH=H2O*P/SoilProfile.e_sat(Ta); % air relative humidity (-) above ground
            h_atm=GasConst*(273.15+Ta).*log(RH)/(Mwater*9.81); % m, atm pressure head in equilibrium with atm. relative humidity
            
            LEmax=L_molar*1000/Mwater*obj.KLh(1)*(h_atm - obj.h(1) - obj.zs(1))/(2*obj.zs(1)); %mm/s(=kg/m2/s) / kg/mol*J/mol =J/m2/s=W/m2    
            clear h_atm RH

            Rn=(1-obj.PARalb)*Q1 +(1-obj.NIRalb)*Q2 - LW; % absorbed isothermal net radiation Wm-2

            To=0.5*(Ta + Ts); %initial guess

            err=999;
            n=0;
            while err>0.01
                n=n+1;
                To_iter=To;
                LE_demand=L_molar*gb_v*(SoilProfile.e_sat(To)/P - H2O); % Wm-2, atmospheric demand   
                LE=min([LEmax LE_demand]);
                To= (Rn + (gr + gb_h)*cp*Ta + ks*obj.T(1) - LE) / ((gr + gb_h)*cp + ks); % deg C
                
                err=abs(To - To_iter);
                %ga=SoilProfile.AerodynamicConductance(zref,obj.zo_soil,U,To,Ta)
                
                if n>30, %case no convergence, break loop and return
                    disp('SoilProfile.SurfaceEnergyBalance_Linearized did not converge')
                    To = Ta;
                    H=0;
                    G=0;
                    LE=0;
                    return
                end
            end
            % negative values are downwards!
            LE=L_molar*gb_v*(SoilProfile.e_sat(To)/P - H2O); %Wm-2;
            H=gb_h*cp*(To-Ta); %W m-2
            G=-ks*(To-obj.T(1)); %W-2; negative value is from surface to deeper soil
            
            %error check
            if abs(To)>70 || abs(To-Ta) > 50,
                To=Ta; H=0; G=0; LE=0;
            end
        end
        
        %% **********************************************************************      
        function [H,LE,G,LWup,To]=SurfaceEnergyBalance(obj,Q1,Q2,LWdn,Ta,U,H2O,P,z)
            %solves surface temperature To from energy balance equation for previously known soil conditions. 
            % Assumptions: 
            %   1) soil state (h, T, hydraulic and thermal conductivities) is known from prev. time step
            %   2) evaporation rate is controlled either by atmospheric demand & transport or by soil supply
            %
            % INPUTS:
            %   obj - soil profile object
            %   Q1, Q2 - incident PAR and NIR (Wm-2)
            %   LWdn - downwelling long-wave radiation at the ground (Wm-2)
            %   Ta - air temperature (deg C)
            %   U - wind speed (m/s)
            %   H2O - water vapor mixing ratio in air (mol/mol)
            %   P - ambient pressure (Pa)
            %   z - height where U and Ta are measured (m)
            % OUTPUTS:
            %   H - sensible heat flux (Wm-2), <0 towards surface
            %   LE - latent heat flux (Wm-2), <0 towards surface
            %   G - soil heat flux (negative value = from surface to deeper soil)(Wm-2)
            %   LWup - emitterd long-wave rad. (Wm-2)
            %   To - soil surface temperature (degC)
            %
            % NOTE: CHANGE fzero TO ode-solver for stability!!! 09.02.2015 /SL
            %
            % Samuli Launiainen METLA, 2014-2015 (last edit 11.2.2015)
            
            %---------- Constants -----------------------
            cp=29.3; % J/mol/K heat capacity of air at constant pressure
            L_molar=44100; %J/mol latent heat of vaporization at 20 deg C
            Mwater=18.0153e-3; % Molecular weight of water kg/mol
            GasConst=8.314; % universal gas constant, Jmol-1
            b = 5.6697e-8; % Stefan-Boltzmann constant (W m-2 K-4)
            NT=273.15; %K
            
            %--------- Instance-dependent properties-----------------
            emi=obj.emissivity; %0.98
            Ts=obj.T(1); %soil temperature at 1st node
            Rabs=(1-obj.PARalb)*Q1 +(1-obj.NIRalb)*Q2 + emi*LWdn; % absorbed all-wave radiation
            ks=obj.Ktherm(1)/abs(obj.zs(1)); %soil thermal conductance to/from 1st layer(Wm-2K-1) 
             
            % soil boundary layer conductances 
            units=1; % return conductances in mol m-2 s-1
            % compute soil boundary layer resistance assuming dT = 0, i.e. Ts=Ta
            dT=0;
            [~,gb_v,gb_h]=SoilProfile.Soil_boundarylayer_conductance(z,obj.zo_soil,U,Ta,dT,units);
            

            % max latent heat flux sustained by soil supply from 1st soil node (Wm-2)
            RH=H2O*P/SoilProfile.e_sat(Ta); % air relative humidity (-) above ground
            h_atm=GasConst*(273.15+Ta).*log(RH)/(Mwater*9.81); % m, atm pressure head in equilibrium with atm. relative humidity
            
            LEmax=L_molar*1000/Mwater*obj.KLh(1)*(h_atm - obj.h(1) - obj.zs(1))/(2*obj.zs(1)); %mm/s(=kg/m2/s) / kg/mol*J/mol =J/m2/s=W/m2    
            clear h_atm RH

            %---------- solve surface temperature from energy balance ------------------------------------
            To=0.5*(Ta + obj.Tsurf); %initial guess 
            
            err=999;
            n=0;
            while err>0.01
                n=n+1;
                To_iter=To;
                LE_demand=L_molar*gb_v*(SoilProfile.e_sat(To)/P - H2O); % Wm-2, atmospheric demand   
                LE=min([LEmax LE_demand]);
                
                %solve To from energy balance
                Febal=@(To) Rabs - emi*b*(To +NT)^4 - cp*gb_h*(To - Ta) - LE - ks*(To - Ts);

                To=fzero(Febal,To_iter); %call fzero to find root

                err=abs(To - To_iter);

                if n>30, %case no convergence, break loop and return
                    To = Ta; % return previous value
                    H=0;
                    G=0;
                    LE=0;
                    return
                end
            end
            % negative values are downwards!
            LE=L_molar*gb_v*(SoilProfile.e_sat(To)/P - H2O); %Wm-2;
            H=gb_h*cp*(To-Ta); %W m-2
            G=-ks*(To-obj.T(1)); %W-2; negative value is from surface to deeper soil
            LWup=emi*b*(To+NT).^4; %Wm-2
            
            %error check
            if abs(To)>70 || abs(To-Ta) > 50,
                To=Ta; H=0; G=0; LE=0;
            end
        end
        
    end
    
    methods (Static)

%% *******************************************************************    
        function [gb_c,gb_v,gb_h]=Soil_boundarylayer_conductance(z,zo,U,Ta,dT,units)
        %function [gb_c,gb_v,gb_h]=Soil_boundarylayer_conductance(z,zo,U,To,Ta,units)
        %computes soil surface boundary layer conductance (mol m-2 s-1)
        %assuming velocity profile logarithmic between z and z0.
        %
        %INPUT: z - height of mean velocity U (m)
        %       zo - soil surface roughness length for momentum (m)
        %       U - mean flow velocity (ms-1) at z
        %       Ta - air temperature (degC) at z
        %       dT - temperature difference Tsoil - Tair (degC)
        %       units - 1=output in mol m-2 s-1, 0 or other for m s-1
        %
        %Based on Daamond & Simmons (1996). Note: gb decreases both in
        %unstable and stable conditions compared to near-neutral;
        %nonfeasible?
        %
        %Samuli Launiainen, 18.3.2014
        
        
            D_H=21.4e-6;    %Thermal diffusivity of air 20oC [m2/s]
            D_c=15.7e-6;    %Molecular diffusivity of CO2 in air at 20oC [m2/s]
            D_v=24.0e-6;     %Thermal diffusivity of water vapor in air at 20oC [m2/s]  

            rhoa=1013e2./(8.31*(Ta+273.15)); % molar density of air mol m-3

            delta=5*9.81*z*dT/((Ta+273.15)*U^2);
            if delta>0,
                d=-0.75;
            else
                d=-2;
            end
            rb=(log(z/zo))^2./(0.4^2.*U).*(1+delta).^d; % resistance s/m

            gb_h=1/rb; %heat, m/s
            gb_v=D_v/D_H*gb_h; %water vapor
            gb_c=D_c/D_H*gb_h; %CO2
            
            
            if units==1, %return conductances in mol m-2 s-1
                gb_c=rhoa.*gb_c;
                gb_v=rhoa.*gb_v;
                gb_h=rhoa.*gb_h;
            end
                
        end

%% ***********************************************************************        
        function x=SoilRH(T,h)
            %x=soil relative humidity (-) according Philip and de Vries, 1957
            %T=temperature (degC), h = pressure head (m)
            
            %%-------- constants
            grav=9.81; % acceleration due gravity, kgm/s2

            GasConst=8.314; % universal gas constant, Jmol-1
            Mwater=18.015e-3; % molar mass of water, kg mol-1
            
            x=exp(-(Mwater*grav.*-h)./(GasConst.*(T+273.15))); % relative humidity in soil pores (-)
        end
%% ***********************************************************************
        function [esat]=e_sat(T)
        % Saturation vapor pressure over water surface (Pa)
        % T in degC
            esat = 611.* exp((17.502.*T)./(T + 240.97)); %Pa
        end
        %% ***************************************************************

        function ss = dSdT(T)
        % the slope of saturation vapor pressure curve, de_s(T)/dT [in units Pa K^-1]
        %INPUT: T - [degC]
        %OUTPUT: ss - [Pa K-1]
            esat = 611.* exp((17.502.*T)./(T + 240.97)); %Pa (Stull 1988)
            ss=17.502.*240.97.*esat./((240.97+T).^2); % [Pa K-1], from Baldocchi's Biometeorology -notes
        end
  %% *********************************************************************
        function [head,Wl,Wi]=InitializeMatrixFromTheta(pF,fp,T,Wtot)
            %initializes matrix from Wtot and T
            Tfreeze=0; % Temperature at which freezing starts     
            N=length(Wtot);

            n=pF(:,4);
            m=1-1./n;
            alfa=pF(:,3);
        
            R=((pF(:,1)-pF(:,2))./(Wtot - pF(:,2))).^(1./m);
        
            head=-1./alfa.*(R-1).^(1./n); % head in cm
    
            % if Wtot> porosity,
            g=find(Wtot>=pF(:,1)); % saturated indexes
            head(g)=(Wtot(g) -pF(g,1))./pF(g,5); % head (cm)

            head=head/100; %m
            head(head<-20000)=-20000; 

            Wi=zeros(N,1); %ice content 
            k=find(T<=Tfreeze);
            Wi(k)=Wtot(k).*(1-exp(-(Tfreeze-T(k))./fp(k))); % frozen water content (m3/m3)  
            Wl=Wtot-Wi; % liquid water content (m3/m3)
            clear N T0 Wtot T  n m ts tr alfa k
        end % initial values
        
          %% *********************************************************************
        function [Wt,Wl,Wi]=InitializeMatrixFromHead(pF,fp,T,head)
            % initializes soil profile if inputs are head and T
            
            Tfreeze=0; % Temperature at which freezing starts     
            N=length(head);

            head=100*head; % cm
            Wt=ones(N,1).*NaN;

            for i=1:N, 
                n=pF(i,4);
                m=1-1./n; % n>1 in all cases!
                ts=pF(i,1);
                tr=pF(i,2);
                alfa=pF(i,3);
                if head(i)<0;
                    Wt(i)= tr + (ts - tr)/(1 + (-alfa.*head(i))^n)^m;
                else
                    Wt(i)= ts;
                end    
            end

            Wi=zeros(N,1); %ice content 
            k=find(T<Tfreeze);
            Wi(k)=Wt(k).*(1-exp(-(Tfreeze(k)-T(k))./fp(k))); % frozen water content (m3/m3)  
            Wl=Wt-Wi; % liquid water content
            clear N T0 head i n m ts tr alfa k
        end % initial values
        
   %% *****************************************************************
        function head=HeadFromTheta(Theta)
        %function head=HeadFromTheta(Theta) returns
        %hydraulic head (m) for given soil volumetric moisture content Theta
        %(m3/m3) and van Genughten soil paramters pF
        % pF=[ThetaS(m3/m3),ThetaR(m3/m3),alfa(-),n(-),com(1/m)] ! com is
        % compressibility'

        n=obj.pF(:,4);
        m=1-1./n;
        alfa=obj.pF(:,3);
        
        R=((obj.pF(:,1)-obj.pF(:,2))./(Theta - obj.pF(:,2))).^(1./m);
        
        head=-1./alfa.*(R-1).^(1./n); % head in cm
    
        % if Theta > ThetaSat,
        g=find(Theta>=obj.pF(:,1)); % saturated indexes
        head(g)=0;
        %head(g)=(Theta(g) -obj.pF(g,1))./obj.pF(g,5); % head (cm)

        head=head/100; %m
        head(head<-20000)=-20000; 

        end
   
   %% ********************************************************************
   
    function Theta=ThetaFromHead(head,pF)
        % function Theta=ThetaFromHead(head) calculates volumetric soil moisture
        % content Theta (m3/m3) from hydraulic head (m)
        % 
        % Parameters vector describing van Genughten soil paramters pF
        % pF=[ThetaS(m3/m3),ThetaR(m3/m3),alfa(-),n(-),poreconn]
        % head and pF-parameters can be scalars or vectors of equal lenght
        % pF as common variable among functions here!
            %N=length(head);

            head=100*head; % cm = hPa
            N=length(head);
            Theta=ones(N,1).*NaN;

            for k=1:N,

                n=pF(k,4);
                m=1-1./n; % n>1 in all cases!
                ts=pF(k,1);
                tr=pF(k,2);
                alfa=pF(k,3);
                if head(k)<0;
                    Theta(k)= tr + (ts - tr)/(1 + (-alfa.*head(k))^n)^m;
                    Theta(k)=max(Theta(k), tr); %residual water content is minimum
                else
                    Theta(k)= ts;
                end
            end
            clear head k n m ts tr alfa 
    end

    %% ********************************************************************

%    function x=DiffCapa(head)
%         % differential water capacity C=dTheta/dhead (1/m) based on
%         % analytical derivative of vanGenuchten water retention curve
%         head=-100*head; %cm, positive
%         
%         n=pF(:,4);
%         m=1-1./n; % n>1 in all cases!
%         ts=pF(:,1);
%         tr=pF(:,2);
%         alfa=pF(:,3);
%         
%         x=100*(ts-tr).*(n-1).*alfa.^n.*head.^(n-1)./((1 +(alfa.*head).^n).^(m+1)); %1/m
 
        
   function x=DiffCapa(head1,head2,pF)
       %numerical derivative of water retention curve.
       %Returns x = dTheta/dhead [1/m] 
       %USES: ThetaFromHead(head)

        % in case too small head difference, use predefined value for dhead
        head2(abs(head1-head2)<1e-5)= head1(abs(head1-head2)<1e-5) -1e-5;

        T1=SoilProfile.ThetaFromHead(head1,pF);
        T2=SoilProfile.ThetaFromHead(head2,pF);

        x=(T2-T1)./(head2 - head1); %[1/m]
        clear head1 head2 T1 T2
   end


    %% ********************************************************************
    function x=FrozenWater(Tsoil,Ws, fp)
        % Calculates frozen water content in soil layer
        %INPUT: Tsoil - soil temperature (degC); total water content Ws (m3/m3)
        % fp=empirical parameter of freezing curve (fp = 2..4 clay soils,
        % 0.5..1.5 sandy soils)
        % 
        %OUTPUT: x - frozen water content (m3/m3)
        % Empirical formulation (Koivusalo et al., 2001, TheorApplClimatol, eq. 18)
        T0=fp(:,1);
        fp=fp(:,2); 
        x=zeros(size(Ws));
    
        k=find(Tsoil<T0); % if temperature below T0, then calculate frozen water content
        x(k)=Ws(k).*(1-exp(-(T0(k)-Tsoil(k))./fp(k))); % frozen water content (m3/m3)
        clear k To fp   
    end

   %% ********************************************************************
   
        function [a, emi]=SoilAlbedo(Wliq_top)
            % estimates bare soil broadband albedo (a) and emissivity (emi) depending on soil moisture content
            % based on van Bavel and Hillel, 1976, Agric.For.Meteorol.,
            % 17:453-476
            
            if Wliq_top<0.1, a=0.25; end
            if Wliq_top>=0.25, a=0.1; end
            if Wliq_top>=0.1 && Wliq_top<0.25; a=0.35-Wliq_top; end
            
            emi=min([0.90 + 0.18*Wliq_top, 1.0]);
        end
        
 %% ***********************************************************************
        function [KLh,Ktherm]=InitializeConductivities(pF,Ksat,Wliq,Wice,vQuartz,vMineral,vOrganic)
                %liquid hydraulic conductivity (m/s)
                l=pF(:,7); % pore connectivity parameter, Mualem (1976)
                n=pF(:,4);
                m=1-1./n;

                Sat= min(1,(Wliq - pF(:,2))./(pF(:,1) - pF(:,2))); % effective saturation, S=[0,1]
                Sat= max(0,Sat);

                KLh=Ksat.*Sat.^l.*(1 -(1-Sat.^(n./(n-1))).^m).^2; % conductivity (m/s)
                
                %heat conductivity
                kw=0.57; % heat cond of water W/(mK) = J/(smK)
                ki=2.2; % heat cond of ice J/(smK)
                ka=0.025; % heat conductivity of air J/(smK)
                kq = 8.8; %Quarz  8.8 W/m/K
                km = 2.9; %other minerals W/m/K
                ko = 0.25; %organic matter W/m/K
    
                Wair=pF(:,1) - Wliq - Wice; %air filled porosity
                Ktherm=vQuartz.*kq + vMineral*km + vOrganic*ko + Wliq.*kw + Wice.*ki + Wair.*ka; % weighted thermal conductivity W/(mK)
        end

%% **************************************************************************************************************

        function [KLh, KLT, Kvh, KvT] = HydraulicConductivities(h,Ts,Wl,Wi, pF, GwT, clayfract, orgfract, flagTherm, flagVap,flagMacro,Ksmacro)
            % Calculates hydraulic conductivities (vectors or scalars) for variably saturated soils.
            % INPUT: 
            % h - hydraulic head (m) 
            % Ts - soil temperature (degC), 
            % Wl - volumetric liquid water content (m3/m3)
            % Wi - volumetric ice content (m3/m3)
            % pF - Parameters vector describing van Genughten soil paramters pF
               % pF=[ThetaS(m3/m3),ThetaR(m3/m3),alfa(-),n(-),com(1/m)] ! com is
                % compressibility
            % GwT - gain factor (-) for Thermal Hydraulic conductivity function
            % clayfract - fraction of clay in each layer (-)
            % orgfract - fraction of organic matter in each layer (-)
            % flagTherm - 1 if thermal hydraulic conductivity is calculated
            % flagVap - 1 if vapor phase hydraulic conductivity is calculated
            % flagMacro - 1 if effective conductivity is addjusted for
            %            preferential flow in wet conditions
            % Ksmacro - macropore conductivity
            %OUTPUT: 
            % KLh - liquid phase hydraulic conductivity due to head (m/s)
            % KLT - liquid hydraulic conductivity due to thermal gradient (m2 s-1 K-1) 
            % Kvh - vapor phase hydraulic conductivity due to head (m/s)
            % KvT - vapor phase hydraulic conductivity due to thermal gradient (m2 s-1 K-1) 
            % KLp - liquid phase hydraulic conductivity due to macropores (m/s)
            %
            % Samuli Launiainen, METLA 10-11/2011
            % Follows closely Hansson et al., 2004 Vadoze Zone Journal & Simuc�k et al., 2009 Hydrus-1D manual

            %%-------- constants
            grav=9.81; % acceleration due gravity, kgm/s2

            GasConst=8.314; % universal gas constant, Jmol-1
            Mwater=18.015e-3; % molar mass of water, kg mol-1
            rhow=1000; %water density, kg/m3

            %%------- 
            Thetasat=pF(:,1); % saturation water content (m3/m3)
            airvol=Thetasat - Wl -Wi; % air-filled porosity
            airvol(airvol>Thetasat)=Thetasat(airvol>Thetasat); airvol(airvol<0)=0;

            Theta=Wl; % here neglect contribution of solid water - assume for now that ice is part of matrix
            %Theta=Wl + Wi; % total water content

            %% hydraulic conductivity KLh (m/s)

            % Hydrus 1-D -manual eq. 2.30 (p.23) & Vereecken et al. Vadoze Zone Journal, 9:795-820,2010

            l=pF(:,7); % pore connectivity parameter, Mualem (1976)
            n=pF(:,4);
            m=1-1./n;

            Ks=pF(:,6); % saturated hydraulic conductivity m/s
            Sat= min(1,(Theta - pF(:,2))./(pF(:,1) - pF(:,2))); % effective saturation, S=[0,1]
            Sat= max(eps,Sat);

            KLh=Ks.*Sat.^l.*(1 -(1-Sat.^(n./(n-1))).^m).^2; % conductivity (m/s)

            KLh(Theta>=Thetasat)=Ks(Theta>=Thetasat);

        %     figure(100)
        %     subplot(221); plot(n,'r.-'); ylabel('n'); axis tight
        %     subplot(222); plot(m,'k.-'); ylabel('m'); axis tight
        %     subplot(223); plot(Ksat,'b.-'); ylabel('Ksat'); axis tight
        %     subplot(224); plot(Sat,'c.-'); ylabel('Sat'); axis tight
        %     pause

            % case ice exists in the layer, KLh is reduced by the blocking effect of ice
            % lenses (Hansson et al., 2004)
            % impedance factor as Shoop & Bigl, (1997), Cold.Reg.Sci.Technol. 25, 33-45.

            impfact= 5/4*(1/36*Ks -3).^2 +6; % (1/36*Ksat = cm/hour)
            %impfact = 4;
            %typically values 4-15 are reported...

            s= Wi./(Wl + Wi - pF(:,2)); %relative ice content
            KLh=10.^(-impfact.*s).*KLh; 
            
            %KLh(KLh<1e-15)=1e-15; %lower limit of plausible hydraulic conductivity
            KLh(KLh<1e-20)=1e-20; %lower limit of plausible hydraulic conductivity
            clear s impfact Sat
            
            
            %hydraulic conductivity in organic layers is based on Laur�n
            %1998 thesis Table 4, MT-type
%             orgfract=orgfract./(1-pF(:,1)); %relative fraction of organic matter
%             isorganic=find(orgfract>0.95);
%             h_org=h(isorganic)*10; %kPa
%             h_org(h_org>-4)=-4; h_org(h_org<-100)=-100; %parameterization of Laur�n et al is valid in range of ...4 kPa - 80 kPa, assume here that same scaling applies for larger range, until -200 kPa (-20 m)
%             Korg=10.^(1./(-0.648 + 0.268*log10(abs(h_org)))) ./ ( 10.^(1./(-0.648 + 0.268*log10(4))) ); %normalized conductivity, maximum is at 4 kPa
%             KLh(isorganic)=max(1e-15, Ks(isorganic).* Korg); 
%             clear Korg h_org
            
            
           % this is new code part describing effective macropore flow when h > -1m 
           if flagMacro==1,
               %Ksmacro is macropore conductivity in full saturation. m/s.
               KLm=zeros(size(KLh));
               hfc=-1; % m, approximates potential at field capacity
               KLm(h>hfc)=Ksmacro(h>hfc);

               KLm(h>hfc)=Ksmacro(h>hfc).*(hfc-h(h>hfc))./hfc; % adjust linearly in wet conditions when h>hfc
               KLh=KLh + KLm; % m/s
           end
           
            %% thermal hydraulic conductivity K_LT (m2 s-1 K-1) 
            if flagTherm==1
                KLT=KLh.*ThermalHydrCond(h,Ts,GwT);
            else
                KLT=zeros(size(KLh));  
            end
            %% isothermal (x, (m s-1)) and thermal (y, (m2 s-1 K-1)) vapor hydraulic conductivities
            if flagVap==1
                [Kvh,KvT]=VaporHydrCond(Ts,h,Theta,airvol,Thetasat);
                Kvh(h>=0)=0; %if profile is saturated, then no vapor and conductances go to zero.
                KvT(h>=0)=0;
            else
                Kvh=zeros(size(KLh));
                KvT=Kvh;        
            end
            
            %set here thermal and vapor conductivities zero in the organic layer
%             KLT(isorganic)=0;
%             Kvh(isorganic)=0;
%             KvT(isorganic)=0;
            
            % %  
            %     figure(100)
            %     subplot(221); plot(KLh,'r.-'); ylabel('K_{Lh}'); axis tight
            %     subplot(222); plot(KLT,'k.-'); ylabel('K_{LT}'); axis tight
            %     subplot(223); plot(Kvh,'b.-'); ylabel('K_{vh}'); axis tight
            %     subplot(224); plot(KvT,'c.-'); ylabel('K_{vT}'); axis tight
            %     pause

            %% ****************** internal function definitions *****************************************

            function x=ThermalHydrCond(h,Ts,GwT)
                % calculates thermal hydraulic conductivity K_LT (m2 s-1 K-1) 
                % HYDRUS-manual eq. 2.40 (as in Noborio et al. (1996))
                % h=pressure head (m), T= temperature (degC)
                % Gwt = gain factor (-); temperature dependency of water retention curve (7 for sand...)
                %
                h(h>0)=0; %negect hydrostatic pressure in saturated zone
                g0=71.89e-3; % surface tension of soil water at 25 degC (kg s-2)
                dgdt=(-0.1425 -2*2.38e-4.*Ts)*1e-3; % derivative of surface tension of soil water with respect to temperature, (kg s-2 K-1)

                x=(h.*GwT/g0.*dgdt); % (m s-1) * m *(1)*s2 kg-1* (kg s-2 K-1) = m2 s-1 K-1
            end

            function [x,y]=VaporHydrCond(Ts,h,Theta,airvol,Thetasat)
                % calculates isothermal (x, (m s-1)) and thermal (y, (m2 s-1 K-1)) vapor hydraulic
                % conductivities as in Hydrus 1-D manual, their eq. 2.42 & 2.43
                
                h(h>0)=0;
                
                Dv=VaporDiffusivity(Ts,airvol, Thetasat); %[m2/s]
                [vapsat,vapder]=SatVapDensity(Ts); % saturated vapor density (kgm-3) and derivative (kg m-3 K-1)
                rh=SoilRH(Ts,h); %[-], enter h negative!

                x=Dv./rhow.*vapsat.*(Mwater*grav)./(GasConst.*(Ts+273.15)).*rh; % isothermal vapor hydraulic conductivity (m s-1)

                %dimensionless enhancement factor, Cass (1984), Campbell (1985), Hydrus 1-D manual eq. 2.50: Thetasat, clayfract etc. are soil parameters 
                nu=ones(length(h),1).*NaN;
                for p=1:length(h),
                    if clayfract(p)~=0
                        nu(p)=9.5 +3*(Theta(p)./Thetasat(p)) - 8.5*exp(-((1 + 2.6./(clayfract(p).^0.5)).*(Theta(p)./Thetasat(p))).^4);
                    else
                        nu(p)=1;
                    end
                end
                clear p
                y=Dv./rhow.*nu.*rh.*vapder; %thermal vapor hydraulic conductivity (m2 s-1 K-1)

                clear Dv vapsat vapder rh nu
                

                % ---------- these subfunctions are visible only to function VaporHydrCond(...)-------------
                
                function x=VaporDiffusivity(T,airvol, Thetasat)
                    % calculates water vapor diffusivity in soil
                    % x= vapor diffusivity Dv (m2s-1) in soil
                    % T = temperature (degC), airvol air-filled porosity (m3m-3), 

                    tau_g=airvol.^(7/3)./(Thetasat.^2); % "torquosity factor" as Millington and Quirk (1961), ref. Saito et al. 2006 Vadose Zone J.
                                                    % note: not torquosity factor in typical menaning where tau_g>0 

                    x=tau_g.*airvol.*(2.12e-5.*((T+273.15)/273.15).^2); %bracketed term is diffusivity of water vapor in air 
                    clear tau_g Wsat
                end

                function [x,y]=SatVapDensity(Ts)
                    %returns saturated vapor density (kgm-3) and its derivative with
                    %respect to temperature (kg m-3 K-1)
                    %Hydrus 1D-manual eq. 2.46
                    Ts=Ts+273.15;
                    aa=31.3716; bb=6014.79; cc=7.92495e-3;

                    x=1e-3*exp(aa - bb./Ts -cc.*Ts)./Ts; % sat vapor density (kgm-3)
                    y=-1e-3*(-bb + cc.*Ts.^2 + Ts).*exp(aa -bb./Ts -cc.*Ts)./Ts.^3; % derivative respect to temperature (kg m-3 K-1)
                    clear aa bb cc Ts
                end

                function x=SoilRH(T,h)
                    %x=soil relative humidity (-) according Philip and de Vries, 1957
                    %T=temperature (degC), h = pressure head (m)
                    h(h>0)=0;
                    x=exp(-(Mwater*grav.*-h)./(GasConst.*(T+273.15))); % relative humidity in soil pores (-)
                end

            end % VaporHydrCond
            
            
        end % HydraulicConductivities
        
    %% ***********************************************************************

        function K=ThermalConductivity(P,T,h,Wl,Wi,Wsat,vQuartz,vMineral,vClay,vOrganic,method)
            % Calcualtes soil thermal conductivity (Wm-1K-1) for variably saturated and partially frozen soils
            % INPUT:
            % P - ambient pressure (Pa)
            % T - soil temperature (degC)
            % h - soil pressure head (m)
            % Wl - volumetric liquid water content (m3/m3)  
            % Wi - volumetric ice content (m3/m3),
            % Wsat - saturated water content (m3/m3)
            % vQuartz - volumetric fraction of quartz (m3/m3)
            % vMineral - volumetric fraction of other minerals (m3/m3)
            % vClay - volumetric fraction of clay (m3/m3)
            % vOrganic - volumetric fraction of organic material (m3/m3)
            % method - 1: weighted averaging, 2: Campbell, 1995 - model, 3:
            % de Vries 1963 according to Campbell and Norman, 1998
            %
            %OUTPUT: 
            % K - thermal conductivity (W m-1 K-1)
            %
            % NOTE: if vOrganic >0.95, K is estimated based on O'Donnell et al. 2009
            % Samuli Launiainen, Metla 2011-2013

            % Thermal conductivities are from, Hillel, D. 1998. Environmental
            % Soil Physics, Academic Press, San Diego, p.316   
    
            kw=0.57; % heat cond of water W/(mK) = J/(smK)
            ki=2.2; % heat cond of ice J/(smK)
            ka=0.025; % heat conductivity of air J/(smK)
            kq = 8.8; %Quarz  8.8 W/m/K
            km = 2.9; %other minerals W/m/K
            ko = 0.25; %organic matter W/m/K
            L_molar=44100; %J/mol latent heat of vaporization at 20 deg C
            
            h(h>0)=0; %under GWL 
            
            Wair=Wsat - Wl - Wi; %air filled porosity

            if nargin<8, %quick and dirty if not enough information. Stetson-Harrison method.

                K=(1-Wsat)*(0.25*kq + 0.75*km) + kw*Wl * ki*Wi; % W/(mK)   

            else 
                if method==1 % weighted volume average

                    K=vQuartz.*kq + vMineral*km + vOrganic*ko + Wl.*kw + Wi.*ki + Wair.*ka; % weighted thermal conductivity W/(mK)

                elseif method==2, %Campbell, 1995, extended by Hansson et al. 2004 for frozen conditions
                    % c1-c5 are from Hydrus 1-D code
                    c1=0.57 + 1.73*vQuartz + 0.93*vMineral./(1-0.74*vQuartz); %W/(mK)
                    c2=2.8*(1-Wsat); %W/(mK)
                    c3=1 +2.6*sqrt(max(0.005,vClay)); %[-]
                    c4=0.03 + 0.7*(1-Wsat); %W/(mK)
                    c5=4; %[-]

                    %Hansson et al, 2004 Kanagawa sandy loam
                    f1=13; %[-]
                    f2=1.06; %[-]
                    F=1 + f1.*Wi.^f2; %[-] 

        %             AAA=c1 + c2.*(Wl + F.*Wi);
        %             BBB=exp(-(c3.*(Wl + F.*Wi)).^c5);

                    K=c1 + c2.*(Wl + F.*Wi) - (c1-c4).*exp(-(c3.*(Wl + F.*Wi)).^c5); %W/(mK)
                    
                    %         Hansson et al, 2004 Kanagawa sandy loam        
                    %         c1=0.55; %W/(mK)
                    %         c2=0.80; %W/(mK)
                    %         c3=3.07; %[-]
                    %         c4=0.13; %W/(mK)
                    %         c5=4; %[-]
                end
                
                if method==3, % DeVries 1963 according to Campbell and Norman, 1998
                    
                    %shape factors
                    %solid phase
                    ga=ones(length(T),1).*0.125; % mineral soil
                    ga(vMineral+vClay+vQuartz<0.1)=0.33; % organic soil                    
                    
                    Wo=0.10;
                    q=4;
                    D_v=24.0e-6;     %Molecular diffusivity of water vapor in air at 20oC [m2/s]
                    
                    rh=SoilProfile.SoilRH(T,h); % soil RH
                    ss=SoilProfile.dSdT(T); % slope of saturation vapor pressure Pa K-1
                    es=SoilProfile.e_sat(T); % saturation vapor pressure (Pa)
                   
                    CF=P./(287.05*(T+273.15))/29e-3; % molar consentration of air, mol/m3
                    fw=1./(1 + (Wl/Wo).^(-q)); % correction factor for latent heat flux
                    
                    kg= ka + L_molar.*ss.*rh.*fw.*CF*D_v./(P-es); % vapor phase apparent thermal conductivity inc. Stefan correction (W m-1 K-1)
                    clear es ss rh
                    kf=kg + fw.*(kw -kg); %fluid thermal conductivity W m-1 K-1
                    ks=((vClay+vMineral)*km + vQuartz*kq + vOrganic*ko)./(1-Wsat); %volume-weighted solid conductivity Wm-1K-1

                    % weighting factors (-)
                    gg= 2/3*(1+ga.*(kg./kf -1)).^(-1) + 1/3*(1 + (1-2*ga).*(kg./kf -1)).^(-1); %gas phase
                    gw= 2/3*(1+ ga.*(kw./kf -1)).^(-1) + 1/3*(1 + (1-2*ga).*(kw./kf -1)).^(-1); %liquid phase
                    gs= 2/3*(1+ ga.*(ks./kf -1)).^(-1) + 1/3*(1 + (1-2*ga).*(ks./kf -1)).^(-1); %solid phase
                    
                    %gg=1/3*(1 + (kg./kf -1).*ga) + 1/3*
                    
                    %thermal conductivity according to DeVries 1963, ice added here separately
                    K=(Wl.*kw.*gw + kg.*(Wair).*gg + (1-Wsat).*ks.*gs + Wi*ki)./(Wl.*gw + Wair.*gg + (1-Wsat).*gs + Wi); %W m-1 K-1  
                end
                
                % for organic layers use typical values for boreal forest organic litter / moss from O'Donnell et al. 2009 Soil Science.
                K(vOrganic>0.95)= min(0.6,(0.03 + 5e-1*Wl(vOrganic>0.95)) + ki*Wi(vOrganic>0.95)); % W m-1 K-1
            end

            % Thermal conductivities are from, Hillel, D. 1998. Environmental
            % Soil Physics, Academic Press, San Diego, p.316
            % Quarz                    8.8 W/m/K
            % Other minerals (average) 2.9
            % Organic matter           0.25
            % Liquid water             0.57
            % Ice                      2.2
            % Air                      0.025  

            %Thermal conductances of soils and snow. Calculated from Hillel (2004) Env. Soil.Physics, Table 12.3.
            %
            %       Wliq(m3/m3) K(W/(mK))
            %
            % Sand  0.0         0.2929 porosity 0.4
            %       0.2         1.7573
            %       0.4         2.1757
            % Clay  0.0         0.2510 porosity 0.4
            %       0.2         1.1715
            %       0.4         1.5899
            % Peat  0.0         0.0586 porosity 0.8
            %       0.2         0.2929
            %       0.4         0.5021
            % Snow  0.05        0.0628 porosity 0.95
            %       0.2         0.1339          0.8
            %       0.5         0.7113          0.5    

        end
        
        function [Q, Qz_drain] = Drainage_Linear(zs,Ksat,GWL,DitchDepth,DitchSpacing)
            %calculates drainage to ditch using simple linear equation,
            %i.e. accounts only drainage from layers where GWL<DitchDepth
            %
            %INPUT:
            %   zs - depth of soil node (m), array, zs<0
            %   Ksat - saturated hydraulic conductivity (m/s),array
            %   GWL - ground water level below surface (m), GWL<0
            %   DitchDepth (m), depth of drainage ditch bottom
            %   DitchSpacing (m), horizontal spacing of drainage ditches
            %OUTPUT:
            %   Q - total drainage from soil profile (m/s), >0 is outflow
            %   Qz_drain - drainage from each soil layer (m m-1s-1), i.e. sink term to Richard's eq.
            
            dx=1; % unit length of horizontal element (m)
            
            N=length(zs);
            
            Qz_drain=zeros(N,1);
            dz=zeros(N,1);
            
            dz(2:N)=zs(1:N-1) - zs(2:N);% m
            dz(1)=-2*zs(1);
            
            Keff=Ksat.*dz/dx; %transmissivity m s-1
            hgrad=max(0,(GWL + DitchDepth)./(0.5*DitchSpacing)); % (-), positive gradient means flow towards ditches, return flow neglected
            
            drl=find((zs - GWL)<0 & zs>-DitchDepth); %layers above ditch bottom where drainage is possible

            Qz_drain(drl)=Keff(drl).*hgrad; %layerwise drainage ms-1
            Q=sum(Qz_drain);
            Qz_drain=Qz_drain./dz; %s-1, sink term

        end

        function [Q, Qz_drain] = Drainage_Hooghoud(zs,Ksat,GWL,DitchDepth,DitchSpacing,DitchWidth,Zbot)
            %calculates drainage to ditch using Hooghoud's drainage equation,
            %i.e. accounts only drainage from saturated layers above and below ditch bottom
            %
            %INPUT:
            %   zs - depth of soil node (m), array, zs<0
            %   Ksat - saturated hydraulic conductivity (m/s),array
            %   GWL - ground water level below surface (m), GWL<0
            %   DitchDepth (m), depth of drainage ditch bottom
            %   DitchSpacing (m), horizontal spacing of drainage ditches
            %   DitchWidth (m), ditch bottom width
            %   Zbot (m), distance to impermeable layer, scalar, <0
            %OUTPUT:
            %   Q - total drainage from soil profile (m/s), >0 is outflow
            %   Qz_drain - drainage from each soil layer (m m-1s-1), i.e. sink term to Richard's eq.
            %
            %REFERENCE:
            %   Follows Koivusalo, Lauren et al. FEMMA -document. Ref: El-Sadek et al., 2001. 
            %   J. Irrig.& Drainage Engineering.
            %
            % Samuli Launiainen, Metla 3.11.2014. 
            
            N=length(zs);
            
            Qz_drain=zeros(N,1);
            Qa=0; Qb=0;
            dz=zeros(N,1);
            dz(2:N)=zs(1:N-1) - zs(2:N);% m
            dz(1)=-2*zs(1);
            
            Hdr=max(0,GWL+DitchDepth); %depth of saturated layer above ditch bottom
            
            if Hdr>0,
                %disp('Hooghoud')
                Trans=Ksat.*dz; % transmissivity of layer, m2s-1
                
                %-------- drainage from saturated layers above ditch base
                dra=find((zs - GWL)<0 & zs> -DitchDepth); %layers above ditch bottom where drainage is possible
                Ka=sum(Trans(dra))/Hdr; %effective hydraulic conductivity ms-1
                
                Qa=4*Ka*Hdr.^2./DitchSpacing.^2; %m s-1, total drainage above ditches
                Qz_drain(dra)=Qa.*Trans(dra)/sum(Trans(dra))./dz(dra); % sink term s-1, rel=Trans(dra)/sum(Trans(dra)) partitions Qa by relative transmissivity of layer
                
                %-----drainage from saturated layers below ditch base
                drb=find(zs<=-DitchDepth & (zs - GWL)<0); % saturated layers below ditch bottom
                zbase= min(abs(min(zs) +DitchDepth), abs(min(zs) - GWL)); %depth of saturated layer below drain base
                Kb=sum(Trans(drb))/zbase;
                
                %compute equivalent depth Deq
                A=3.55 -1.6*Zbot/DitchSpacing -2*(2/DitchSpacing).^2;
                Reff=DitchWidth/2; %effective radius of ditch
                Dbt=-Zbot -DitchDepth; %distance from impermeable layer to ditch bottom
                
                if Dbt/DitchSpacing<=0.3,
                    Deq= Zbot./(1 + Zbot/DitchSpacing.*(8/pi*log(Zbot/Reff) - A)); %m
                else
                    Deq=pi*DitchSpacing/(8*log(DitchSpacing/Reff) - 1.15);
                end
                
                Qb=8*Kb*Deq*Hdr/DitchSpacing.^2; % m s-1, total drainage below ditches
                Qz_drain(drb)=Qb.*Trans(drb)/sum(Trans(drb))./dz(drb); % sink term s-1
            end
            Q=Qa + Qb; % drainage m s-1, positive is outflow
            
%             figure(1);
%             subplot(121); plot([0 1],[GWL GWL],'r-',[0 1],[-DitchDepth -DitchDepth],'k-')
%             subplot(122); plot(Qz_drain,zs,'r-'); ylabel('zs'), xlabel('Drainage s-1');
        end
        
    %% ******************************************************************************************************
        function xu=SpatialAverage(z,x,method)
            %calculates spatial average of quantity x,
            %z - space vector.
            %xu(i) - conductivity between node i-1 and node i, i.e. "to node i"
            %method - 1: arithmetic average, 2:resistors in series, weighted by
            %distance

            %dz=z(i)-z(i+1) >0, distance between nodes, z<0.

            N=length(z); % nr of nodal points, N is deepest node
           
            if method==1, % arithmetic average

                xu(2:N-1)=(x(1:N-2) + x(2:N-1))/2;
                xu(1)=x(1);
                xu(N)=x(N);
            end

            if method==2, %resistors in series

                xu(2:N-1)=(z(1:N-2) - z(3:N)).*( x(1:N-2).*x(2:N-1) ) ./ (x(2:N-1).*(z(1:N-2) - z(2:N-1)) + x(1:N-2).*(z(2:N-1) - z(3:N)));
                %for i=2:N-1,    
                    %xu(i)=(z(i-1) - z(i+1))*( x(i-1)*x(i) ) / ( x(i)*(z(i-1) -z(i)) + x(i-1)*(z(i) - z(i+1)) );          
                %end

                xu(N)=x(N); 
                xu(1)=x(1);
            end
            
            if method==3, %geometric mean
                xu(2:N-1)=sqrt(x(1:N-2).*x(3:N));
                xu(1)=x(1);
                xu(N)=x(N);
            end
            
        end
            

        % *********** Heat transport equation for homogenous soil layer ****************************************
        %(could be used in MLCM to create realistic lower BC for heat balance in the computational domain.
        
        function U = HeatEquation_HomogenousSoil(K,tm,x,Uxo,c1,c2,ubctype,lbctype)
        % function U = HeatEquation_HomogenousSoil(K,S,tm,m,x,Uxo,c1,c2,ubctype,lbctype)
        % Solves heat equation in homogenous soil using explicit Eulerian method:
        % Forward difference in time, centered in space

        % INPUT:    K - thermal diffusivity (m2/s) : thermal diffusivity is k/(rho_s*c_s)
        %           tm - time when result is expected
        %           x - grid (m)(from zero to lower boundary)
        %           Uxo - Initial temperature (degC)
        %           c1 - Upper boundary condition 
        %           c2 - Lower boundary condition 
        %           ubctype & lbctype - Type of boundary condition (1 = Dirchlet, specific
        %           value, 2 = Neumann, dU/dx specified)
        % OUTPUT:   U - temperature profile in the computational domain
        % Samuli Launiainen 22.02.2011

            m=100; % number of subtimesteps
            
            S=zeros(size(x));
            n=length(x); %number of gridpoints
            dt=tm/m; % time increment
            dx=abs(x(1) - x(2)); % space increment

            R= K*dt/(dx^2); % mesh Fourier number

            if abs(R>0.5),
                disp('HeatEquation_HomogenousSoil: solution unstable, check dx & dt')
                return
            end
            
            
            U=Uxo; % initial condition at to

            %% solve FTCS-difference equation: explicit Eulerian method: Forward difference in time, centered in space

            if ubctype==1 && lbctype ==1 % Dirchlet boundary conditions (specified value at boundary)
                U=Uxo;
                U(1)=c1;
                U(n)=c2;

                for j=2:m %time-loop
                    for i=2:n-1 % x-loop
                        %d2tdx=(U(i-1,j-1) - 2*U(i,j-1) + U(i+1,j-1))/(dx^2) 
                        U(i)=Uxo(i) + R*( U(i-1) - 2*U(i) + U(i+1) ) +dt*S(i);
                    end
                    Uxo=U; %new temperature
                    %pause
                end

            end

            if ubctype==2 && lbctype ==2 % Neumann (dU/dx specified at upper & lower grid point)
                U=Uxo; % initial condition at to

                for j=2:m %t-loop
                    %upper boundary   
                     U(1)=Uxo(1) + R*( 2*U(2) -2*U(1) -2*dx*c1);
                     for i=2:n-1 % nodes 2 to n-1
                       U(i)=Uxo(i) + R*( U(i+1) -2*U(i) + U(i-1)) +dt*S(i);
                     end
                        %lower boundary   
                     U(n)=Uxo(n) + R*( 2*U(n-1) -2*U(n) +2*dx*c2);
                     Uxo=U; % new temperature
                end
               
            end
        end % end HeatEquation_HomogenousSoil

    end % end static methods

end % SoilProfile

