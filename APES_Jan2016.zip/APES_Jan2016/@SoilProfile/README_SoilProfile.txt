

******** README_SoilProfile.txt ***********************

Date: 09.02.2015 / Samuli Launiainen

*************************************************

Folder /@SoilProfile: 

Contains Multi-layer Atmosphere-Plant Exchange Simultator (APES) codes for "SoilProfile" -object.

Files currently used in APES:

SoilProfile.m : class generator and class-instance dependent & static functions for SoilProfile -related processes

Soil_WaterFlow.m : 1-D Richards equation with variable boundary conditions (BC's) formulated as flux-based. 
		   MBE's small in all cases
Soil_HeatFlow.m : 1-D Fourier equation with variable boundary conditions (BC's) formulated as flux or temperature -based

**************************************************

Not currently in use:

Soil_WaterFlow_DynamicBC.m : 1-D Richards equation with variable boundary conditions (BC's) formulated either as flux or head-based. 
							 MBE's can become large in case of rapid infiltration / drainage. 
							 This is due to inaccurate approximation of boundary fluxes, not numerics in the code.

**************************************************
Example of SoilProfile -object, see class def. for explanations and units.

  SoilProfile

  Properties:
                   zs: [33x1 double]
                  dzs: [33x1 double]
              cosalfa: 1
           NrOfLayers: 33
                   pF: [33x7 double]
                 Ksat: [33x1 double]
                KsatH: [33x1 double]
               Kmacro: [33x1 double]
                  GwT: [33x1 double]
              vQuartz: [33x1 double]
             vMineral: [33x1 double]
                vClay: [33x1 double]
             vOrganic: [33x1 double]
              vStones: [33x1 double]
    FreezingCurvePara: [33x2 double]
         MaxPondDepth: 0.0500
             porosity: [33x1 double]
                 Wsat: [33x1 double]
            Rsoil_Q10: 2
            Rsoil_R10: 3.5000
              zo_soil: 1.0000e-003
               PARalb: 0.2000
               NIRalb: 0.3000
           emissivity: 0.9800
                    T: [33x1 double]
                    h: [33x1 double]
                 Wliq: [33x1 double]
                 Wice: [33x1 double]
                 Wtot: [33x1 double]
                  GWL: -1.6100
               h_pond: 0
                Tsurf: 8.2055
                  KLh: [33x1 double]
               Ktherm: [33x1 double]
           DitchDepth: 0.5000
         DitchSpacing: 40

  Methods

 SoilProfile describes soil matrix physical properties,preserves values
 of state variables and contains SoilProfile method definitions
 
  Modified 26.7: (initialization and added properties) / Samuli


Methods for class SoilProfile:

SoilProfile                      Soil_WaterFlow                   SurfaceEnergyBalance_Linearized  
SoilRespiration                  Soil_WaterFlow_DynamicBC         
Soil_HeatFlow                    SurfaceEnergyBalance             


Static methods:

DiffCapa                         InitializeConductivities         ThermalConductivity              
Drainage_Hooghoud                InitializeMatrixFromHead         ThetaFromHead                    
Drainage_Linear                  InitializeMatrixFromTheta        dSdT                             
FrozenWater                      SoilAlbedo                       e_sat                            
HeadFromTheta                    SoilRH                           
HeatEquation_HomogenousSoil      Soil_boundarylayer_conductance   
HydraulicConductivities          SpatialAverage                   






