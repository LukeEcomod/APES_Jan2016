% Scalar profiles in canopy air space and leaf-scale responses

%% filter data 

sname='Demo '
fdayn=1;
ldayn=365;
daynum=Doy;
PrecIndex=TimeAve(PrecW,48,1); % 0 if no P during last 24h
%ustar=Ust(fi:li);
% RH_ref=FORCING(:,10);
% CO2_ref=FORCING(:,11);
% H2O_ref=FORCING(:,12);
% T_ref=FORCING(:,9);

j=find( (daynum>fdayn & daynum<ldayn) );% "select periods
dryc=find(PrecIndex==0 & RH_ref<90 & ustar>0.1); % dry conditions, with reasonable mixing
k=intersect(j,dryc);
length(k)

zn=z./hc; % normalized height
%% Ensemble-average profiles

fh=12; lh=15;    % time span of the profile (daytime)
ff=find(tvec(:,3)>=fh & tvec(:,3)<=lh);% & Fwat(:,zabo)>0 & Fwat(:,zabo)< 400 & Fc(:,zabo)~=0);
f=intersect(ff,k);
clear ff

fh=0; lh=4;    % time span of the profile (nighttime)
ff=find(tvec(:,3)>=fh & tvec(:,3)<=lh);% & Fwat(:,zabo)>0 & Fwat(:,zabo)< 400 & Fc(:,zabo)~=0);
g=intersect(ff,k);

%leaf area density profile
N=length (z); % length of the grid in datapoints
LAD=Stand_1.lad; % Leaf-area profile, integrated gives unity

%---------Normalized scalar profiles-------------
[r,c]=size(oMeteo.CO2);
nCO2=zeros(r,c).*NaN;
nH2O=nCO2;
nTa=nCO2;
nU=nCO2;

for ff=1:c,
    nCO2(:,ff)=oMeteo.CO2(:,ff)./CO2_ref(ff);
    nH2O(:,ff)=oMeteo.H2O(:,ff)./H2O_ref(ff);
    nTa(:,ff)=oMeteo.T(:,ff)./T_ref(ff);
    nU(:,ff)=oMeteo.U(:,ff)./oMeteo.U(end,ff); % normalized mean velocity profile
end
clear rc

h=figure('Name', [figtext ' Prof Microclimate'], 'NumberTitle','on','PaperOrientation','Portrait','PaperUnits','normalized',...
    'PaperPositionMode','manual','PaperPosition', [0.1 0.1 0.8 0.8]);
set(gcf, 'PaperOrientation','Portrait','PaperUnits','normalized','PaperPosition', [0.1 0.1 0.8 0.8])

subplot(2,3,1); 
%txt=sprintf('LAI=%02.1f,'Stand_1.LAI);
A=Stand_1.lad*Stand_1.LAI;
plot(A./max(A),zn,'k-','Linewidth',1); hold on;
plot(nanmean(oRadi.f_sl(:,f),2),zn,'-','color','r','Linewidth',1); hold on;
xlabel('\it{\Lambda_l & f_{sl} (-)}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10)
ylim([0 1.01]); xlim([0 1.01])
legend('\Lambda_l','f_{sl}');
title([sname num2str(year) '-days ' num2str(fdayn) '-' num2str(ldayn)]);

subplot(2,3,2);
plot(nanmean(nU(:,f),2),zn,'-','color','r','Linewidth',1); hold on;
xlabel('\it{U/U_{,ref} (-)}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10)
%ylim([0 max(zn)+0.05]); 
ylim([0 1.01]); axis tight
title(['Profiles' num2str(year) '-days ' num2str(fdayn) '-' num2str(ldayn)]);



subplot(2,3,3); %PAR and NIR profiles
plot(nanmean(oRadi.SWb1(:,f),2),zn,'-','color','r','Linewidth',1); hold on;
plot(nanmean(oRadi.SWd1(:,f),2),zn,'-','color','g','Linewidth',1); hold on;
plot(nanmean(oRadi.SWu1(:,f),2),zn,'-','color','b','Linewidth',1); hold on;
legend('SW_b','SW_d','SW_u','Location','SouthEast')
xlabel('\it{PAR, Wm^{-2}(ground)}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10); axis tight
ylim([0 1.01])

subplot(2,3,4)
plot(nanmean(oRadi.SWb2(:,f),2),zn,'-','color','r','Linewidth',1); hold on;
plot(nanmean(oRadi.SWd2(:,f),2),zn,'-','color','g','Linewidth',1); hold on;
plot(nanmean(oRadi.SWu2(:,f),2),zn,'-','color','b','Linewidth',1); hold on;

xlabel('\it{NIR, Wm^{-2}(ground)}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10); axis tight
ylim([0 1.01])

subplot(2,3,5); %LW
plot(nanmean(oRadi.LWnet(:,f),2),zn,'-','color','r','Linewidth',1); hold on;
plot(nanmean(oRadi.LWnet(:,g),2),zn,'-','color','k','Linewidth',1); hold on;
xlabel('\it{LW_{n}^* (Wm^{-2})}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10)
ylim([0 1.01]); 
legend('day','night')

subplot(2,3,6)
Rn_sl=nanmean(oRadi.q_sl1(:,f) + oRadi.q_sl2(:,f) + oRadi.LWnet(:,f),2);
Rn_sh=nanmean(oRadi.q_sh1(:,f) + oRadi.q_sh2(:,f) + oRadi.LWnet(:,f),2);
Rn_sl(zn>=1)=NaN; Rn_sh(zn>=1)=NaN;
fsunlit=nanmean(oRadi.f_sl(:,f),2);
Rn_lay=fsunlit.*Rn_sl + (1-fsunlit).*Rn_sh;
plot(nanmean(Rn_sl,2),zn,'-','color','r','Linewidth',1); hold on;
plot(nanmean(Rn_sh,2),zn,'--','color','b','Linewidth',1); hold on;
plot(nanmean(Rn_lay,2),zn,'-','color','k','Linewidth',2); hold on;
xlabel('\it{R_{n}^* (Wm^{-2}(leaf))}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10)
ylim([0 1.01]); xlim([0 250])
legend('R_{n,sl}^*','R_{n,sh}^*','R_{n}^*','Location','SouthEast')


%print(h,['Figs\' sname '_microclimate.eps'],'-depsc')


%%
h=figure(101);
set(h, 'PaperOrientation','Portrait','PaperUnits','normalized','PaperPosition', [0.1 0.1 0.8 0.8])

subplot(331); 
%txt=sprintf('LAI=%02.1f,'Stand_1.LAI);
A=Stand_1.lad*Stand_1.LAI;
plot(A./max(A),zn,'k-','Linewidth',1); hold on;
plot(nanmean(oRadi.f_sl(:,f),2),zn,'-','color','r','Linewidth',1); hold on;
xlabel('\it{\Lambda_l & f_{sl} (-)}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10)
ylim([0 1.01]); xlim([0 1.01])
legend('\Lambda_l','f_{sl}', 'Location','East');
title([sname  num2str(year) '-days ' num2str(fdayn) '-' num2str(ldayn)]);


subplot(332);

An_lay=oRadi.f_sl.*oDLF(1).sl.An + (1-oRadi.f_sl).*oDLF(1).sh.An;

plot(nanmean(oDLF(1).sl.An(:,f),2),zn,'r-','Linewidth',1); hold on;
plot(nanmean(oDLF(1).sh.An(:,f),2),zn,'b-','Linewidth',1); hold on;
plot(nanmean(An_lay(:,f),2),zn,'k-','Linewidth',2); hold on;
xlabel('\it{A_n(umolm^{-2}(leaf)s^{-1})}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10)
axis tight; ylim([0 1.01]);

subplot(333);

E_lay=oRadi.f_sl.*oDLF(1).sl.E + (1-oRadi.f_sl).*oDLF(1).sh.E;

plot(nanmean(oDLF(1).sl.E(:,f),2),zn,'r-','Linewidth',1); hold on;
plot(nanmean(oDLF(1).sh.E(:,f),2),zn,'b-','Linewidth',1); hold on;
plot(nanmean(E_lay(:,f),2),zn,'k-','Linewidth',2); hold on;
xlabel('\it{E (mmolm^{-2}(leaf)s^{-1})}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10)
axis tight; ylim([0 1.01]);

subplot(334);

gsv_lay=oRadi.f_sl.*oDLF(1).sl.gsv + (1-oRadi.f_sl).*oDLF(1).sh.gsv;
plot(nanmean(oDLF(1).sl.gsv(:,f),2),zn,'r-','Linewidth',1); hold on;
plot(nanmean(oDLF(1).sh.gsv(:,f),2),zn,'b-','Linewidth',1); hold on;
plot(nanmean(gsv_lay(:,f),2),zn,'k-','Linewidth',2); hold on;
xlabel('\it{g_{s,v} (molm^{-2}(leaf)s^{-1})}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10)
axis tight; ylim([0 1.01]);

subplot(335);
Ca=1e6*oMeteo.CO2;
Ca(Ca>600)=NaN;
cica_sl=oDLF(1).sl.Ci./Ca;
cica_sh=oDLF(1).sh.Ci./Ca;
cica_lay=oRadi.f_sl.*cica_sl + (1-oRadi.f_sl).*cica_sh;
plot(nanmean(cica_sl(:,f),2),zn,'r-','Linewidth',1); hold on;
plot(nanmean(cica_sh(:,f),2),zn,'b-','Linewidth',1); hold on;
plot(nanmean(cica_lay(:,f),2),zn,'k-','Linewidth',2); hold on;
xlabel('\it{c_i/c_a (-)}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10)
axis tight; ylim([0 1.01]); 

subplot(336);

WUE_sl=1e-3*oDLF(1).sl.An./oDLF(1).sl.E; %mumol CO2 mmol H2O
WUE_sh=1e-3*oDLF(1).sh.An./oDLF(1).sh.E;
WUE_lay=oRadi.f_sl.*WUE_sl + (1-oRadi.f_sl).*WUE_sh;

plot(nanmean(WUE_sl(:,f),2),zn,'r-','Linewidth',1); hold on;
plot(nanmean(WUE_sh(:,f),2),zn,'b-','Linewidth',1); hold on;
plot(nanmean(WUE_lay(:,f),2),zn,'k-','Linewidth',2); hold on;
xlabel('\it{WUE (\mumol(CO2) mmol(H2O)^{-1})}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10)
axis tight; ylim([0 1.01]); 


subplot(3,3,[7 8]);

T_lay=oRadi.f_sl.*oDLF(1).sl.Tleaf + (1-oRadi.f_sl).*oDLF(1).sh.Tleaf;
plot(nanmean(oMeteo.T(:,f),2),zn,'k--','Linewidth',1); hold on;
plot(nanmean(oDLF(1).sl.Tleaf(:,f),2),zn,'r-','Linewidth',1); hold on;
plot(nanmean(oDLF(1).sh.Tleaf(:,f),2),zn,'b-','Linewidth',1); hold on;
plot(nanmean(T_lay(:,f),2),zn,'k-','Linewidth',2); hold on;
xlabel('\it{T_{leaf} (^{\circ}C)}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10)
axis tight; ylim([0 1.01])
legend('T_a','T_{l,sl}','T_{l,sh}','T_{l,ave}','Location','NorthEast');

subplot(339);

H_lay=oRadi.f_sl.*oDLF(1).sl.H + (1-oRadi.f_sl).*oDLF(1).sh.H;

plot(nanmean(oDLF(1).sl.H(:,f),2),zn,'r-','Linewidth',1); hold on;
plot(nanmean(oDLF(1).sh.H(:,f),2),zn,'b-','Linewidth',1); hold on;
plot(nanmean(H_lay(:,f),2),zn,'k-','Linewidth',2); hold on;
xlabel('\it{H (Wm^{-2}(leaf))}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10)
xlim([-20 170]); ylim([0 1.01]);

