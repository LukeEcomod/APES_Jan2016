%------------- this script initializes APES (Atmosphere-Plant Exchange Simulator) using loosely SMEAR II-data  ------------------------
%
% Calls APES_main_vJan2016 at last line
%
clear all; close all;

import DataAnalysis.TimeAve

folder='D:\APES_Jan2016\'; %define folder where APES is

%------------ Simulation period ------------------------
year=2005;
fmonth=6;
fday=1;

lmonth=6;
lday=2;
Doy0=datenum(year,fmonth,fday) - datenum(year,1,0); %doy when simulation starts

% --- give above-ground computational grid ------------

zmax=20; % height of uppermost layer (m)
N=200; % number of gridpoints
dz=zmax/(N-1);
z=[0:dz:zmax]';
clear zmax 

%-------- Main program controls------------
MAIN.dt=1800; % forcing timestep (s)
MAIN.dt_output=1800; %output timestep (for saving results)
MAIN.Switch_EnsembleFlow='y'; %use ensemble-averaged flow statistics
MAIN.Switch_WMA='n'; %use well-mixed profiles (neglect mixing) within canopy
MAIN.Switch_Figures='n';    %not active now
MAIN.Soil_WaterFlow_LBC=[-1; 0]; %lower BC for Soil_WaterFlow. [type(-1=impermeable, 0=prescibed head, 1=free drainage(until field capacity); value(needed for head-boundary)]
MAIN.Soil_HeatFlow_LBC=[1; 0];  %lower BC for Soil_HeatFlow
MAIN.tau_m=1/2; %time constant (1/day) for leaf water potential feedbacks

MAIN.forcingfile=[folder sprintf('FORCINGS\\FIHy\\Forcing_%04d.dat',year)]; %forcing file path

%rf=sprintf('Res_%02d%02d%02d%02d.mat',fmonth,lmonth,fday,lday);
MAIN.resultsfile=[sprintf('R%04d_%02d%02d%02d%02d.mat',year,fmonth,lmonth,fday,lday)]; %saved into main folder

MAIN.Save_LeafFluxes='y';

%% ----------------------------- READ FORCING DATA FROM ASCII-FILE -----------------------

dat=load(MAIN.forcingfile);

time=dat(:,1:5);
f1=find(time(:,1)==year & time(:,2)==fmonth & time(:,3)>=fday, 1 ); % starting index
f2=find(time(:,1)==year & time(:,2)==lmonth & time(:,3)<=lday, 1, 'last' ); % ending index
time=time(f1:f2,:);

Tdaily=TimeAve(dat(1:f1-1,8),48,2); %calculates daily Tair from 1st Jan to simulation start (for initial condition of phenology & LAI)

dat=dat(f1:f2,:);

%------ UBC-values at the uppermost gridpoint
FORCING=struct();
FORCING.time=time;
FORCING.U=dat(:,6); %meas. mean wind speed (m/s)
FORCING.Ustar=dat(:,7) +1e-2; % friction velocity (m/s), Has to be >0.02 m/s for numerical stability (due function 'generate_flow' in +MicroMet)
FORCING.Utop_Ensemble=5.06; % ensemble-average U/Ustar (-) at reference height. Speeds up calculations if ensemble-averaged flow statistics are used

FORCING.Ta=dat(:,8); %degC
FORCING.RH=dat(:,9); % %
FORCING.CO2=dat(:,10); %CO2 mixing ratio (ppm)
FORCING.CO2=1e-6*FORCING.CO2; % CO2 mixing ratio (mol/mol)
FORCING.H2O=1e-3*dat(:,11); %H2O mixing ratio (mol/mol)

FORCING.Prec=dat(:,13)/MAIN.dt; % precipitation rate (mm/s = kg/m2/s)
FORCING.Pamb=1e2*dat(:,14); %Pressure (Pa)
FORCING.PARdir=dat(:,15); %direct PAR in (Wm-2)
FORCING.PARdif=dat(:,16); %diffuse PAR in (Wm-2)
FORCING.NIRdir=dat(:,17); % direct NIR radiation (Wm-2)
FORCING.NIRdif=dat(:,18); % diffuse NIR radiation (Wm-2)
FORCING.emi_atm=dat(:,29); %atm. emissivity (-)

FORCING.Tdaily=TimeAve(FORCING.Ta,48,2); %daily mean temperature 
%FORCING.LWin=dat(:,20);  %downwelling LW (Wm-2), SMEAR II 2010-->
%FORCING.LWout=dat(:,21);  %upwelling LW (Wm-2), SMEAR II 2010-->
%PAR=0.45 x Rg, NIR = 0.55 x Rg, Jones H.(1992): Plants and Microclimate: ... Cambridge, 1992

clear dat time fday lday

% load initial profile of bedrock temperature; this is used to get boundary
% condition for soil heat balance
Tsz=load([folder '\FORCINGS\FIHy\Hyde_Tz_deep2005.dat']);

T0=Tsz(Tsz(:,1)==Doy0,2:end); % bedrock initial temperature profile;
T0=[Tsz(1,2:end)' T0'];

clear f1 f2  year fmonth lmonth fdoy Tsz

%[Hint!: Access to data in Struct fields is as: dummy=FORCING.Ta]

%% **************** ------ Bedrock -object --------- ******************
DampDepth=10;
zsb=-[0:0.4:DampDepth]';

ThermalConductivity=3; %Wm-1K-1=J s-1 m-1 K-1
SpecificHeat=820; %J kg-1 K-1
Density=2.65e3; %kg m-3

Tannual=4.5;
Bedrock_1=Bedrock(zsb,T0,Tannual,ThermalConductivity,SpecificHeat,Density);

clear T0 K zsb Tannual DampDepth ThermalConductivity SpecificHeat Density


%% **************** ------ SoilProfile -object ----------- *******************

SP=struct();

SP.cosalfa=1; % cosine of slope normal vertical flow, [1= vertical flow, 0=horizontal flow]
SP.DitchDepth=0.50; % m, depth of drainage ditches
SP.DitchSpacing=40; % m, ditch spacing

SP.MaxPondDepth=0.05; % m, maximum ponding depth allowed at the surface

zs=-[0.01 0.02 0.03 0.04 0.05 0.06:0.02:0.6]'; %soil grid, m
K=length(zs);

SP.zs=zs;

%------ Soil physical properties -----------
pF=ones(K,7).*NaN; %[ThetaS(m3/m3) ThetaR(m3/m3) alfa(-) n(-) compressibility(1/m) Kzsat(m/s) poreconnectivity]

%volumetric fractions of soil consituents; used in calculation of e.g. thermal conductivity
vQuartz=ones(K,1).*NaN; vMineral=ones(K,1).*NaN; vClay=ones(K,1).*NaN; vOrganic=ones(K,1).*NaN; vStones=ones(K,1).*NaN;

%------- organic L & F -layers ------------- 'litter & fermented'
for i=1:3
    %pF=[ThetaS(m3/m3) ThetaR(m3/m3) alfa(-) n(-) compressibility(1/m) Kzsat(m/s) poreconnectivity]
    pF(i,:)=[0.92 0.015 1.72 1.30 1e-5 4e-6 0.5]; % Lauren thesis, Table 2 MT-mean o1
    vQuartz(i)=0; % volume fraction of quartz minerals (-)
    vMineral(i)=0; % volume fraction of other minerals (-)
    vClay(i)=0; % volume fraction of clay (-)
    vOrganic(i)=1-pF(i,1); % volume fraction of organic matter (-)
    vStones(i)=0;
    
end

% %------organic H-layer-------- 'humus'
for i=4:5,
    pF(i,:)=[0.88 0.01 0.70 1.23 1e-5 4e-6 0.5]; % Lauren thesis, Table 2 MT-mean o2
    vQuartz(i)=0; % volume fraction of quartz minerals (-)
    vMineral(i)=0; % volume fraction of other minerals (-)
    vClay(i)=0; % volume fraction of clay (-)
    vOrganic(i)=1-pF(i,1); % volume fraction of organic matter (-)
    vStones(i)=0;
    
end

%------Mineral soil -----------
for i=6:K
    pF(i,:)=[0.4	0.096	0.06	1.35 1e-5 3e-6 0.5]; %
    vClay(i)=0.03; % volume fraction of clay (-)
    vOrganic(i)=0.1; % volume fraction of organic matter (-)
    vQuartz(i)=(1-pF(i,1)-vOrganic(i))*0.2; % volume fraction of quartz minerals (-) %Melkerud et al., 2000 Geoderma, ~20% of minerals in B-horizon are quartz
    vMineral(i)=1-pF(i,1)-vClay(i) -vOrganic(i) - vQuartz(i);
    vStones(i)=0.0;

end

clear i

SP.pF=pF; 
SP.vClay=vClay; SP.vMineral=vMineral; SP.vQuartz=vQuartz; SP.vOrganic=vOrganic; SP.vStones=vStones;
clear pF vClay vMineral vQuartz vOrganic vStones

%----- Adjustment for macropore conductivity (m/s) in case soils are wet
SP.Kmacro=zeros(K,1);
SP.Kmacro(1:K)=100*SP.pF(1:K,6); %increase K_sat by two orders of magnitude 

%saturated horizontal hydraulic conductivity
SP.KsatH=SP.pF(:,6);

SP.GwT=ones(K,1)*7; % 'gain factor', temperature dependency of pF -curve

%---- Soil freezing characteristics [Tfreeze para]
SP.FreezingCurvePara=[ones(K,1)*0 ones(K,1)*0.5]; %[Tfreeze para_freeze]

%------- soil respiration parameters (Kolari et al. 2009)
SP.Q10=2.0; % Temp. sensitivity (-)
SP.R10=3.5; % Base respiration rate at 10degC(mumolm-2s-1)

%------ soil surface physical parameters
SP.zo=1e-3; %m, soil roughness length
SP.PARalb=0.2; %soil PAR albedo
SP.NIRalb=0.3; %soil NAR albedo
SP.emi=0.98;

% ------------ soil profile initial conditions -----------------------------


T=interp1([0 min(zs)],[FORCING.Ta(1) Bedrock_1.T(1)],zs,'linear');
%ho=ones(K,1).*-0.00001; % pressure head (m)
ho=flipud(zs)-0.01; % soil water potential in hydrostatic equilibrium and nearly-saturated conditions at profile bottom

IniCond.Wtot=[];
IniCond.h=ho; clear ho
IniCond.T=T;
IniCond.GWL=[];
IniCond.h_pond=0;

%------------create SoilProfile -object-----------
Soil_1=SoilProfile(SP,IniCond);

clear SP IniCond Wtot T K

%[Hint! type Soil_1 in workspace to see properties and list of functions. Look @SoilProfile for class definition, state variables and
%functions. Matlab treates all functions within @ClassName -folder to belong into class ClassName]
%% ************* CREATE PlantType -ohjects *******************************

% ****** PlantType_1 ***************************

Species = 'Overstory'; %species name
Switch_LAI='n'; %; 'y' - include seasonal LAI dynamics
Switch_Pheno='n'; %'y' include phenology
Switch_Stoma_PsiL='y'; %'y' - adjust stomatal parameters based on pre-dawn leaf water potential proxy

% physical attributes of Species cohort
PT.hmax =15; %canopy height (m)
PT.LAImax =3.5; %maximum annual 1-sided LAI (m2/m2)
PT.LAImin=0.8*PT.LAImax; %minimum annual 1-sided LAI (m2/m2)
PT.WAI =0.15*PT.LAImax; %woody area index (m2/m2): Assumption is based on Chen_etal 2006AFM

%----- create leaf- and woody area densities (m2/m3) from Weibull-shape parameters (Teske & Thistle, 2004)
b=0.4;
c=2.7;

PT.lad=PlantType.generate_LAD_Weibul(z,1,PT.hmax,b,c); %leaf-area density shape: sum(lad*dz)=1, multiply by LAI to get real values

%create woody area profile, adding small number to b gives more weight to lower canopy
wad=PlantType.generate_LAD_Weibul(z,1,PT.hmax,b+0.05,c); clear b c
PT.wad=wad/sum(wad)/dz;

PT.lt=0.02; %characteristic leaf dimension (m)
PT.emi=0.98; %emissivity for thermal radiation
PT.PARalb=0.12; %leaf PAR albedo, adjusted for within-shoot scattering
PT.NIRalb=0.50; %leaf NIR albedo, adjusted for within-shoot scattering. value ~0.5 seems to give good stand albedo for Global radiation

PT.Wmaxrain=0.15; %(mm / unit of LAI), maximum interception capacity of liquid precipitation
PT.Wmaxsnow=0.3; %(mm / unit of LAI), maximum interception capacity of snowfall: does not impact anything yet!

%************** root zone properties **********************
Root.RootDepth=0.6; %rooting depth (m)
Root.RAI=2*PT.LAImax;  %total fine root area index (m2/m2); this can be derived from typical species-dependent RAI - LAI -relation
Root.beta=0.943; % shape parameter for root distribution model. Y=1-beta.^z_in_cm; Y=cumulative distribution (Gale & Grigal 1987)
Root.FineRootRadius=2e-3; %m, default 2e-3
Root.RadialConductivity= 5e-8; % s-1, maximum bulk root membrane conductance in radial direction, default 5e-8

% *************** Photosynthesis model parameters( GIVE PER 1-SIDES (HALF-TOTAL) LAI) ******

Photo.Vcmax25opti=38; % maximum carboxylation velocity at top of canopy, at 25degC ref. temperature(mumolm-2s-1)
Photo.Jmax25opti=2.1*Photo.Vcmax25opti; %Jmax25
Photo.Rd25opti=0.023*Photo.Vcmax25opti; %dark respiration at 25cegC, proportionality factor is 0.0229 for Pinus sylvestris, 0.0433 for Picea abies - Niinemets 2002: Tree Phys. 22, 515-535;
Photo.qeff=0.2; %parameter related to quantum efficiency; for conifers this needs to be smaller that needle-scale measurements give due within shoot shading?
Photo.Theta=0.7; %curvature of light response curve (co-limitation)
Photo.Kn=0.5; % leaf nitrogen extinction coefficient for Vcmax scaling: [0 = const. Vcmax, large values indicate rapid decrease with depth]

%Temperature -dependency
Photo.Vcmax_T=[69.83; 200; 0.672]; %Ha (kJmol-1) Hd (kJmol-1) dS(kJmol-1K-1)
Photo.Jmax_T=[61.74; 185.2; 0.624]; %Ha (kJmol-1) Hd (kJmol-1) dS(kJmol-1K-1)
Photo.Rd_T=33.87; % dark respiration temperature sensitivity parameter

%Leaf water potential -dependency of photosynthetic parameters (Kellomaki & Wang, xxxx)
Photo.Vcmax_PsiL=[-2.04 2.78]; %scots pine
Photo.Jmax_PsiL=[-1.56; 3.94];
Photo.Rd_PsiL=[]; %-2.53; 6.07

% ***************** Stomatal control parameters *****************

Stoma.StomaType =2; %1=stomata on one side, 2=stomata on both sides (does not affect yet anything)
Stoma.go=1e-3; % residual (cuticular) conductance (molm-2(leaf) s-1)

%----Medlyn et al. 2011 'unified stomatal model'
Stoma.Para={'Medlyn'; 2.2; 0.7}; %{'Medlyn'; g1_ww; sensit. to PsiL}

%NOTE: only parameters of selected 'Model' should be to be given!
%For other models give parameters as follows:

%Stoma.Para={'BWB'; 4; 0.7}; %{'BWB'; m_ww; sensit. to PsiL}
% Stoma.Para={'OptiL'; 18e-4; -0.9; 0.7}; %{'OptiL', La_ww(molCO2/molH2O);
% sensit. to PsiL; long-term CiCa}: Note Lambda increases with decreasing PsiL
% so sensitivity parameter <0
% Stoma.Para={'Leuning'; 3; 0.7; 1.5};  %{'Leuning', m_ww; sensit. to PsiL; scalingVPD(kPa)}

% *************** Respiration parameters **********************
Respi.Sapwood=[1.9; 0.3]; %sapwood respiration [Q10(-); R10(umolm-2(sapwood surface)s-1]; values for Scots pine, Zha et al. 2004
Respi.Root=[2.0; 1.0]; % root respiration[Q10(-); R10(umolm-2(ground)s-1]; not yet modeled separately

% *************** Phenology and LAI-dynamics **********************
Pheno.DegreeDayPara=[98; 1.5]; %degree-day model: [DDaccumulation_start(doy); T-threshold(degC)]
Pheno.PhenoPara={'Hari'; 0.1; 150; -4; 10}; % photosynthetic seasonal cycle: ['Model'; fmin; tau(days); T0(degC); Smax(degC)]
Pheno.LeafGrowthPara=[300; 750]; %[DD_sum(budbreak); DDsum(leaf maturation)]
Pheno.LeafSenescencePara=[270; 30]; % start DOY and duration of leaf senescence

% initialize DDsum and S

DDsum=0; 
S=0;

for n=1:length(Tdaily),
    DDsum=PlantType.DegreeDaySum(n,Tdaily(n),DDsum,Pheno.DegreeDayPara);
    S=S + (Tdaily(n) - S)/Pheno.PhenoPara{3}*24;
end

IniCond.Doy=Doy0;
IniCond.Tair=Tdaily(end);
IniCond.h_root=-0.1; %m, initial root pressure; default -0.1 m
IniCond.S=S;
%IniCond.S=[]; %Degree-Day model
IniCond.DDsum=DDsum;

PlantType_1=PlantType(Species,Switch_LAI, Switch_Pheno, Switch_Stoma_PsiL, z, zs, PT, Root, Photo, Stoma, Respi, Pheno, IniCond);  
            
clear Pheno 

%% ****** PlantType_2 ***************************

%give only values that have changed from previous PT
Species = 'Understory'; %species name
Switch_LAI='n';
Switch_Pheno='n';
Switch_Stoma_PsiL='y';

% physical attributes of Species cohort
PT.hmax =0.6; %canopy height (m)
PT.LAImax =0.5; %maximum annual 1-sided LAI (m2/m2)
PT.LAImin=0.6*PT.LAImax; %minimum annual 1-sided LAI (m2/m2)
PT.WAI =0.1*PT.LAImax; %woody area index (m2/m2):

%----- create leaf- and woody area densities (m2/m3) from Weibull-shape parameters (Teske & Thistle, 2004)
%NOTE: Add Tahvanainen & Forss - models for crown shape (pine,spruce,birch)

b=4;
c=1;

PT.lad=PlantType.generate_LAD_Weibul(z,1,PT.hmax,b,c); %leaf-area density shape: sum(lad*dz)=1, multiply by LAI to get real values

%create woody area profile, adding small number to b gives more weight to lower canopy
wad=PlantType.generate_LAD_Weibul(z,1,PT.hmax,b+0.05,c); clear b c
PT.wad=wad/sum(wad)/dz; %plant-aread density profile; sum(wad*dz)=1, multiply by WAI to get real values
clear wad b c

PT.lt=0.01; %characteristic leaf dimension (m)
PT.emi=0.98; %emissivity for thermal radiation
PT.PARalb=0.12; %leaf PAR albedo, adjusted for within-shoot scattering
PT.NIRalb=0.50; %leaf NIR albedo, adjusted for within-shoot scattering. value ~0.5 seems to give good stand albedo for Global radiation

PT.Wmaxrain=0.15; %(mm / unit of LAI), maximum interception capacity of liquid precipitation
PT.Wmaxsnow=0.3; %(mm / unit of LAI), maximum interception capacity of snowfall: does not impact anything yet!

%************** root zone properties **********************
Root.RootDepth=0.5; %rooting depth (m)
Root.RAI=2*PT.LAImax; %total fine root area index (m2/m2); this can be derived from typical species-dependent ratios. Does not currently affeat anything (?)
Root.beta=0.943; % shape parameter for root distribution model. Y=1-beta.^z_in_cm; Y=cumulative distribution (Gale & Grigal 1987)
Root.FineRootRadius=2e-3; %m, default 2e-3
Root.RadialConductivity= 5e-8; % s-1, maximum bulk root membrane conductance in radial direction, default 5e-8

% *************** Photosynthesis model parameters( GIVE PER 1-SIDES (HALF-TOTAL) LAI) ******

% Photo.PsiLSwitch=1; % 1= include biochemical limitations due low PsiLeaf, 0=neglect

Photo.Vcmax25opti=20; % maximum carboxylation velocity at top of canopy (mumolm-2s-1)
Photo.Jmax25opti=2.1*Photo.Vcmax25opti;
Photo.Rd25opti=0.023*Photo.Vcmax25opti; %dark respiration at 25cegC, proportionality factor is 0.0229 for Pinus sylvestris, 0.0433 for Picea abies - Niinemets 2002: Tree Phys. 22, 515-535;
Photo.qeff=0.2; %parameter related to quantum efficiency
Photo.Theta=0.7; %curvature of light response curve (co-limitation)
Photo.Kn=0; % leaf nitrogen extinction coefficient for Vcmax scaling: [0 = const. Vcmax, large values indicate rapid decrease with depth]

%Temperature -dependency
Photo.Vcmax_T=[69.83; 200; 0.672]; %Ha (kJmol-1) Hd (kJmol-1) dS(kJmol-1K-1)
Photo.Jmax_T=[61.74; 185.2; 0.624]; %Ha (kJmol-1) Hd (kJmol-1) dS(kJmol-1K-1)
Photo.Rd_T=33.87; % dark respiration temperature sensitivity parameter

%Leaf water potential -dependency (Kellomaki & Wang, xxxx)
Photo.Vcmax_PsiL=[-2.04 2.78]; %scots pine
Photo.Jmax_PsiL=[-1.56; 3.94];
Photo.Rd_PsiL=[]; %[2.53; 6.07];

% ***************** Stomatal control parameters *****************

Stoma.StomaType =2; %1=stomata on one side, 2=stomata on both sides (does not affect yet anything)
Stoma.go=5e-3; % residual (cuticular) conductance (molm-2(leaf) s-1)

%----Medlyn et al. 2011 'unified stomatal model'
Stoma.Para={'Medlyn'; 5.0; 0.7}; %{'Medlyn'; g1_ww; sensit. to PsiL}

%NOTE: only parameters of selected 'Model' should be to be given!
%For other models give parameters as follows:

% Stoma.Para={'BWB'; 8; 0.7}; %{'BWB'; m_ww; sensit. to PsiL}
% Stoma.Para={'OptiL'; 18e-4; -0.9; 0.7}; %{'OptiL', La_ww(molCO2/molH2O);
% sensit. to PsiL; long-term CiCa}: Note Lambda increases with decreasing PsiL
% so sensitivity parameter <0
% Stoma.Para={'Leuning'; 3; 0.7; 1.5};  %{'Leuning', m_ww; sensit. to PsiL; scalingVPD(kPa)}

% *************** Respiration parameters **********************
Respi.Sapwood=[1.9; 0.3]; %sapwood respiration [Q10(-); R10(umolm-2(sapwood surface)s-1]; values for Scots pine, Zha et al. 2004
Respi.Root=[2.0; 1.0]; % root respiration[Q10(-); R10(umolm-2(ground)s-1]; not yet modeled separately

% *************** Phenology and LAI-dynamics **********************
Pheno.DegreeDayPara=[98; 1.5]; %degree-day model: [DDaccumulation_start(doy); T-threshold(degC)]
Pheno.PhenoPara={'Hari'; 0.1; 150; -4; 10}; % photosynthetic seasonal cycle: ['Model'; fmin; tau(days); T0(degC); Smax(degC)]
Pheno.LeafGrowthPara=[200; 750]; %[DD_sum(budbreak); DDsum(leaf maturation)]
Pheno.LeafSenescencePara=[270; 30]; % start DOY and duration of leaf senescence

% initialize DDsum and S

DDsum=0; 
S=0;

for n=1:length(Tdaily),
    DDsum=PlantType.DegreeDaySum(n,Tdaily(n),DDsum,Pheno.DegreeDayPara);
    S=S + (Tdaily(n) - S)/Pheno.PhenoPara{3}*24;
end

IniCond.Doy=Doy0;
IniCond.Tair=Tdaily(end);
IniCond.h_root=-0.1; %m, initial root pressure; default -0.1 m
IniCond.S=S;
%IniCond.S=[]; %Degree-Day model
IniCond.DDsum=DDsum;

PlantType_2=PlantType(Species,Switch_LAI, Switch_Pheno, Switch_Stoma_PsiL, z, zs, PT, Root, Photo, Stoma, Respi, Pheno, IniCond);  
            
clear Species Switch_LAI Switch_Pheno Switch_Stoma_PsiL PT Root Photo Stoma Respi Pheno IniCond Tdaily Doy0 DDsum S n 


%% create PlantType array

PTypes=[PlantType_1 PlantType_2 ];
clear PlantType_1 PlantType_2 %PlantType_3

%% **************************** ----- Moss_1 characteristics ---- *************************************
clear IniCond

SpecName='Feather moss';
BT.f_cover=1; % moss cover, fraction of soil surface (0..1)
BT.height=0.03; % height of moss layer (m);
BT.lt=0.01;% m, characteristic roughness length scale of moss, order of few mm - 1 cm

BT.SLA=180; % specific leaf area (cm2/g), average of P.shreberi and Hylocomium splendens (Bond-Lamberty & Gower, Oecologia 2007
BT.Mdry=0.060; % dry mass (kg/m2)
BT.BulkDensity=50; % bulk density kg/m3
BT.LAI=1e3*BT.Mdry*BT.SLA/1e4; % bryophyte LAI m2/m2

BT.Wmax=10; %(kg/kg) maximum fresh weight is 10 times dry mass
BT.Wmin=1.5; %(kg/kg), minimum fresh weight is ~1.5 times dry mass

%----hydraulic properties
%[ThetaS(m3/m3) ThetaR(m3/m3) alfa(-) n(-) compressibility(1/m) Kzsat(m/s) poreconnectivity]
%pF=[0.97 0.02 0.51 1.88 1e-5 1e-6 0.5]; %pFcurve parameters: Lauren 1999 CT 32 o2
BT.pF=[0.97 0.015 1.72 1.25 1e-5 1.0e-6 0.5]; %pFcurve parameters: Lauren 1999 CT 32 o2[0.92 0.015 1.72 1.25 1e-5 4e-6 0.5]

BT.PhotoPara=[1.8; 0.018]; % [Amax(umolm-2s-1); qeff(mol/mol) on incident light basis] (Kolari et al. 2006, Kulmala, 2011, Williams & Flanagan, 1998)
BT.R10=0.02; % base respiration rate (mumolm-2s-1); Williams & Flanagan, 1998 give 0.3-0.6 for Pleurozium at T=25degC so this is reasonable at 10degC
BT.Q10=2; % temperature sensitivity (-); calculated from Williams & Flanagan, 1998 eq. 10

%----- optical properties
BT.PARalb=0.05; % albedo (-) %Arkimaa et al. & Van Gaalen et al. 2007 Oecologia
BT.NIRalb=0.45; % albedo (-)
BT.emi=0.98; % emissivity (-)

%--Initial conditions -----------------------------

IniCond.W=10; %fresh weight
IniCond.T=3; % temperature

Moss_1=BryoType(SpecName, BT, IniCond);
clear IniCond SpecName BT

%[Hint! One can define more moss types as above and assing them then into
%MTypes -array. Make sure that Moss_1.f_cover + Moss_2.f_cover 

%% MTypes -array
BryoTypes=[Moss_1];
clear Moss_1

%% ************ ------ Initialize Stand -object ---- ******************************************
%Gen. is struct for Stand-object initialization

SiteName='VT pine';
Gen.LAT=61.51; % latitude deg.
Gen.LON=24; % longitude deg.
Gen.ELEV=181; % elevation a.s.l. (m)
Gen.Tave=4.5; %annual average temperature (degC)
Gen.dPdx=0.0; %0.01; % horizontal pressure gradient
Gen.Slope=0.04; % site slope

%NumberOfPlantTypes=3; % Set here the number of PlantType-objects used
NrBryoTypes=length(BryoTypes);

Gen.hc=PTypes(1).hmax; %canopy height (m)
Gen.d=0.67; % displacement height / canopy height
Gen.SN_CO2=2; %ratio of eddy diffusivities; Ks/Km, turbulent Schmidt number
Gen.SN_H2O=3; %ratio of eddy diffusivities; Ks/Km, turbulent Schmidt number
Gen.SN_heat=4; %ratio of eddy diffusivities; Ks/Km, turbulent Schmidt number

%Schmidt numbers are tuned so that reasonable vertical profiles are
%produced for Hyyti�l� when ecosystem and sub-canopy EC-fluxes are matched.
%Some theoretical grounds to SN_H2O & SN_heat > SN_CO2; see LES-study of
%Albertson, Katul et al. 

Gen.Cd=0.15; % drag coefficient (-)

Gen.ClumpingFactor=0.7; % leaf + shoot + trunk clumping factor (-)
Gen.CanopyClosure=1; % canopy closure fraction (-)
Gen.LeafAngleDistribution=1; % parameter describing leaf angle distribution (1 = spherical, 0 = vertical, -->inf = horizontal)

Gen.emi_leaf=0.98;
Gen.emi_soil=0.98;
Gen.surfPARalb=0.05;
Gen.surfNIRalb=0.45;

f_bryophytes=1; %make sure here that this is <=1  and equals to sum of f_cover of all BryoTypes
f_litter=0; %not in use currently

%-------- Initial conditions of Stand -state variables (Nx1 -vectors)
IniCond.W=0;  % canopy water storage per layer (mm), give here as (mm) per UNIT PAI
IniCond.S=0; % canopy snow storage per layer (mm)

IniCond.Tair=10;  % canopy temperature (degC)

Stand_1=Stand(SiteName,z,Gen,PTypes,NrBryoTypes,f_bryophytes,f_litter,IniCond);

clear SiteName NrBryoTypes z Gen f_bryophytes f_litter IniCond N z zs dz
%% --------- Call main program --------

APES_main_vJan16(MAIN, Stand_1,PTypes,BryoTypes, Soil_1, Bedrock_1, FORCING);


%% ---- plot some graphs ----

disp('************* Done ! **************')
disp('To plot some example graphs, run Main\PlotSomeResults.m.')
disp('And see @APES_IO for output structures')
    

