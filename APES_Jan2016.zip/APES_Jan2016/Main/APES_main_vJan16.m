
function APES_main_vJan16(MAIN, Stand_1,PTypes,BryoTypes, Soil_1, Bedrock_1, FORCING)
%------------------------------------------------------------------------------------------------------
%  APES - Atmosphere-PlantEcosystem Simulator v. Jan 2016 Solves energy and mass (CO2,
%  H2O) exchange in 1D-vertically resolved canopy-soil -system
%
% Samuli Launiainen, Gaby Katul 2009-
%
%

% NOTES ON CODE:

% n - running index of FORCING
% MAIN.Runs - number of dt in FORCING
% MAIN.dt - forcing timestep (s)
% N - number of above-ground gridpoints: z(1) = ground, z(N)=upper boundary
% K - number of soil gridpoints: zs(1)=1st layer, zs(K)=lowest layer

%% constants
%parcf=4.56; % conversion of PAR from Wm-2 to umol m-2 s-1
L_molar=44100; %J/mol latent heat of vaporization at 20 deg C
Mwater=18.0153e-3; % Molecular weight of water kg/mol
GasConst=8.314; % universal gas constant, Jmol-1
StefBolz=5.6697e-8; %Stefan-Boltzman constant W m-2 K-4

z=Stand_1.z; % height vector (m)
dz=z(2)-z(1);
N=length(z); % number of gridpoints above ground
K=length(Soil_1.zs); %number of gridpoints in soil
M=length(FORCING.Ta); %number of runs

%import packages & IO object
import Radiation.* %radiation package
import MicroMet.* %micromet package

IO=APES_IO(); %create IO -object

%% ------------ initialize output structures ----------------------
%model outputs will be saved here!
global oStand oPlant oFloor oBryo oFlux oMeteo oRadi oSoil oDLF oWLF

[oStand,oPlant,oDLF,oWLF,oFloor,oBryo,oFlux,oMeteo,oRadi,oSoil] = IO.Initialize_Outputs(Stand_1.NrPlantTypes,Stand_1.NrBryoTypes,...
                                                                  M,N,K,MAIN.Save_LeafFluxes);
                                              
%% ---------------------------Proceed to Model computations ------------------------------
Time_per_run=zeros(M,1)+NaN; %bookkeeping time consumption

savetime=0; % time when outputs are saved to "MAT"
dayindex=1; % running index for initiation of daily updated phenology etc.

d_out=1; %index for daily outputs

dummy0=tic;

%MaxIterNo=0;
Tdaily=0;
CumInfiltr=0;
CumEvap=0;
CumDrain=0;
CumRoff=0;
CumEb=0;

for n=1:M %% loop through forcing timesteps
    
    dummy1=tic;
    
    savetime=savetime + MAIN.dt;
    
    dayindex=dayindex+MAIN.dt/86400; %varies between [0;1] - when 1 at midnight, physiology and phenology are updated
        
    %---- forcings at uppermost gridpoint
    time= FORCING.time(n,:); %YYYY MM DD hh mm
    Uref= FORCING.U(n); %measured velocity above canopy
    ustar=FORCING.Ustar(n); %friction velocity (m/s). Has to be >0.02 m/s for numerical stability
    Utop_Ensemble=FORCING.Utop_Ensemble; % ensemble-averaged U/Ustar at reference height
    T_ref=FORCING.Ta(n); %air temperature degC
    CO2_ref=FORCING.CO2(n); %CO2 mixing ratio (mol/mol)
    H2O_ref=FORCING.H2O(n); %H2O mixing ratio (mol/mol)
    P=FORCING.Pamb(n); % Pressure (Pa)
    
    Ib1=FORCING.PARdir(n); %direct PAR in Wm-2
    Id1=FORCING.PARdif(n); %diffuse PAR in Wm-2
    Ib2=FORCING.NIRdir(n); % direct NIR radiation Wm-2
    Id2=FORCING.NIRdif(n); % diffuse NIR radiation Wm-2  
    ea=FORCING.emi_atm(n); % atmospheric emissivity
    LWdn0=ea*StefBolz*(T_ref+273.15).^4; % downwelling LW (Wm-2)
    
    %precipitation & partitioning to liquid and snow
    PrecW=FORCING.Prec(n); % Precipitation rate (mm/s = kg /m2 /s)
    
    %assumes that above 1degC all is rain, below 0degC all is snow and otherwise linear relation to T_ref
    %if T_ref>1, PrecW=Prec; PrecS=0; elseif T_ref<0, PrecW=0; PrecS=Prec; else PrecW=Prec*(T_ref-1); PrecS=Prec-PrecW; end
    % temperature of precipitating water
    Tprec=T_ref;
        
    %compute daily mean temperature for temperature sum and S
    Tdaily=Tdaily + T_ref*MAIN.dt/(3600*24);
    
    DOY=datenum(time(1), time(2), time(3)) - datenum(time(1),1,0); 
    tm=time(4)+time(5)./60; % decimal hour
        
    disp(['Processing day: ' num2str(DOY) ' Run: ' num2str(n)])  

    %% ---------- At begining of each day check phenology status, update LAI, photoparameters and update root pressure
    if dayindex>=1,
        disp('Midnight:Updating plant physiology and phenology')
        %update stand structure
        LAI_stand=0;
        PAI_stand=0;
        lad_stand=zeros(N,1);
        pad_stand=zeros(N,1);
        
        for PlantNr=1:Stand_1.NrPlantTypes, %loop through PlantType-objects and update their characteristics

            if strcmpi(PTypes(PlantNr).Switch_Pheno,'y'), %calculate phenology
                [PTypes(PlantNr).PhenoState, PTypes(PlantNr).RelPhoto_Seasonal] = PTypes(PlantNr).PhotoCapa_SeasonalAcclimation(Tdaily);
            end
            
            if strcmpi(PTypes(PlantNr).Switch_LAI,'y'), %calculate LAI dynamics
                [PTypes(PlantNr).LAI, PTypes(PlantNr).PAI, PTypes(PlantNr).lad, PTypes(PlantNr).pad, PTypes(PlantNr).DDsum] = PTypes(PlantNr).LeafAreaDynamics(DOY,Tdaily);
            end
            
            % -----------
            %SL 12.1.2016: Fotosynteesi- ja ilmarakoparametreja ohjataan lehden vesipotentiaalin avulla. T�ll� hetkell� on oletettu ett� lehden vesipotentiaali (h_leaf) kussakin latvuskerroksessa on yksinkertaisesti:
            % Juurten vesipotentiaali (h_root)- korkeus maanpinnasta (z) (m).
            % Juurten vesipotentiaali on edellisen p�iv�n ja t�m�n hetken keskiarvo (MAIN.tau_m = 0.5). h_root, h_leaf p�ivitetty aina  keskiy�ll� ja oletettu vakioksi seuraavan p�iv�n aikana.
            %-----------
            
            % update root and leaf pressures assuming Tr. rate is zero at midnight
            [~,h_root,~]=PTypes(PlantNr).RootUptake(0,Soil_1.zs,Soil_1.h,Soil_1.Wliq,Soil_1.KLh);
            PTypes(PlantNr).h_root=PTypes(PlantNr).h_root* (1-MAIN.tau_m) + h_root*MAIN.tau_m; %smoothed average
            
            PTypes(PlantNr).h_leaf=PTypes(PlantNr).h_root - z; %leaf pressure
            
            %update stand vegetation
            LAI_stand=LAI_stand + PTypes(PlantNr).LAI;
            PAI_stand=PAI_stand + PTypes(PlantNr).PAI;
            lad_stand=lad_stand + PTypes(PlantNr).lad;
            pad_stand=pad_stand + PTypes(PlantNr).pad;
        end
        
        %update Stand_1 properties (used for computing radiative transport
        %and flow statistics
        Stand_1.LAI=LAI_stand;
        Stand_1.lad=lad_stand;
        Stand_1.PAI=PAI_stand;
        Stand_1.pad=pad_stand;

        clear LAI_stand lad_stand PAI_stand pad_stand
        
        dayindex=0; % reset dayindex
        d_out=d_out+1; % daily output index
        Tdaily=0; %reset daily temperature
        
        if strcmpi(MAIN.Switch_EnsembleFlow,'y'),
            % estimates normalized velocity statistics once per day to account for LAI-impacts. This assumes that upper BC for momentum balance i.e. Utop/ustar = constant (given by user as ensemble average in
            % typical conditions). These are then scaled by measured U or ustar at each run. Speeds up computations; also U/ustar can become very low in convective conditions and thus Kmn be
            % anomalously small   
            %SL 12.1.2016: if LAI-dynamics are not included, calculation of normalized flow velocity can be done only once.
            
            % Utop is U/ustar normalized mean wind speed and Kmn eddy
            % diffusivity for momentum. NOTE: including dPdx >0 in dense canopied stands (high LAI) may lead to crash of numerics
            [Un,Kmn] = generate_flow(z,Stand_1.pad,Stand_1.hc,Stand_1.Cd, Utop_Ensemble,0.02*Utop_Ensemble,Stand_1.dPdx);
        end
    end
    

    %% ---------- Microclimate: Radiation and flow field, eddy diffusivity ----------------
    
    [ZEN,~,~]=solar_dec_azimuth(DOY, Stand_1.LAT,Stand_1.LON, tm);    %solar angles

    %--------- Calculate SW radiation attenuation in canopy
    
    [PAR_sl,PAR_sh,q_sl1, q_sh1, q_soil1, f_sl, SWb1, SWd1, SWu1, alb1] = CanopySWRad_ZhaoQualls(Stand_1.lad*dz,Stand_1.ClumpingFactor,Stand_1.LeafAngleDistribution,ZEN,Ib1,Id1,Stand_1.PARalb,Stand_1.surfPARalb);
    [~,~,q_sl2, q_sh2, q_soil2, ~, SWb2, SWd2, SWu2, alb2] = CanopySWRad_ZhaoQualls(Stand_1.lad*dz,Stand_1.ClumpingFactor,Stand_1.LeafAngleDistribution,ZEN,Ib2,Id2,Stand_1.NIRalb,Stand_1.surfNIRalb);

%     figure(333)
%     Rab1=sum((f_sl.*q_sl1 + (1-f_sl).*q_sh1).*Stand_1.lad.*dz) + q_soil1;
%     Rab2=sum((f_sl.*q_sl2 + (1-f_sl).*q_sh2).*Stand_1.lad.*dz)+q_soil2; %(1-Stand_1.surfNIRalb)*(SWb2(1)+SWd2(1));
%   
%     subplot(411); plot(n,Rab1./((1-alb1)*(Ib1+Id1)+eps),'ro'); title('-'); hold on
%     subplot(412); plot(n,Rab1,'go', n,(1-alb1)*(Ib1+Id1),'ks'); title('Par'); hold on
%     subplot(413); plot(n,Rab2,'ro', n,(1-alb2)*(Ib2+Id2),'ks'); title('Nir'); hold on

    %---------- FLOW STATISTICS AND EDDY DIFFUSIVITIES ------------

    if strcmpi(MAIN.Switch_EnsembleFlow,'n'), %compute flow field at each dt; note that this may crash if Stand_1.dPdx is >0 and ustar low
        Utop=Uref/(ustar+eps);
        [Un,Kmn] = generate_flow(z,Stand_1.pad,Stand_1.hc,Stand_1.Cd, Utop,0.01*Utop,Stand_1.dPdx);    % Un is normalized mean wind speed and Kmn eddy diffusivity for momentum
    end
    
    U=Un.*ustar;
    U(1)=U(2);
    Km=Kmn.*ustar;
    Km(1)=Km(2);
    
    %Scalar eddy diffusivities
    Kc=Stand_1.SN_CO2.*Km;
    Kt=Stand_1.SN_heat.*Km;
    Kq=Stand_1.SN_H2O.*Km;

%     figure(3);
%     subplot(121);plot(U,z,'b-');
%     subplot(122);plot(Km,z,'r-');
%     pause

    %% *************** Turbulence closure loop starts here; iterates until T, CO2 and H2O converge  or IterNo>=20 (very rare cases) *************
    
    %initial conditions
    CO2=CO2_ref.*ones(N,1); % CO2 concentration profile (mol/mol)
    H2O=H2O_ref.*ones(N,1); % H2O concentration profile (mol/mol)
    T=T_ref*ones(N,1); % air temperature profile (degC)
    Tf=Stand_1.Tfloor; %forest floor temperature
        
    IterNo=0;
    err_T=9999;
    err_H2O=9999;
    err_CO2=9999;  
    % W, df and T, H2O and CO2 change between iterations 
    
   while (err_T >0.01 || err_H2O>0.01 || err_CO2>0.01) && IterNo<50
       
        IterNo=IterNo+1;

        %source/sink profiles
        Csource=zeros(N,1);
        Esource=zeros(N,1);
        Hsource=zeros(N,1);
        Rsource=zeros(N,1); %non-isothermal component of radiation balance
        Rootsink=zeros(size(Soil_1.zs)); %s-1
        
        %Transpi=zeros(Stand_1.NrPlantTypes,1); 
        %GPP=zeros(Stand_1.NrPlantTypes,1); 
        %Rplant=zeros(Stand_1.NrPlantTypes,1); 
        %RootsinkTotal = 0;
        
        %% ------- Calculate isothermal LW radiation balance ------------------------------------------
        
        LWups=Stand_1.soilemi*StefBolz*(Tf+273.15).^4; %LW emissions from forest floor
        %[LW,LWleaf,LWup,LWdn] = CanopyLWRad(Stand_1.lad*dz,Stand_1.ClumpingFactor,T,LWdn0,LWups);
        [LW,LWdn,LWup,LWleaf] = CanopyLWRad_ZhaoQualls(Stand_1.lad*dz,Stand_1.ClumpingFactor,Stand_1.LeafAngleDistribution,T,LWdn0,LWups,0.98, 0.98);

        clear LAIZ CLUMP LWups
        
%         figure(1)
%         subplot(221);plot(LW,z,'r-', LW2,z,'g-');
%         subplot(222);plot(LWup,z,'g-', LWup2,z,'g--',LWdn,z,'r-', LWdn2,z,'r--');
%         subplot(223);plot(LWleaf2,z,'r-'); 
%         subplot(224);plot(LWleaf,z,'g-'); ylabel('leaf'), pause

        %% ------- Calculate interception, throughfall, wet-canopy fluxes and update Stand_1.W and Stand_1.df

        % Wm-2 isothermal radiation balance at each layer, sunlit and shaded leaves together
        Rabs=(q_sl1 + q_sl2).*f_sl + (q_sh1 + q_sh2).*(1-f_sl) + LWleaf; 
        
        %interception, evaporation and wet canopy energy budget
        [flx_w,LEw,Hw,Tleaf_w,W,df,Trfall,cum_w]=Stand_1.WetLeaf_Module2(H2O,T,P,Rabs,U,PrecW,MAIN.dt);
        % flx_w -struct gives fluxes per unit wet leaf area (Wm-2(leaf));
        % cum_w cumulative interception and Evap / condensation (mm) per layer
        % LEw, Hw latent & sensible heat flux from wet fraction of foliage (Wm-2(ground)) at each layer, Tleaf_w - leaf temperature
        % W moisture storage (kg) and df dry fraction at each layer (-), 
        
        Trfall_f=Trfall(1); % throughfall rate to forest floor (mm/s)
        
        Esource=Esource + LEw/L_molar/dz; %H2O source profile (mol m-3 s-1)
        Hsource=Hsource + Hw/dz; % Heat source profile W/m3
        Rsource=Rsource + (1-df).*flx_w.Fr.*Stand_1.lad; %W m-3 s-1
        
        %% ------ Compute leaf scale assimilation, dark respiration, transpiration, sensible heat flux and root water uptake of PlantTypes ---------
        % goes through PlantType objects in [PTypes]; accumulates each PlantType contribution to source profiles and saves leaf-level fluxes to outputs at desired times
        
        %temporary storage struct for PlantType outputs; global to APES_write_oPlant
        clear PFlx
        PFlx(1:length(PTypes))=struct('GPP',[],'Respi',[],'Transpi',[],'sl',[],'sh',[],'RootSink',[]);
        
        for PlantNr=1:Stand_1.NrPlantTypes,
            %disp('PlantType loop')
            
            [sl, sh]=PTypes(PlantNr).Leaf_Module(H2O,CO2,T,P,PAR_sl,PAR_sh,q_sl1,q_sh1,q_sl2,q_sh2,LWleaf,U); %do leaf-scale computations by PlantType.LeafModule
            %sl is structure for sunlit leaves, sh for shaded leaves
            
            [Rwoody]=PTypes(PlantNr).WoodyRespiration(T); % umol m-3 s-1, woody biomass growth and maintenance respiration, assume air T
            Rd_wet=PTypes(PlantNr).LeafDarkRespiration(Tleaf_w,SWb1+SWd1).*(1-df).*PTypes(PlantNr).lad; % umol m-3 s-1, due wet leaf respiration rates
            
            %vertical source profiles            
            %allow here no CO2 exchange from wet leaves
            Csource=Csource + df.*(f_sl.*(sl.Rd - sl.An) + (1-f_sl).*(sh.Rd - sh.An)).*PTypes(PlantNr).lad + Rwoody + Rd_wet; %umol m-3 s-1
            Hsource=Hsource + df.*(f_sl.*sl.H + (1-f_sl).*sh.H).*PTypes(PlantNr).lad; %W m-3 s-1
            
            Rsource=Rsource + df.*(f_sl.*sl.Fr + (1-f_sl).*sh.Fr).*PTypes(PlantNr).lad; %W m-3 s-1
            
            %
            PFlx(PlantNr).GPP=sum(df.*(f_sl.*sl.An + (1-f_sl).*sh.An).*PTypes(PlantNr).lad)*dz; % GPP umolm-2s-1
            PFlx(PlantNr).Respi=sum(Rd_wet + Rwoody + df.*(f_sl.*sl.Rd + (1-f_sl).*sh.Rd).*PTypes(PlantNr).lad)*dz; % respiration rate %mol m-3 s-1
            
            Tr=df.*(f_sl.*sl.E + (1-f_sl).*sh.E).*PTypes(PlantNr).lad; % H2O source density %mol m-3 s-1
            Esource=Esource + Tr; %mol m-3 s-1
            
            % transpiration rate is sum of layers where Tr>0
            PFlx(PlantNr).Transpi=1e-3*sum(Tr(Tr>0)*Mwater*dz); %m/s
            
            
            if PFlx(PlantNr).Transpi>0,
                [S,~, Stotal]=PTypes(PlantNr).RootUptake(PFlx(PlantNr).Transpi,Soil_1.zs,Soil_1.h,Soil_1.Wliq,Soil_1.KLh);
                Rootsink=Rootsink + S; % s-1
                %RootsinkTotal=RootsinkTotal + Stotal; %this is to check sum(Transpi)==Rootsink
            end
           
            if strcmpi(MAIN.Save_LeafFluxes,'y'), %keep leaf-level fluxes
                PFlx(PlantNr).sl=sl;
                PFlx(PlantNr).sh=sh;
                if PFlx(PlantNr).Transpi>0,PFlx(PlantNr).RootSink=S; end
            end
            clear sl sh S Stotal
            
        end %end of PlantType-loop
        clear PlantNr kk S Stotal
        
        %% ------------ ForestFloor processes: Bryophyte interception, evaporation, CO2 and heat exchange -------
        %
        % 1) assumes that ground is either covered by Bryophytes (moss species), litter layer (NOT YET) or bare soil is exposed 
        % 2) Simple weighting scheme based on fractional cover of each type is used to compute mean exhange rates and forest floor temperature
        % 3) Takes soil state from previous dt, uses ambient U, H2O, CO2, and T from 1st node above the surface from the current iteration step 

        %---- total effective fluxes at forest floor; tiling scheme used to compute        
        Ef=0; %forest floor evaporation (mosses + litter) (molm-2(ground)s-1) 
        Esoil=0; %soil evaporation (molm-2(ground)s-1)
        Hf=0; %forest floor sensible heat flux (Wm-2)
        Gsoil=0; %ground heat fluxes (Wm-2) 
        LWf=0; %emitted LW (Wm-2)
        Fcf=0; %net forest floor CO2-flux (umolm-2(ground)s-1)
        Trfall_s=Trfall_f*Stand_1.f_baresoil; %Throughfall rate (kgm-2s-1) to soil
        Tf=0; %forest floor temperature (degC)
        Tbryo=0;

        % --- Litter/mulch  layer interception, evaporation and heat balance --------------------
        % TO BE ADDED IN FUTURE


        % ------------ Bryophyte layer -----------------------------
        if Stand_1.f_bryophytes>0,
            
            
            %temporary storages for outputs
            clear Flx_b State_b
            Flx_b=cell(length(BryoTypes),1); %fluxes
            State_b=Flx_b; %statevariables
            
            %loop through all BryophyteTypes in [BryoTypes]
            for BNr=1:Stand_1.NrBryoTypes,
                
                % calc. moss-soil thermal conductance
                km=BryoTypes(BNr).OrganicMatterHeatConductivity(BryoTypes(BNr).Theta,3); %W m-1 K-1
                ks=Soil_1.Ktherm(1); %W m-1 K-1

                kms=(ks*km)^0.5/(abs(Soil_1.zs(1))+ BryoTypes(BNr).height); %geometric average, (Wm-2K-1)
                clear ks km
                
                % compute liquid water flux (mm/s) due capillary rise, only rise is allowed: q=-k(dh/dz +1)
                if strcmpi(BryoTypes(BNr).Switch_CapillaryRise,'y') && BryoTypes(BNr).W<=BryoTypes(BNr).Wmax,
                    
                    %compute capillary rise from soil
                    FL_bryo=BryoTypes(BNr).CapillaryRise(MAIN.dt,Soil_1.KLh(1),Soil_1.h(1),Soil_1.zs(1)); %mm/s
                    
                    % add capillary rise to root sink term at 1st soil layer (for soil water model)
                    Rootsink(1)=Rootsink(1) - 1e-3*BryoTypes(BNr).f_cover*FL_bryo/(2*Soil_1.zs(1)); %s-1
                else
                    FL_bryo=0;
                end
                
                %water and energy balance
                [Flx_b{BNr}, Prec_b,State_b{BNr}]=BryoTypes(BNr).BryoEnergyH2OBalance(MAIN.dt,Trfall_f,FL_bryo,T(2),Tprec,Soil_1.T(1),kms,SWb1(1),SWd1(1),SWb2(1),SWd2(1),LWdn(1),U(2),H2O(2),P);
                %take U from node 2 since that is ~height of Rice's wind-tunnel measurement (ca. 30cm)
                Flx_b{BNr}.FL_bryo=FL_bryo;
                clear kms FL_bryo
                
                %photosynthesis, respiration
                [Flx_b{BNr}.Anb,Flx_b{BNr}.Rb]=BryoTypes(BNr).BryoCO2exchange(SWb1(1)+SWd1(1)); %photosynthesis, respiration rate (micromol m-2(ground) s-1)
                
                % ------ Compute soil evaporation through bryophytes; limited either by atm. demand & transport or soil supply.
                % Vapor flow from soil to air must overcome two resistances in series:
                %1st molec. diffusion through porous living moss and then 2nd from moss canopy to 1st calc. node in the atm; assumed equal to conductance from wet moss canopy
                
                Esoil_b = BryoTypes(BNr).SoilEvaporation_through_Moss(State_b{BNr}.Theta_b,T(2),H2O(2),U(2),P,Soil_1.T(1),Soil_1.h(1),Soil_1.KLh(1),Soil_1.zs(1));
                
                %---compute effective forest floor fluxes & surface T for microclimate & soil models by weighting with relative covers
                Ef=Ef + BryoTypes(BNr).f_cover*Flx_b{BNr}.LE/L_molar; %molm-2s-1
                Esoil=Esoil + BryoTypes(BNr).f_cover*Esoil_b; %molm-2s-1
                
                Hf=Hf + BryoTypes(BNr).f_cover*Flx_b{BNr}.H; %Wm-2
                Gsoil=Gsoil + BryoTypes(BNr).f_cover*Flx_b{BNr}.G; %Wm-2
                LWf=LWf + BryoTypes(BNr).f_cover*Flx_b{BNr}.LWout; %Wm-2
                
                Fcf=Fcf + (Flx_b{BNr}.Anb + Flx_b{BNr}.Rb); %umolm-2s-1 (scaling for .f_cover done in function)
                Trfall_s=Trfall_s + BryoTypes(BNr).f_cover*Prec_b; %kg/m2 = mm/s
                Tbryo=Tbryo + BryoTypes(BNr).f_cover*State_b{BNr}.Tb;
                
            end
            clear BNr
            Tf=Tf + Tbryo*Stand_1.f_bryophytes;
            
        end %if Stand_1.f_bryophytes>0
        
        
        %-------- Bare soil energy balance; if part of soil is exposed to atm.
        
        if Stand_1.f_baresoil >0,
            
            [Hs,LEs,Gs,LWups,Tsoil0]=Soil_1.SurfaceEnergyBalance(SWb1(1)+SWd1(1),SWb2(1)+SWd2(1),LWdn(1),T(2),U(2),H2O(2),P,z(2));
            %Soil_1.SurfaceEnergyBalance(totPar,totNir,LWdn,Tair,U,H2Oair,Pamb,z_1stnode)
            Hf = Hf + Hs*Stand_1.f_baresoil;
            Esoil = Esoil + LEs/L_molar*Stand_1.f_baresoil;
            Gsoil = Gsoil + Gs*Stand_1.f_baresoil;
            LWf=LWf + LWups*Stand_1.f_baresoil;
            Tf=Tf + Tsoil0*Stand_1.f_baresoil;
        else
            Tsoil0=NaN; %needed for output
        end
        
        %----- Soil respiration rate
        Rsoil=Soil_1.SoilRespiration(); %umol m-2 (ground) s-1; uses state variables from Soil_1
        Fcf=Fcf + Rsoil; %CO2 efflux at forest floor (umolm-2(ground)s-1)
        
        
        %% ----------- Calculate scalar profiles in canopy air space from source distributions ---------
        
        Tprev=T;
        T=closure_1_model_T(z,Kt,T_ref,P,Hsource,Hf);
        
        CO2prev=CO2;
        CO2=closure_1_model_CO2(z,Kc,CO2_ref,T_ref,P,Csource,Fcf);
        
        H2Oprev=H2O;
        H2O=closure_1_model_H2O(z,Kq,H2O_ref,T_ref,P,Esource,Ef+Esoil);
        
        % check that H2O profiles stays in realistic range: allow no supersaturation
        esa=PlantType.e_sat(T)/P; %saturation vapor pressure
        H2O(H2O>esa)=esa(H2O>esa); clear esa
        
        if any(H2O<0)
            disp('closure model H2O returns H2O<0, Well-mixed profiles used')
            H2O(:)=H2O_ref;
            % T(:)=T_ref;
        end
        
        % figure(100);
        % subplot(231); plot(T,Stand_1.z,'r-',Tprev,Stand_1.z,'b-'); title('T')
        % subplot(232); plot(Hsource,Stand_1.z,'r-'); title('T source')
        % subplot(231); plot(H2O,Stand_1.z,'r-',H2Oprev,Stand_1.z,'b-'); title('H2O')
        % subplot(232); plot(Esource,Stand_1.z,'r-'); title('H2O source')
        % subplot(235); plot(CO2,Stand_1.z,'g-',CO2prev,Stand_1.z,'b-'); title('CO2')
        % subplot(236); plot(Csource,Stand_1.z,'g-'); title('CO2 source')
        
        if any(isnan(T)==1 | isnan(H2O)==1) || any(isreal(T)==0 | isreal(H2O)==0),
            disp('TurbClosure returns "NaN" - Well-mixed profiles used')
            H2O(:)=H2O_ref;
            T(:)=T_ref;
        end
        
        %check for well-mixed assumption and end while-loop; i.e. no
        %iteration to account for interaction between sinks/sources and vertical profiles in canopy air-space
        if strcmpi(MAIN.Switch_WMA,'y'), break; end
        
        %absolute errors and new initial values
        err_T=max(abs(T - Tprev));
        err_CO2=max(abs((CO2 - CO2prev)./CO2prev));
        err_H2O=max(abs((H2O - H2Oprev)./H2Oprev));
        
        % use average as next guess
        H2O=0.5*(H2O + H2Oprev);
        T=0.5*(T + Tprev);
        CO2=0.5*(CO2 + CO2prev);
        clear Tprev H2Oprev CO2prev
        
        % if no convergence within 20 iterations, compute next WMA-sources and break
        if IterNo>=20
            disp('TurbClosure did not converge - Well-mixed profiles used')
            T(:)=T_ref;
            H2O(:)=H2O_ref;
            CO2(:)=CO2_ref;
            
            if IterNo==21, break; end
        end
        
   end % of Turbulence closure loop
   clear err_T err_H2O err_CO2 %IterNo
   
   % **************  Update above-ground state variables *******************************************
   
   Stand_1.df(Stand_1.pad>0)=df(Stand_1.pad>0); %dry fraction of canopy layers
   Stand_1.W=W; %canopy layers water storage (kg)
   Stand_1.Tfloor=Tf; %forest floor temperature
   Soil_1.Tsurf=Tsoil0; %bare-soil temperature
   
   clear Tsoil0
   %now update state variables of BryoTypes
   for BNr=1:length(BryoTypes)
       BryoTypes(BNr).T=State_b{BNr}.Tb;
       BryoTypes(BNr).W=State_b{BNr}.Wb;
       BryoTypes(BNr).Theta=State_b{BNr}.Theta_b;
       BryoTypes(BNr).h=State_b{BNr}.psi_b;
   end
   clear State_b
   
   %% ************************** Solve soil water and heat flow and update SoilProfile -state ***************************************
   
   qtop = 1e-3*(Esoil*Mwater - Trfall_s); % m/s, <0 downwards. Upper boundary flux is the balance between soil evaporation and infiltration. 
                                          %Note that capillary rise to living mosses is included in Rootsink -term
   
   RH=H2O(2)*P/PlantType.e_sat(T(2)); % air relative humidity (-) at 1st calc. node above ground
   h_atm=GasConst*(273.15+T(2)).*log(RH)/(Mwater*9.81); % m, atm. pressure head in equilibrium with atm. relative humidity
   clear RH
   
   %-----Water flow lower BC
   lBCtype=MAIN.Soil_WaterFlow_LBC(1); % type of lower boundary condition: -1 = impermeable soil, %0=presc. head (m), 1=free drainage
   if lBCtype==0,
       lBCh=MAIN.Soil_Watflow_LBC(2);  %get value of lower BC
   else
       lBCh=0;
   end
   
   %lateral water flux is taken only from saturated layers.
   HorizFlux=zeros(Soil_1.NrOfLayers,1); %horizontal sink term (m3/m3/s) e.g. drainage to ditches.
   %satlayers=find(Soil_1.GWL>=Soil_1.zs);
   satlayers=find(Soil_1.h>-0.1); %Soil_1.h>-1
   
   if isempty(satlayers)~=1, %assume horizontal conductivity in forest soils is two orders of magnitude larger than vertical (Koivusalo H, pers. comm.)
       HorizFlux(satlayers)=100*Soil_1.KLh(satlayers).*Soil_1.dzs(satlayers)*Stand_1.Slope; 
   end
   
   %---- call Soil_WaterFlow;  and update SoilProfile -object state variables
   [Soil_1.h,Soil_1.Wliq,Soil_1.Wice,Infil,Evap,Drain,Roff,Soil_1.h_pond,FL, Soil_1.KLh, MaxEva, RHsoil,Soil_1.GWL, MBE]=...
       Soil_1.Soil_WaterFlow(MAIN.dt,0.1*MAIN.dt,Rootsink,HorizFlux,qtop,h_atm,lBCh,lBCtype);
   
   if any(isnan(Soil_1.h))
       disp('h is nan from watflow'), pause
   end
   clear h_atm lBCh lBCtype
   
   % ----- boundary conditions for heat flow ---------------
   uBCt=[1 Gsoil]; %surface boundary is flux-based
   
   if MAIN.Soil_HeatFlow_LBC(1)==1, %lower boundary is flux based and equals conduction to/from bedrock
       Bedrock_1.T=Bedrock_1.Fourier_Homogenous(MAIN.dt,Soil_1.T(end),Bedrock_1.Tannual);
       Gbottom=Bedrock_1.HeatFlux(Bedrock_1.T);
       lBCt=[1 Gbottom(1)];
   else
       lBCt=[0 MAIN.Soil_HeatFlow_LBC(2)]; %LBC=fixed temperature given as user input
   end
   
   %---- call Soil_HeatFlow
   [Soil_1.Wliq, Soil_1.Wice, Soil_1.T, Fheat, Soil_1.Ktherm]=Soil_1.Soil_HeatFlow(MAIN.dt,0.1*MAIN.dt,P,Infil/MAIN.dt,Tprec,uBCt,lBCt);
   clear Tprec uBCt lBCt
   %     figure(101);
   %     subplot(221); plot(Soil_1.Wliq,Soil_1.zs,'r-');title('Wliq')
   %     subplot(222); plot(Soil_1.h,Soil_1.zs,'r-');title('h')
   %     subplot(223); plot(Soil_1.KLh,Soil_1.zs,'r-');title('K')
   %     subplot(224); plot(FL(:,1),Soil_1.zs,'r-');title('q')
   
   if any(isnan(Soil_1.Wliq)), disp('Error:SoilHeatFlow returned Wliq = NaN'); end
   
   %in case there is water ponding at surface, one could update bryophyte
   %water storage here assuming mosses take up as much water as they can...

   
    %% ************* update outputs ******************************************
   
   outtime=[time(1) DOY time(4) time(5)]; %timestamp [YY DOY hh mm]

   %--- update soil outputs oSoil: save state variables of SoilProfile -object and soil-related fluxes

   IO.write_oSoil(outtime,Soil_1,FL,Fheat,Infil,Evap,Drain,HorizFlux,Roff,Rootsink,MBE,qtop*MAIN.dt, Rsoil)
%    
   %--- update oStand: save state variables of Stand_1
   IO.write_oStand(outtime,Stand_1);
   
   %----update oWLF: save fluxes from wet leaves
   IO.write_oWLF(outtime,flx_w,cum_w,Tleaf_w);
   clear flx_w cum_w Tleaf_w
   %----update oPlant, oDLF: save PlantType state variables and leaf-scale
   %fluxes etc. for each PlantType and layer.
   IO.write_oPlant(outtime,PTypes,PFlx);
   clear PFlx
   
   %---update oFloor: save forest floor fluxes 
   IO.write_oFloor(outtime,Tf,Hf,L_molar*Ef,Gsoil,Fcf,Rsoil,Ef,Esoil,Trfall_s);
   
   %----update oBryo: save state variables of BryoTypes, and moss-related
   %fluxes
   IO.write_oBryo(outtime,BryoTypes,Flx_b);
   clear Flx_b
   
   %---update oFlux: save vertical flux profiles and sink-source distributions
   IO.write_oFlux(outtime,dz,Csource,Esource,Hsource,Rsource,Fcf,Ef+Esoil,Hf,Gsoil)
   clear Tf Hf LEf Gsoil Fcf Rsoil Ef Esoil Csource Hsource Esource Rsource Trfall_s
   
   %--- update microclimatic outputs oMeteo & oRadi
   IO.write_oMeteo(outtime,U,T,H2O,CO2,W,df,Trfall);
   clear U T H2O CO2 W df Trfall
   
   albGlob=(alb1*(Ib1+Id1) + alb2*(Ib2+Id2))./(Ib1+Id1+Ib2+Id2); %albedo for global radiation
   IO.write_oRadi(outtime,f_sl,SWb1,SWd1,SWu1,SWb2,SWd2,SWu2,LW,alb1,alb2,albGlob,q_sl1,q_sl2,q_sh1,q_sh2,LWup,LWdn,LWleaf,q_soil1,q_soil2);
   clear f_sl SWb1 SWd1 SWu1 SWb2 SWd2 SWu2 LW LWup LWdn LWleaf alb1 alb2 albGlob q_sl1 q_sl2 q_sh1 q_sh2 q_soil1 q_soil2
   
   %update IO index
%   IO.set_out_index(IO.ind+1);
           
  Time_per_run(n)=toc(dummy1);
  
end % end of forcing 

    
Time_used_total=toc(dummy0) 
clear dummy0

save(MAIN.resultsfile,'oDLF','oWLF','oPlant','oBryo','oFloor','oStand','oFlux','oMeteo','oRadi','oBryo','oSoil','MAIN','FORCING','Stand_1','PTypes','BryoTypes','Soil_1','Bedrock_1','-mat')

%clear all
%clear write_o* %reset persistent variables!
%clear write_oBryo write_oPlant write_oFloor write_oStand write_oFlux write_oMeteo write_oRadi
%clear MAIN PTypes BryoTypes Soil_1 Stand_1 oDLF oWLF oPlant oBryo oFloor oStand oFlux oMeteo oRadi oBryo oSoil FORCING N m k z dz 

end




