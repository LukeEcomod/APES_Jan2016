% Script for plotting APES results
clear all; close all

import DataAnalysis.* ModelStatistics.*

folder='D:\APES_Jan2016\';  % apes results are here!

figtext='Demo ';
%% set period and load data from 2005

year = 2005;
fmonth = 6;
lmonth = 6;
fday=1;
lday=2;

respath=[folder 'Main\'];

disp('Loading APES results...')
resfile=sprintf('R%04d_%02d%02d%02d%02d.mat',year,fmonth,lmonth,fday,lday);
load([respath resfile])
disp('...done.')

tvec=oRadi.time; %[YYYY Doy hh mm]
Doy=tvec(:,2) + tvec(:,3)/24 + tvec(:,4)/1440; %Doy in model results

%definitions
fDoy=1; lDoy=365;

dt=MAIN.dt;
N=length(Doy); %timesteps
DataCol=[0.5 0.5 0.5];


%% constants

parcf=4.56; % conversion of PAR from Wm-2 to umol m-2 s-1
L_molar=44100; %J/mol latent heat of vaporization at 20 deg C
Mwater=18.0153e-3; % Molecular weight of water kg/mol

%% canopy parameters
hc=Stand_1.hc; %stand height
z=Stand_1.z; %height, m
dz=Stand_1.z(2)-Stand_1.z(1);
zs=Soil_1.zs; % soil depth

f1m=find(z>1.0, 1 ); %index corresponding to 1m height above ground



%% ---- forcings at uppermost gridpoint
time= FORCING.time; %YYYY MM DD hh mm
Uref= FORCING.U; %measured velocity above canopy
ustar=FORCING.Ustar; %friction velocity (m/s). Has to be >0.02 m/s for numerical stability
Utop=Uref./ustar; %  U/Ustar at reference height
T_ref=FORCING.Ta; %air temperature degC
CO2_ref=FORCING.CO2; %CO2 mixing ratio (mol/mol)
H2O_ref=FORCING.H2O; %H2O mixing ratio (mol/mol)
RH_ref=FORCING.RH; %RH (%)
P=FORCING.Pamb; % Pressure (Pa)

Ib1=FORCING.PARdir; %direct PAR in Wm-2
Id1=FORCING.PARdif; %diffuse PAR in Wm-2
Ib2=FORCING.NIRdir; % direct NIR radiation Wm-2
Id2=FORCING.NIRdif; % diffuse NIR radiation Wm-2
SWtop=Ib1+Id1+Ib2+Id2; % global radiation Wm-2
ea=FORCING.emi_atm; % atmospheric emissivity
%LWdn0=ea*StefBolz*(T_ref+273.15).^4; % downwelling LW (Wm-2)

%precipitation
PrecW=FORCING.Prec; % Precipitation rate (mm/s = kg /m2 /s)
%precipitation index for screening data
PrecIndex=TimeAve(PrecW,24,1); % 0 if no P during last 12h


%% RADIATION-related outputs: calculate albedo and absorbed radiation above canopy
Fr=sum(oFlux.Rsource*dz,1); %total 'non-isothermal' heatflux'

%LW=ones(size(SWtop')).*NaN;
%LW=oRadi.LWnet(end,:);

%canopytop
Rnet=SWtop' - oRadi.SWu1(end,:) - oRadi.SWu2(end,:) + oRadi.LWnet(end,:) -Fr;%oRadi.LW(end,:); %isothermal net radiation above canopy
%1m height
Rnetsub=oRadi.SWb1(f1m,:) + oRadi.SWd1(f1m,:) + oRadi.SWb2(f1m,:) + oRadi.SWd2(f1m,:) -oRadi.SWu1(f1m,:)  - oRadi.SWu2(f1m,:) + oRadi.LWnet(f1m,:);
%Parsub= oRadi.SWb1(f1m,:) + oRadi.SWd1(f1m,:);


%***** period *********
f=find(Doy>=fDoy & Doy<=lDoy); 

%*************

h=figure('Name', [figtext 'Radiation'], 'NumberTitle','on');

% measured and modeled Rnet above canopy
subplot(2,2,1); 
%plot(Doy(f), Rnet(f),'.-', 'MarkerSize',5,'Color',DataCol); hold on
plot(Doy(f), Rnet(f), 'r-', Doy(f), Rnetsub(f),'b-');
ylabel('R_n (Wm^{-2})'); xlabel('Doy');
axis tight; %ylim([-150 800]); xlim([190 214]);

subplot(2,2,2)
y1=DiurnalCycle(tvec(f,3), tvec(f,4), Rnet(f)','30min');
y2=DiurnalCycle(tvec(f,3), tvec(f,4), Rnetsub(f)','30min');
plot(y1(:,1), y1(:,3), 'r.-', y2(:,1), y2(:,3),'b-');
ylabel('R_n (Wm^{-2})'); xlabel('Doy'); title('ensemble cycles')
axis tight; %ylim([-150 800]); xlim([190 214]);
clear y1 y2

% albedos
subplot(223);plot(Doy,oRadi.alb1, 'g-'); hold on
subplot(223);plot(Doy,oRadi.alb2, 'r-',Doy, oRadi.alb_glob, 'k-');
ylim([0 0.3]); ylabel('\alpha (-)'); title('albedos')
legend('Par','Nir','R_g')


%% Canopy-scale energy fluxes
h=figure('Name', [figtext ' Energy Balance'], 'NumberTitle','on');

subplot(121);
plot(Doy, Rnet, 'r.-',Doy,oFlux.H(end,:)+oFlux.LE(end,:)-oFlux.G,'bo-',Doy,oRadi.LWnet(end,:),'c.-','LineWidth',1); 
ylabel('Wm^{-2}'); xlabel('doy'); %xlim([fDoy-0.5 lDoy+1.5])
legend('R_{net}','H+LE-G','LW_n')
% 

subplot(122)
AE=Rnet;
TF=oFlux.H(end,:)+oFlux.LE(end,:)-oFlux.G;
f=find(isnan(AE)==0 & isnan(TF)==0);

plot(AE,TF,'ko');ylabel('TF'); xlabel('AE');
p=polyfit(AE(f),TF(f),1); 
R2 = rsquare(AE(f),TF(f));
title(sprintf('y= %.2f x + %.2f,  R^2=%.2f', p(1), p(2),R2)); axis tight; axis square

%% ecosystem-level fluxes & fluxes at 1m height

h=figure('Name', [figtext ' Ecosystem Flx'], 'NumberTitle','on');

subplot(221); 
plot(Doy, oFlux.Fc(end,:), 'g-', Doy, oFlux.Fc(f1m,:), 'k-'); ylabel('NEE (umolm-2s-1)'); legend('abo', '1m');axis tight
subplot(222); 
plot(Doy, oFlux.H(end,:), 'r-',Doy, oFlux.H(f1m,:), 'k-'); ylabel('H (Wm-2)'); axis tight
subplot(223); 
plot(Doy, oFlux.LE(end,:), 'b-',Doy, oFlux.LE(f1m,:), 'k-'); ylabel('LE (Wm-2)'); axis tight
subplot(224);
plot(Doy, oFlux.G, 'k-'); ylabel('G (Wm-2)'); axis tight

%% Moss layer: plot Moss_1 -responses and state

h=figure('Name', [figtext ' Mosses'], 'NumberTitle','on','PaperOrientation','Portrait','PaperUnits','normalized',...
    'PaperPositionMode','manual','PaperPosition', [0.1 0.1 0.8 0.8]);

ModCol1=[0.5 0.5 0.5];
ModCol2=[0.2 0.2 0.2];

Moss_1=BryoTypes(1);

subplot(4,1,1); 
plot(Doy,oBryo(1).T,'r-'); hold on
plot(Doy, oMeteo.T(2,:), 'k-', Doy,oSoil.T(1,:),'g-'); ylabel('^{\circ}C'); hold on
legend('T_{m}','T_{a}','T_{s,1}','Orientation','Horizontal'); xlabel('doy');axis tight; xlim([min(Doy) max(Doy)])


subplot(4,1,2); 
plot(Doy,oBryo(1).W./Moss_1.Wmax,'-','Color',ModCol2); hold on
ylabel('w_m^* (-)'); xlabel('doy');axis tight; ylim([-0.05 1.05]);xlim([min(Doy) max(Doy)])

subplot(4,1,3);
plot(Doy,oBryo(1).LE,'-','Color', ModCol1); hold on
plot(Doy,oBryo(1).H,'r-'); hold on 
plot(Doy, oBryo(1).G, 'k.-'); 
ylabel('W m^{-2}');legend('LE_{m,1}','H_{m,1}','G_{m,1}','Orientation','Horizontal'); 
axis tight; xlim([min(Doy) max(Doy)])

subplot(4,1,4);
plot(Doy,oBryo(1).GPP,'g-', Doy, oBryo(1).Respi,'-','Color',ModCol2); hold on
ylabel('GPP_{m} & R_{a,m} (\mumol m^{-2} s^{-1})'); xlabel('doy'); xlim([min(Doy) max(Doy)])


%% Soil temperature&moisture
cols=['krgbcmkrgbcm'];
Nl=length(zs);
lays=[1 3 5 10:5:Nl];
depths=zs(lays);

h=figure('Name', [figtext ' Soil temporal'], 'NumberTitle','on','PaperOrientation','Portrait','PaperUnits','normalized',...
    'PaperPositionMode','manual','PaperPosition', [0.1 0.1 0.8 0.8]);

labtext={};
n=0;
for k=lays,
    n=n+1;
    labtext{n}=[num2str(depths(n)) ' cm'];
    if n<7,
        subplot(121);
        plot(Doy,oSoil.T(k,:),'-','color',cols(n)); hold on
        subplot(122);
        plot(Doy,oSoil.Wliq(k,:),'-','color',cols(n)); hold on
    else
        subplot(121);
        plot(Doy,oSoil.T(k,:),'--','color',cols(n)); hold on
        subplot(122);
        plot(Doy,oSoil.Wliq(k,:),'--','color',cols(n)); hold on
    end
    if n>12, n=1; end
end
subplot(121); ylabel('T (degC)')
subplot(122); ylabel('\theta (m3m-3)'); legend(labtext)
clear k n labtext

h=figure('Name', [figtext ' Soil vertical'], 'NumberTitle','on','PaperOrientation','Portrait','PaperUnits','normalized',...
    'PaperPositionMode','manual','PaperPosition', [0.1 0.1 0.8 0.8]);

steps=[1:10:N];

labtext={};
n=0;
for k=steps,
    n=n+1;
    if n>12, n=1; end
    labtext{n}=[num2str(k)];
    if n<7,
        subplot(131);
        plot(oSoil.T(:,k), zs,'-','color',cols(n)); hold on
        subplot(132);
        plot(oSoil.Wliq(:,k), zs,'-','color',cols(n)); hold on
        subplot(133);
        plot(oSoil.h(:,k), zs,'-','color',cols(n)); hold on
    else
        subplot(131);
        plot(oSoil.T(:,k), zs,'-','color',cols(n)); hold on
        subplot(132);
        plot(oSoil.Wliq(:,k), zs,'-','color',cols(n)); hold on
        subplot(133);
        plot(oSoil.h(:,k), zs,'-','color',cols(n)); hold on
    end
    
        
end
subplot(131); xlabel('T (degC)'); ylabel('zs (m)'); axis tight
subplot(132); xlabel('\theta (m3m-3)'); axis tight
subplot(133); xlabel('head (m)'); legend(labtext); axis tight

%% ensemble profiles: leaf gas-exchange & vertical microclimatic variations

Plot_EnsembleProfiles;

%% PlantType -specific results

col='rgbk';
figure()
for k=1:length(PTypes),
    subplot(221);
    plot(Doy, oPlant(k).GPP,'.-','color',col(k)); hold on
    subplot(222);
    plot(Doy, oPlant(k).Tr*1e3*dt,'.-','color',col(k)); hold on   
    subplot(223);
    plot(Doy, oPlant(k).Respi,'.-','color',col(k)); hold on
end
subplot(221); ylabel('GPP (umolm-2s-1)')
subplot(222); ylabel('Transpiration (mm/timestep)')
subplot(223); ylabel('R_{a} (umolm-2s-1)')


