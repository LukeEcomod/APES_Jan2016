function [a]=generate_LAD_Weibul(z,LAI,h,b,c)
%generate_LAD_Weibul.m: This function generates a Weibul-distributed 
%Leaf Area density profile based on a specified leaf area index 
%LAI, canopy height h, and shape and scale parameters b,c.
%z is height
%Reference: Teske, M.E., and H.W. Thistle, 2004, A library of forest canopy
%structure for use in interception modeling, Forest Ecology and Management,
%198, 341-350. n.b. their formula is missing brackets for the scale param.
%
%Gabriel Katul, 2009
%-------------------------------------------------------------------------
%N=length(z);
dz=z(2)-z(1);
a=0*z;
xx=z(z<=h);
xx=xx/h;

nn=length(xx);
a(1:nn)=-(c/b)*(((1-xx)/b).^(c-1)).*(exp(-((1-xx)/b).^c))./(1-exp(-(1/b)^c));
%a=smooth(a,10);
%a=a';
a=LAI*(a./(sum(a.*dz)));


