% test parameters of Farquhar-optimality -model

P = 101.3; %kPa
Tleaf = 20;
Dleaf = 1.2; %kPa VPD
Ca = 380e-6; %mol/mol
gb_c = 10; %boundary-layer conductance

go = 1e-5; % residual conductance
Lambda = 15e-4; % marginal water use efficiency
s = 0.75; %long-term average ci/ca -ratio

Vcmax25 = 20;
Jmax25 = 2*Vcmax25;
Rd25 = 0.05*Vcmax25;
alpha = 0.2; %quantum efficiency
Theta = 0.7; %curvature of light response

Tresponse(1,1:3)=[69.83e3 200e3 672]; %activation energy (J mol-1), deactivation energy (J mol-1), entropy term (J mol-1 K-1) of  Vcmax
Tresponse(2,1:3)=[61.74e3 185.2e3 624]; % -"- of Jmax
Tresponse(3,1:3)=[33.87e3 0 0]; % -"- of dark respiration


Qp=[0:10:1500];
N=length(Qp);

for k=1:N,
    [gs_v(k),An(k),Rd(k),Ci(k),Cs(k),Anv(k),Anj(k)]=Farquhar_OptiL(Qp(k),Tleaf,Dleaf/P,Ca,gb_c,go,Lambda,s,Vcmax25,Jmax25,Rd25,alpha,Theta,Tresponse);
end

E=1e6*gs_v.*Dleaf/P;

WUE=An./E;
WUE(Qp<100)=NaN;

% --- plot measured light-response -----------
Pmax = 6;
K = 150;

Am=NonRectHyperbola(Qp,Pmax,K);

%--------------------------------------------
figure(1)

subplot(321);
plot(Qp,An,'g-', Qp,Anj,'b.-');
ylabel('A_n umolm-2s-1')

subplot(322);
plot(Qp,E/1000,'b-'); ylabel('E mmol m-2 s-1')

subplot(323);
plot(Qp,WUE,'k-'); ylabel('WUE mol CO2 / mol H2O')

subplot(324);
plot(Qp,1e3*gs_v,'k-'); ylabel('g_s mmol m-2s-1')

subplot(325);
plot(Qp,Ci./Ca*1e-6,'k-'); ylabel('C_i/C_a')