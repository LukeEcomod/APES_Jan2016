function RootProfiles_Jackson
% code for visualizing root distributions in Jackson et al. 1996 Oecologia
% 108

%beta, root biomass (kg/m2) and root/shoot biomass ratio in some biomes:

p(1,1:3)=[0.943 2.9 0.32]; %boreal forest
p(2,1:3)=[0.976 4.4 0.18]; %temperate coniferous
p(3,1:3)=[0.966 4.2 0.23];  %temperate deciduous
p(4,1:3)=[0.945 1.4 3.7]; %temperate grassland
p(5,1:3)=[0.914 1.2 6.6]; %tundra
p(6,1:3)=[0.961 0.15 0.10]; %crops
p(7,1:3)=[0.961 4.1 0.34]; %tropical deciduous
p(8,1:3)=[0.962 4.9 0.19]; %tropical evergreen


d=0.01:0.01:2; % depth (m)

colcode='rgbkcm';
figure(1)
k=0;
for n=[1 2 3 4 5 6],
    k=k+1;
    [Y,R]=RootDistribution(p(n,1),d);
    %Y=p(n,2)*Y; 
    R=p(n,2)*R;
    subplot(121);
    plot(Y,-d,'-', 'color',colcode(k), 'linewidth',2); hold on
    subplot(122);
    plot(R,-d,'-', 'color',colcode(k), 'linewidth',2); hold on
    clear Y R
end
legend('Boreal','Temperate coniferous','Temperate deciduous','Temperate grassland','Tundra','Crops', 'location','southeast')
subplot(121); ylabel('depth (m)','fontweight','bold'); xlabel('Y(z)','fontweight','bold')
subplot(122); ylabel('depth (m)','fontweight','bold'); xlabel('\rho_r (kgm^{-3})','fontweight','bold')


function [Y, R] =RootDistribution(beta,d)
    d=abs(d*100); % cm
    Y=1-beta.^d; % cumulative distribution (Gale & Grigal 1987)
    R=-beta.^d*log(beta); % root distribution as a function of depth
end

end
    
