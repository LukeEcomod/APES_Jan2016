function [Y,L]=BiomassMarklund(d,species)
% returns biomasses of each compartment in kg, based on diameter at breast
% height (d, in cm). species ==1 (Scots Pine), 2 (Norway spruce), 3 (birch)
% for birch only size(Y)=5, for others 8

% Marklund L.G.(1988): Biomassafunktioner for tall, gran och bj�rk i Sverige. SLU Rapport 45, 73p
% K�rkk�inen L., 2005 Appendix 4.
% Kellom�ki et al. (2001). Atm. Env.

% Scots pine
if species==1,
    y1=11.4219*(d./(d+14))-2.2184; % stem wood
    y2=8.8489*(d./(d+16))-2.9748; % stem bark
    y3=9.1015*(d./(d+10))-2.8604; % living branches incl. needles
    y4=7.7681*(d./(d+7))-3.7983; % needles
    y5=9.5938*(d./(d+10))-5.3338; % dead branches
    y6=11.0481*(d./(d+15))-3.9657; % stumps
    y7=13.2902*(d./(d+9))-6.3413; % roots, >=5cm
    y8=8.8795*(d./(d+10))-3.8375; % roots, <5cm
    
    Y=exp([y1 y2 y3 y4 y5 y6 y7 y8]); % matrix of biomasses (kg)
    L=Y(:,4)*5.54; % leaf area (m2) based on specific foliage area (SLA), Kellom�ki et al. 2001 Atm. Env.
end

% Norway spruce
if species==2,
    y1=11.4873*(d./(d+14))-2.2471; % stem wood
    y2=9.8364*(d./(d+15))-3.3912; % stem bark
    y3=8.5242*(d./(d+13))-1.2804; % living branches incl. needles
    y4=7.8171*(d./(d+12))-1.9602; % needles
    y5=9.9550*(d./(d+18))-4.3308; % dead branches
    y6=10.6686*(d./(d+17))-3.3645; % stumps
    y7=13.3703*(d./(d+8))-6.3851; % roots, >=5cm
    y8=7.6283*(d./(d+12))-2.5706; % roots, <5cm

    Y=exp([y1 y2 y3 y4 y5 y6 y7 y8]); % matrix of biomasses (kg)
    L=Y(:,4)*5.65; % leaf area (m2) based on specific foliage area (SLA), Kellom�ki et al. 2001 Atm. Env.
end

% Silver and downy birch
if species==3,
    y1=10.8109*(d./(d+11))-2.3327; % stem wood
    y2=10.3876*(d./(d+14))-3.2518; % stem bark
    y3=10.2806*(d./(d+10))-3.3633; % living brances excluding leaves
    y4=8.0580*(d./(d+8))-3.9823; % Kellom�ki et al. 2001 Atm. Env.
    y5=7.9266*(d./(d+5))-5.9507; % dead branches
    
    Y=exp([y1 y2 y3 y4 y5]); % matrix of biomasses (kg)
    L=Y(:,4)*18.46; % leaf area (m2) based on specific foliage area (SLA), Kellom�ki et al. 2001 Atm. Env.
end
