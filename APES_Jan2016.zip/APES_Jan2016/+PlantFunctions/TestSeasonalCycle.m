%tests seasonal cycle model

%function [f_state,f_bud]=SeasonalCycle(jday,Tave,Tmin,Ts,Slim,Plim)
%
%is a seasonal cycle model for bud-burst date,spring photosynthesis recovery and autumn decline.
%Model is as Bergh et al. 1998 For. Ecol. Manag. 110, 127-139
%Acclimation is described as saturating, reversible function of S, the degree-day
%temperature sum. Decline in autumn is due to frost events.
%
%INPUT:
%       jday - julian day of year
%       Tave - mean air temperature (degC) during previous 24h
%       Tmin - minimum air temperature (degC) during previous 24h
%       Ts - average root zone soil temperature (degC) during previous 24h
%       Slim - Temperature sum for full recovery of photocapacity 
%       Plim - Temperature sum for bud-burst onset
%
%OUTPUT:f_state - state of photosynthetic machinery (0 -1), min(f_rec, f_dorm)
%       f_bud - indicator of bud-burst; 1 when bud burst occured, 0 otherwise
%

doy=1:365;

dTa=TimeAve(Ta,48,2); %daily temperture
dTs=TimeAve(Ts,48,2); %daily soil temperature
N=length(Ta);

Tmin=ones(365,1);
fi=1;
for n=1:365
    li=fi+47;
    Tmin(n)=min(Ta(fi:li))
    fi=li+1;
end

%
Slim=500;
Plim=290;

for n=1:365,
    [f_state(n),f_bud(n)]=SeasonalCycle(n,dTa(n),Tmin(n),dTs(n),Slim,Plim);
end

figure()

plot(doy,f_state,'r-',doy,f_bud,'g-')