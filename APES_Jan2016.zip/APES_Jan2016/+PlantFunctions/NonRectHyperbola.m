function An = NonRectHyperbola(Qp,Pmax,K)

    An = Pmax.*Qp./(Qp + K);
end