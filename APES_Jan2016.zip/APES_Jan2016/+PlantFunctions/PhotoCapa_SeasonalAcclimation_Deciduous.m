function f=PhotoCapa_SeasonalAcclimation_Deciduous(DOY,dd,para)
%f=PhotoCapa_SeasonalAcclimation_Deciduous(dd,para)computes recovery of birch photocapacity as
%function of degree-day sum (dd).
%Assumes: 
%1) linear increase of photocapacity with temperature sum in
%spring; loosely following Linkosalo et al. 2015 (AFM, submitted
%manuscript)
%2) linear decrease with time during autumn senescence (starting from Doy when daylength>12h)
%and lasting 20days (loosely following phenology observations and
%Fracheboud et al., 2009 Plant Phys. (aspen-paper)
%
%Samuli Launiainen, Luke 6.8.2015
%
%IN:
%   DOY - day of year
%   dd - degree-day sum
%   Rpara - para(1)=dd sum for bud-break, para(2)=dd sum for full recovery,
%          para(3)=minimum photocapacity at budbreak
%OUT:
%   f - relative photocapa (0...1)

    f0=0.1; %minimum relative photocapacity
    dd0=para(1); %budburst
    dd1=para(2); %full maturation
    doy0=para(3); %day when senescence starts (corresponds to ~12h daylength)
    Sdur=para(4); %duration of senescence, days
    
%spring recovery    
    if dd>dd0;
        f=min(f0+(dd-dd0)/(dd1-dd0),1);
    else
        f=f0;
    end

%autumn decline
    if DOY>doy0,
        f=max(f0, 1-(DOY-doy0)/Sdur);
    end
end

