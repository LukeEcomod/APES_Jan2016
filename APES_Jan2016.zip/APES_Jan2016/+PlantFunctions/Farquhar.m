function [An, Rd] = Farquhar(Qp,T,Ci)
%[An, Rd] = Farquhar(Qp,T,Ci) calculates leaf photosynthesis (umol m-2 s-1)
%and dark respiration (umol m-2 s-1)
%
% INPUT:    Qp - incident PAR (umol m-2 s-1)
%           T - leaf temperature (deg C)
%           Ci - internal CO2 mixing ratio (umol mol-1)
%
% OUTPUT:   An - assimilation rate (umol m-2 s-1)
%           Rd - dark respiration (umol m-2 s-1)
%
% An is assumed to be minimum of Rubisco, Electron transport or Sucrose
% transport limited photosyntehtic rates. Co-limitation is not concerned
    
% Generic parameters of the model

    Coa=0.21e6;        %Oxygen consentration in air, umol/mol 
    Theta=0.9; % curvature of light response curve
    alpha=0.8; % PAR absorptivity of leaf (-)
    
% Species-specific parameters
    Vcmax25=30;
    Jmax25= 60; % Jmax ~1.97 - 2.68*Vcmax (Leuning,  1997 J. Exp. Bot. 307,345-347.
    Rd25=0.015*Vcmax25; 
    
%Temperature sensitivity parameters

    % Vcmax
    Hav=52.75e3; % J mol-1, activation energy Vcmax
    Hdv=202.3e6; % J mol-1, deactivation energy Vcmax
    Svv=672e3; % J mol-1 K-1, entropy term Vcmax
    
    % Jmax
    Haj=61.74e3; % J mol-1, activation energy Jmax
    Hdv=185.2e3; % J mol-1, deactivation energy Jmax
    Svj= 624e3; % J mol-1 K-1, entropy term Vcmax
    
    % Rd
    Har=32.5e3;  % J mol-1, parameter for Rd sensitivity    
    
    [Vcmax,Jmax,Rd,Tau_star,Kc,Ko]=TempScaling(T); %
    
    %K=Kc.*(1+Coa./Ko); % Michaelis-Menten constant of Rubisco (umol/mol)
    
    % Rubisco-limited photosynthesis (umol m-2 s-1)
    
    Av=Vcmax.*(Ci-Tau_star)./(Ci + Kc.*(1+Coa./Ko));
    
    % ------- electron-limited photosyntehsis (umol m-2 s-1)
    
    J= (alpha*Qp - ( (alpha*Qp + Jmax).^2 - 4*Theta*alpha*Qp.*Jmax ).^0.5)/2*Theta; % potential rate of electron transport
    
    Aj= J/4.*(Ci-Tau_star)./(Ci + 2*Tau_star); 
    
    % ------ Sucrose transport limited photosynthesis (umol m-2 s-1)
    
    As = Vcmax/2;
    
    % -----
    
    An=min(Av,Aj);
    An=min(An,As); % umol m-2 s-1
    
    function [Vcmax,Jmax,Rd,Tau_star,Kc,Ko]=TempScaling(T) % T in degC
    % Adjusts Farquhar model parameters for temperature
        TN=298.15; % K
        R=8.314427;
        Tk=T+273.15; % actual T in Kelvin
    
        %------  Vcmax -------------
        
        C=Vcmax25.*(1+exp((Svv.*TN - Hdv))./(R*TN));
        Vcmax=C.*exp(Hav/(R*NT).*(1-TN./Tk)) ./ (1 + exp((Svv.*Tk -Had)./(R*Tk)));      
        clear C
        
        %------  Jmax -------------
        
        C=Jmax25.*(1+exp((Svj.*TN - Hdj))./(R*TN));
        Jmax=C.*exp(Haj/(R*NT).*(1-TN./Tk)) ./ (1 + exp((Svj.*Tk -Had)./(R*Tk)));      
        clear C
        
        %------ Rd ---------------
        
        Rd=Rd25.*exp(Har*(Tk-TN)./(298*R*Tk));
        
        %-------- CO2 Compensation point -------
        
        Tau_star=Coa./(2*2.6*exp(-0.056*(Tk-TN)));  % Campbell & Norman, 1998
        
        %------- Kc & Ko -------------
        
        %Medlyn et al.,1999 Plant Cell. Environ. 22, 1475-1495
        Kc=404*exp(59.4*(Tk-TN)./(298*R*Tk)); %Michaelis-Menten constant for CO2 umol/mol 
        Ko=2.48e5*exp(36*(Tk-TN)./(298*R*Tk)); %Michaelis-Menten constant for oxygen inhibition umol/mol 
    
    end % Temp_scaling

end

