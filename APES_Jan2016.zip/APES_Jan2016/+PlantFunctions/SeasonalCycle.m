function [f_state,f_bud]=SeasonalCycle(jday,Tave,Tmin,Ts,Slim,Plim)
%function [f_state,f_bud]=SeasonalCycle(jday,Tave,Tmin,Ts,Slim,Plim)
%
%is a seasonal cycle model for bud-burst date,spring photosynthesis recovery and autumn decline.
%Model is as Bergh et al. 1998 For. Ecol. Manag. 110, 127-139
%Acclimation is described as saturating, reversible function of S, the degree-day
%temperature sum. Decline in autumn is due to frost events.
%
%INPUT:
%       jday - julian day of year
%       Tave - mean air temperature (degC) during previous 24h
%       Tmin - minimum air temperature (degC) during previous 24h
%       Ts - average root zone soil temperature (degC) during previous 24h
%       Slim - Temperature sum for full recovery of photocapacity
%       Plim - Temperature sum for bud-burst onset
%
%OUTPUT:f_state - state of photosynthetic machinery (0...1), min(f_rec, f_dorm)
%       f_bud - indicator of bud-burst; 1 when bud burst occured, 0 otherwise
%
%USAGE: call once per day, assume f_state constant over day
%
%Temperature thresholds are given as T1-T6
%
%Samuli Launiainen METLA, 27.5.2011

f_photo=0.05; % minimum photocapacity
S0=Slim; % degree days for full acclimation
P0=Plim; % degree days for bud burst
persistent S P Tprev f_dorm0

%initialize
if isempty(S)==1
    S=0;
    P=0;
    Tprev=Tave;
end

% reset development stages at begining of year
if jday<=1,
    S=0;
    P=0;
    f_dorm0=1;
end

% these are species specific (?) and should be given as parameter
%thresholds below apply for Norway spruce (Bergh et al. (1998), For. Ecol. Manag. 110,127-139
T1=0; %
T2=-3; % threshold for reversal of recovery of photocapacity
T3=-4; %
T4=0; % budburst
T5=-5; % budburst
T6=-5; % severe frost threshold

% dormancy recovery

if Ts>=0, fthaw=1; else fthaw=0.5; end % soil frost modifier

% f2 - speed of recovery
if Tmin>=T1 && Tprev>=T1,
    f2=1;
elseif Tmin<T2 || Tprev<T2,
    f2=0;
else
    f2=min([(Tmin-T2)/(T1-T2), (Tprev-T2)/(T1-T2)]);
end

%f1 - setback of recovery if severe night frosts

if Tmin>=T2
    f1=0;
elseif Tmin>T3 && Tmin<T2,
    f1=0.3*(T2-Tmin)/(T2-T3);
else
    f1=0.3; % maximum reduction of capacity is 30 % / day
    
end

% Calculate new state of acclimation and f_rec0
if Tmin>=T2,
    dS=Tave*fthaw*f2; % advance of recovery
else
    dS=-S*f1; % reversal of recovery
end

S=S + dS; % new state of acclimation

if S<S0
    f_rec0=f_photo + (1-f_photo)*S/S0;
else % at S0 full recovery has occurred
    f_rec0=1;
end
f_rec0=max(f_photo, f_rec0); % ensure capacity remains greater than minimum value.


% reduction of capacity in autumn is irreversible process

if jday>=244 % can occur only from sept onwards
    f_rec0=1;
    f_frost=0; % if Tmin>0
    
    %if Tmin<0, f_dorm=0.15; end % decrease capacity by 15 % if mild night frost
    if Tmin<0 && Tmin>T6, f_frost=0.1*Tmin/T6; end
    if Tmin<=T6, f_frost=0.1; end
    f_dorm0=f_dorm0-f_frost; % state of photomachinery followed by consequtive frost events
    f_dorm0=max(f_photo, f_dorm0); % ensure capacity remains greaten than minimum value
else
    f_dorm0=1;
end

% budburst
if P<P0
    if Tmin<=T5, f4=0; end
    if Tmin>=T4, f4=1; end
    if Tmin<T4 && Tmin>T5, f4=(Tmin-T5)/(T4-T5); end
    
    P=P+Tave*fthaw*f4;
end

if P>=P0, f_bud=1; else f_bud=0; end % budburst occurs when P exceeds P0

Tprev=Tave; % set Tprev equal to Tave
% output
f_state=min(f_rec0, f_dorm0); % select most limiting
end
