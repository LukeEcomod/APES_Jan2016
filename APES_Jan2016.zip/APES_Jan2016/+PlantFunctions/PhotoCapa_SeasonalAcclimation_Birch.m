function f=PhotoCapa_SeasonalAcclimation_Birch(dd,para)
%f=PhotoCapa_SeasonalAcclimation_Birch(dd,para)computes recovery of birch photocapacity as
%function of degree-day sum (dd).
%
%IN:
%   dd - degree-day sum
%   para - para(1)=dd sum for bud-break, para(2)=dd sum for full recovery,
%          para(3)=minimum photocapacity at budbreak
%OUT:
%   f - relative photocapa (0...1)

    dd0=para(1);
    dd1=para(2);
    f0=para(3);
    
    if dd>dd0;
        f=min(f0+(dd-dd0)/(dd1-dd0),1);
    else
        f=f0;
    end
end

