function [gs_v,An,Rd,Ci,Cs,Av,Aj]=Farquhar_OptiL(Qp,Tleaf,Dleaf,Ca,gb_c,go,Lambda,CiCa_ave,Vcmax25,Jmax25,Rd25,alpha,Theta,Tresponse)
            %-- Linearized optimality model for combined Photosynthesis - Stomatal conductance 
            %
            %INPUT: Qp - absorbed PAR at leaves (umol m-2 s-1)
            %       Tleaf  - leaf temperature (degC)
            %       Dleaf -  vapor pressure gradient e_sat(Tleaf) - e(amb)(mol/mol )
            %       Ca - ambient CO2 mixing ratio (mol/mol)
            %       gb_c - laminar boundary layer conductance for CO2 (mol m-2 s-1) 
            %       go - residual conductance for CO2 (mol m-2 s-1) 
            %       Lambda - marginal water use efficiency (mol CO2 / mol H2O)
            %       s - long term ci/ca -ratio (-)
            %       Vcmax25
            %       Jmax25
            %       Rd25
            %       alpha
            %       Theta
            %OUTPUT:gs_v - stomatal conductance for H2O (mol m-2 s-1)
            %       An - assimilation rate (umol m-2 s-1)
            %       Rd - dark respiration (umol m-2 s-1)
            %       Ci - leaf internal CO2 mixing ratio (ppm)
            %       Cs - leaf surface CO2 mixing ratio (ppm)
            %
            %Gaby Katul & S. Launiainen 2009-2011
            

            
            Ca=1e6*Ca; %umol/mol 
            Dleaf=max(eps, 1e6.*Dleaf); %umol/mol       
    
            Coa=0.21e6;%Oxygen consentration in air, umol/mol 
            %Theta=0.7; % curvature of light response curve
            
            %alpha=(1-0.15)/2; %quantum yield factor of electron transport - here assume that Qp is already absorbed PAR!
            %alpha=0.3; % Kellom�ki & Wang, addjusted for PAR absorptivity ~0.85
            %alpha=0.2;
            %alpha=0.4; %Medlyn et al.
            
            % addjust coefficients for temperature, seasonal cycle and soil
            % water content
             
            [Vcmax,Jmax,Rd,Gamma_star,Kc,Ko]=Farquhar_Scaling(Tleaf,Vcmax25,Jmax25,Rd25,Tresponse);

            %------------- Assume Photosynthesis is Rubisco limited
    %         a1=Vcmax; a2=Kc.*(1+Coa./Ko);
    %         slopec=a1./(s*Ca+a2);
            slopec=Vcmax./(CiCa_ave*Ca + Kc.*(1+Coa./Ko));
            gs=slopec.*(-1+((Ca-Gamma_star)./(1.6*Dleaf.*Lambda)).^(1/2))+ go; % Rubisco-limited gs
            Av=slopec.*(Ca-Gamma_star).*( 1-sqrt((1.6*Dleaf.*Lambda)./(Ca-Gamma_star)) );
            Ci=Ca-Av./gs; % Ci
            gsv=gs;
            Civ=Ci;

            %------------ Assume Photosynthesis is Light-limited

            J= ((alpha*Qp + Jmax) - ( (alpha*Qp + Jmax).^2 - 4*Theta*alpha*Qp.*Jmax ).^0.5)/(2*Theta); % potential rate of electron transport

    %       a1=J/4;
    %       a2=2*Tau_star;
            %slopeq=a1./(s*Ca+a2);
            slopeq = J/4./(CiCa_ave*Ca + 2*Gamma_star);
            gs=slopeq.*(-1+((Ca-Gamma_star)./(1.6*Dleaf.*Lambda)).^(1/2))+ go;
            Aj=slopeq.*(Ca-Gamma_star).*( 1-sqrt((1.6*Dleaf.*Lambda)./(Ca-Gamma_star)) );
            Ci=Ca-Aj./gs; % Ci
            gsj=gs; % Light limited gs
            Cij=Ci;

            % now select the smaller of Av, Aj

            An=Av;
            Ci=Civ;
            gs=gsv;
            f=find(Aj<Av);
            An(f)=Aj(f);
            Ci(f)=Cij(f);
            gs(f)=gsj(f); clear f
            f=find(An -Rd <0);  
            gs(f)=go; % if photo is less than dark respiration, assume that stomata are closed
            An(f)=0; %Aq(f); % should one set An=0 then?
            Ci(f)=Cij(f); clear f
            Cs=max(Ca-An./gb_c, 0.5*Ca);

            gs_v=1.6*gs; % stomatal conductance for H2O

            
            %% ****************************************************************************************************************       
        function [Vcmax,Jmax,Rd,Gamma_star,Kc,Ko]=Farquhar_Scaling(T,Vcmax25,Jmax25,Rd25,Tresponse) 
        % Adjusts Farquhar model parameters for stemperature. Formulation of Medlyn et al., 2002.Plant Cell Environ. 25,
        % 1167-1179.
        %INPUT:
        %   T - temperature degC
        %   Vcmax25
        %   Jmax25
        %   Rd25
        %   Tresponse - temperature sensitivity matrix: (1,1:3)=Vcmax,(2,1:3)=Jmax, (3:,1:3) = Rd.
        %   Rd(1)
        % OUTPUT:
        %   Vcmax(T)
        %   Jmax(T)
        %   Rd(T)
        %   Gamma_star -compensation point
        %   Kc 
        %   Ko

            Tk=T+273.15; % actual T in Kelvin
            
            TN=298.15; % reference temperature (K)
            R=8.314427; % gas constant

            %Coa=210; %O2 concentration in air (mmol/mol)
            
            %Temperature sensitivity parameters: To optimize speed, refer directly to obj.xx

            % Vcmax
            Hav=Tresponse(1,1); %52.75e3; % J mol-1, activation energy Vcmax
            Hdv=Tresponse(1,2); %202.3e3; % J mol-1, deactivation energy Vcmax
            Svv=Tresponse(1,3); %672; % J mol-1 K-1, entropy term Vcmax           
%             Hav=1e3*obj.Vcmax_Tscaling(1); %52.75e3; % J mol-1, activation energy Vcmax
%             Hdv=1e3*obj.Vcmax_Tscaling(2); %202.3e3; % J mol-1, deactivation energy Vcmax
%             Svv=1e3*obj.Vcmax_Tscaling(3); %672; % J mol-1 K-1, entropy term Vcmax

            % Jmax
            Haj=Tresponse(2,1); % 61.74e3; % J mol-1, activation energy Jmax
            Hdj=Tresponse(2,2); %185.2e3; % J mol-1, deactivation energy Jmax
            Svj=Tresponse(2,3); % 624; % J mol-1 K-1, entropy term Vcmax
            
            % Rd 
            Har=Tresponse(3,1); %32.5e3;  % J mol-1, parameter for Rd sensitivity  

            %------  Vcmax -------------%umol/mol
            
            
            C=Vcmax25.*(1+exp((Svv.*TN - Hdv)./(R*TN)));
            Vcmax=C.*exp(Hav/(R*TN).*(1-TN./Tk)) ./ (1 + exp((Svv.*Tk -Hdv)./(R*Tk)));      
            clear C

            %------  Jmax ------------- %umol/mol

            C=Jmax25.*(1+exp((Svj.*TN - Hdj)./(R*TN)));
            Jmax=C.*exp(Haj/(R*TN).*(1-TN./Tk)) ./ (1 + exp((Svj.*Tk -Hdj)./(R*Tk)));      
            clear C

            %------ Rd ---------------

            Rd=Rd25.*exp(Har*(Tk-TN)./(TN*R*Tk)); %umol/mol

            %-------- CO2 Compensation point -------
            %Medlyn et al.,1999 Plant Cell. Environ. 22, 1475-1495
            Gamma_star=36.9 +1.88*(Tk-TN) + 0.036*(Tk-TN).^2; %umol/mol
          
            %------- Kc & Ko -------------

            %Medlyn et al.,1999 Plant Cell. Environ. 22, 1475-1495
            Kc=404*exp(59.4*(Tk-TN)./(TN*R*Tk)); %Michaelis-Menten constant for CO2 umol/mol 
            Ko=2.48e5*exp(36*(Tk-TN)./(TN*R*Tk)); %Michaelis-Menten constant for oxygen inhibition umol/mol 
            
        end 
 end