function A = TimeAve(dat,ap,outp)
% function A = TimeAve(dat,ap,outp)
% returns block-average (A or Am) or running average (Ar) of matrix dat
% over given averaging period "ap" (number of observations)
% Assumes constant time step. Give in outp which output you want
% SL 2007
%IN:
%   dat - data matrix (NxC)
%   ap - averagind period (Nobs)
%   outp - 1: block average [NxC matrix], 2: block average
%   [N/ap x C], 3: running average [NxC]
%OUT:
%   A - averaged matrix as desired by ap and outp
%

[N,C]=size(dat);
A=ones(N,C).*NaN;
Am=ones(fix(N/ap),1);
Ar=A;
for n=1:C,
    %block-average
    j=1;
    for i=1:ap:N
        wl=i;
        wh=min(i+ap,N);
        A(wl:wh,n)=nanmean(dat(wl:wh,n));
        Am(j,n)=nanmean(dat(wl:wh,n)); %averaged into a vector of length N/ap
        j=j+1;
    end
    %running average
    Ar(:,n)=filter(ones(1,ap)/ap,1,dat(:,n));
end

if outp==1,A=A;end %block ave,
if outp==2,A=Am;end % block averaged into a vector of length N/ap
if outp==3,A=Ar;end %running ave

end