function y=CanopySurface(a,S,r)
%function y=CanopySurface(as,z,S,n) creates a 2D matrix /(r x N) for surface
%plotting.
%Input: a - leaf area density profile
%       S - data vector (Nx1), where N is number of vertical layers
%       r - number of horizontal nodes in output vector

% as - leaf area density profile
% z - height
% 
CC=1e6;
R=length(S);
a=a./max(a); %normalized lad
x=0:1/r:1;
x=CC*x;
a=CC*a; a=fix(a);
y=ones(length(x),R).*NaN; % vector
size(y)
for k=1:R,
    y(x<a(k),k)=S(k); 
end
y=y';
