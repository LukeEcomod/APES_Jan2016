function x=DiurnalCycle(hh,mm,y, ap)
%Computes diurnal cycle over data
%IN:
%   hh - hour [Nx1]
%   mm - minute [Nx1]
%   y - data vector [Nx1]
%   ap - ensemble period ('hourly', '30min')
%OUT:
%   x - matrix [T x 12] where T = 24/aveperiod and columns are as:
%   x(:,1)=decimal hour
%   x(:,2)=Nobs
%   x(:,3)=nanmean
%   x(:,4)=nanstd
%   x(:,5)=standard error of the mean
%   x(:,6)=nanmedian
%   x(:,7:11)=quantile([0.05 0.25 0.5 0.75 0.95]
%
%SL 12.1.2014

%[R,C]=size(y); %rows, cols

if strcmpi(ap,'hourly'),
    hour=0:1:23;
    x=ones(24,11).*NaN;
    
    n=1;
    for t=hour
        f=find(hh==t & isnan(y)==0);
        x(n,2)=length(f); % no of observations
        x(n,3)=mean(y(f));
        x(n,4)=std(y(f));
        x(n,5)=std(y(f))./x(n,2); %standard error of the mean
        x(n,6)=median(y(f));
        x(n,7:11)=quantile(y(f),[0.05 0.25 0.50 0.75 0.95]);
        x(n,1)=t;
        clear f;
        n=n+1;
    end
elseif strcmpi(ap,'30min'),
    hour=0:0.5:23.5;
    tvec=hh + mm/60;
    x=ones(24,11).*NaN;
    
    n=1;
    ftime=0;
    for t=hour
        f=find(tvec>ftime & tvec<=t & isnan(y)==0);
        x(n,2)=length(f); % no of observations
        x(n,3)=mean(y(f));
        x(n,4)=std(y(f));
        x(n,5)=std(y(f))./x(n,2); %standard error of the mean
        x(n,6)=median(y(f));
        x(n,7:11)=quantile(y(f),[0.05 0.25 0.50 0.75 0.95]);
        x(n,1)=t;
        clear f;
        ftime=t;
        n=n+1;
    end
    
else
    disp('DiurnalCycle: ERROR - input "ap" should be "hourly" or "30min"')
    x=[];
end
end