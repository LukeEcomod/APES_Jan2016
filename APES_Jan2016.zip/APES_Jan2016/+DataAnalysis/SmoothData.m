function yy = SmoothData(y, nn)
%function yy = SmoothData(y,nn) returns "smoothed" vector yy using nn-point
%moving filter
%INPUT: y - vector to be smoothed
%       nn - span (must be odd)
%OUTPUT: yy - smoothed data
%
%Samuli Launiainen 17.3.2014

    K=length(y);
    yy=ones(K,1).*NaN;

    dn=(nn-1)/2;
          
    %first elements
    yy(1)=y(1);
    for k=2:dn,
        yy(k)=sum(y(1:k))/(2*k-1);
    end
    
    %last elements
    for k=K-dn:K
        yy(k)=sum(y(k:K))/(K-k+1);
    end
    %middle
    for k=(dn+1):1:(K-dn) 
        yy(k)=sum(y(k-dn:k+dn))/nn;
    end

% figure(999);
% plot(y,'r.-'); hold on;
% plot(yy,'k-'), pause
end

