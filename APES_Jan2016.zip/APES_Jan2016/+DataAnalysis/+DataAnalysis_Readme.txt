**************************************************

Samuli Launiainen (Luke) 23.2.2015
samuli.launiainen@luke.fi

**************************************************

package '+DataAnalysis' contains Matlab functions for looking APES model outputs.

Incomplete - update!