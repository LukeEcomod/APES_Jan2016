function [ME,MAE,MSE,RMSE, N]=ModelErrorStatistics(x,y)
%function [ME,MAE,MSE,RMSE]=ModelErrorStatistics(x,y) computes error statistics
%
%INPUT:
%   x - measured data, Nx1 -array
%   y - modeled data, Nx1 array
%OUTPUT:
%   ME - mean error: ME=1/N*sum(y-x)
%   MAE - mean absolute error: MAE=1/N*sum(abs(y-x))
%   MSE - mean squared error: MSE=1/N*sum( (y-x).^2)
%   RMSE - root mean squared error: MSE= sqrt(1/N*sum( (y-x).^2))
%   N - number of real-valued x-y -pairs excluding NaN's
%
%Samuli Launiainen, 14.5.2014 METLA

if size(x)~=size(y)
    disp('Error: x and y should be of equal size')
    return;
end

f=find(isnan(x)==0 & isnan(y)==0);

x=x(f); y=y(f);
N=length(x);

%compute error statistics

ME=1/N*sum(y-x);

MAE=1/N*sum(abs(y-x));

MSE=1/N*sum( (y-x).^2);

RMSE=sqrt(MSE);


