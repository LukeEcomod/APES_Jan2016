function [NS, N]=NashSutchliffe(x,y)
%function NS=NashSutchliffe(x,y) computes model efficiency parameter
%of Nash & Sutchliffe.
% 
% Nash�Sutcliffe efficiencies can range from ?? to 1. An efficiency of 1 (E = 1) corresponds to a perfect match of modeled to the observed data. 
% An efficiency of 0 (E = 0) indicates that the model predictions are as accurate as the mean of the observed data, whereas an efficiency 
% less than zero (E < 0) occurs when the observed mean is a better predictor than the model or, in other words, when the residual variance 
% (described by the numerator in the expression above), is larger than the data variance (described by the denominator). 
% Essentially, the closer the model efficiency is to 1, the more accurate the model is.
% The efficiency coefficient is sensitive to extreme values and might yield suboptimal results when the dataset contains large outliers.
%
%INPUT:
%   x - measured values
%   y - modeled values

%INPUT:
%   x - measured data, Nx1 -array
%   y - modeled data, Nx1 array
%OUTPUT:
%   NS - Nash & Sutchliffe model efficiency parameter: 
%        NS = 1- sum((x-y).^2)/sum(x - mean(x))
%   N - number of real-valued x-y -pairs excluding NaN's
%
%Samuli Launiainen, 14.5.2014 METLA

if size(x)~=size(y)
    disp('Error: x and y should be of equal size')
    return;
end

f=find(isnan(x)==0 & isnan(y)==0);

x=x(f); y=y(f);
N=length(x);

NS = 1- sum((x-y).^2)/sum((x - mean(x)).^2);