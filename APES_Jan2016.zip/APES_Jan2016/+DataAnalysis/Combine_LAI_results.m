%% extract variables from APES results to struct

clear all; close all;
%% constants

parcf=4.56; % conversion of PAR from Wm-2 to umol m-2 s-1
L_molar=44100; %J/mol latent heat of vaporization at 20 deg C
Mwater=18.0153e-3; % Molecular weight of water kg/mol

%%----------------------------------------
year = 2005;
fmonth = 6;
lmonth = 8;
fday=1;
lday=31;

%measured fluxes
% load('M:\Research\MLCM\Hyde\ForcingData\Hy2005APES.mat');
% D=Hy05APES;
% time=D.time;
% fi=find(time(:,2)==fmonth & time(:,3)==fday & time(:,4)==0 & time(:,5)==15); %first index
% li=find(time(:,2)==lmonth & time(:,3)==lday & time(:,4)==23 & time(:,5)==45); %last index
% 
% daynum=datenum(time(fi:li,1),time(fi:li,2), time(fi:li,3)) - datenum(time(fi:li,1),1,0) + time(fi:li,4)/24 + time(fi:li,5)/(24*60);


dt=60*30;

%% SA results

%load('M:\Research\ET_rotation\Motti\VT_M�nty_Samuli.mat')
%load('M:\Research\ET_rotation\Motti\OMT Kuusi Juupajoki simuloinnit.mat')
%filepath='M:\Research\MLCM\COMPILE_0314\Runs\Rotation\Spruce\';
%
filepath='M:\Research\ETsynthesis\APES_LAI\';

S=struct(); %contains stand informations
R=struct(); %contains simulation results
F=struct();
AProf=struct();
%%
for n=1:16,

    disp('Loading APES results...')
    resfile=sprintf('LAI%02d_%02d%02d%02d%02d.mat',n,fmonth,lmonth,fday,lday);

    resfile=[filepath resfile]
    load(resfile);
    disp('...done.')
    
    time=FORCING.time;
    daynum=datenum(time(:,1),time(:,2),time(:,3)) +time(:,4)/24 + time(:,5)/(24*60) - datenum(year,1,0);
    % ----------
    hc=Stand_1.hc;
    z=Stand_1.z; %height
    f1m=find(z>0.5,1,'first');
    
    K=length(daynum);
    N=length(z);
    dz=abs(z(2)-z(1));
    %------------
    
    % stand structure
    S(n).Stand_1=Stand_1;
    S(n).PTypes=PTypes;
    S(n).BryoTypes=BryoTypes;
    if n==1,
        S(n).Soil_1=Soil_1;
    end
    %S(n).Bedrock_1=Bedrock_1;
       
    R(n).oStand=oStand;
    R(n).oSoil=oSoil;
    R(n).oPlant=oPlant;
    R(n).oFloor=oFloor;
    R(n).oBryo=oBryo;
    
    %reduce dimensions from oRadi and oMeteo to save space
    k=[1:5:N];
    zp=z(k);
    
    % microclimatic variables
    R(n).oMeteo.zp=zp;
    R(n).oMeteo.U=oMeteo.U(k,:);
    R(n).oMeteo.T=oMeteo.T(k,:);
    R(n).oMeteo.H2O=oMeteo.H2O(k,:);
    R(n).oMeteo.CO2=oMeteo.CO2(k,:);
    R(n).oMeteo.Trfall=oMeteo.Trfall(k,:);
    R(n).oMeteo.W=oMeteo.W(k,:);
    R(n).oMeteo.df=oMeteo.W(k,:);
    
    kmax=find(z>Stand_1.hc,1,'first');
    k=[1:4:kmax N];
    zp=z(k);
    R(n).oRadi.zp=zp;
    R(n).oRadi.f_sl=oRadi.f_sl(k,:);
    R(n).oRadi.SWb1=oRadi.SWb1(k,:);
    R(n).oRadi.SWd1=oRadi.SWd1(k,:);
    R(n).oRadi.SWb2=oRadi.SWb2(k,:);
    R(n).oRadi.SWd2=oRadi.SWd2(k,:);
    R(n).oRadi.SWu1=oRadi.SWu1(k,:);
    R(n).oRadi.SWu2=oRadi.SWu2(k,:);
    R(n).oRadi.LW=oRadi.LW(k,:);
    R(n).oRadi.LWleaf=oRadi.LWleaf(k,:);
        
    R(n).oRadi.alb1=oRadi.alb1;
    R(n).oRadi.alb2=oRadi.alb2;
    R(n).oRadi.alb_glob=oRadi.alb_glob;
    
    %
    Rabs=(1-oRadi.alb_glob).*( oRadi.SWb1(end,:) + oRadi.SWd1(end,:) + oRadi.SWb2(end,:) + oRadi.SWd2(end,:));
    Rnet=Rabs + oRadi.LW(end,:); %net radiation above canopy

    % at sub-canopy
    Rnetsub=oRadi.SWb1(f1m,:) + oRadi.SWd1(f1m,:) + oRadi.SWb2(f1m,:) + oRadi.SWd2(f1m,:) -oRadi.SWu1(f1m,:)  - oRadi.SWu2(f1m,:) + oRadi.LW(f1m,:);
    Parsub= oRadi.SWb1(f1m,:) + oRadi.SWd1(f1m,:);
    
    %stand-scale values
    R(n).oStand.Rn=Rnet; clear Rnet
    R(n).oStand.H=oFlux.H(end,:);
    R(n).oStand.LE=oFlux.LE(end,:);
    R(n).oStand.Fc=oFlux.Fc(end,:);
    
    %compute stand GPP, WUE, LUE and PlantType-specific LUE, WUE
    ET=R(n).oStand.LE./L_molar; %molm-2s-1
    aPAR=(1-oRadi.alb1).*(oRadi.SWb1(end,:) + oRadi.SWd1(end,:))*parcf; %absorbed PAR, mumolm-2s-1
    GPP=(oPlant(1).GPP + oPlant(2).GPP)' - oBryo.GPP; 
    
    %Transpi (molm-2s-1) per PlantType
    Tr1=1000/Mwater*oPlant(1).Tr'; %mm/s=kgm-2s-1*/kgmol-1 = molm-2s-1
    Tr2=1000/Mwater*oPlant(2).Tr'; %mm/s=kgm-2s-1*/kgmol-1 = molm-2s-1
    
    %absorbed PAR per PlantType
    dz=Stand_1.z(2)-Stand_1.z(1);
    aPAR1=zeros(K,1);
    aPAR2=aPAR1;
    for tt=1:K
        aPAR1(tt)= sum(PTypes(1).lad*dz.*(oRadi.q_sl1(:,tt) + oRadi.q_sh1(:,tt))*parcf); %Wm-2 --> umolm-2s-1
        aPAR2(tt)= sum(PTypes(2).lad*dz.*(oRadi.q_sl1(:,tt) + oRadi.q_sh1(:,tt))*parcf); %Wm-2 --> umolm-2s-1
    end
    clear kk
    
    R(n).oStand.WUE=1e-6*GPP./ET'; %mol/mol
    R(n).oStand.LUE=GPP./aPAR'; %mol/mol
    R(n).oPlant(1).WUE=1e-6*oPlant(1).GPP'./Tr1+eps; %wue mol/mol
    R(n).oPlant(2).WUE=1e-6*oPlant(2).GPP'./Tr2+eps; %wue mol/mol
    R(n).oPlant(1).LUE=oPlant(1).GPP'./aPAR1; %wue mol/mol
    R(n).oPlant(2).LUE=oPlant(2).GPP'./aPAR2; %wue mol/mol
    
    R(n).oBryo.LUE=-oBryo.GPP./(oRadi.q_floor1*parcf+eps)'; %mol/mol
    WUEb=-1e-6*oBryo.GPP./(oBryo.LE/L_molar)';
    WUEb(WUEb<0 | WUEb>0.2)=NaN; 
    R(n).oBryo.WUE=WUEb; %mol/mol
    clear Tr1 Tr2 GPP aPAR ET aPAR1 aPAR2 WUEb;
    
    % ground heat flux at ~10cm depth
    f=find(Soil_1.zs<-0.05 & Soil_1.zs>-0.15);
    R(n).oStand.G=nanmean(oSoil.Fheat(f,:));

    k=[1:4:kmax N];
    zp=z(k);
    R(n).zp=zp;
    R(n).Fc=oFlux.Fc(k,:);
    R(n).LE=oFlux.LE(k,:);
    R(n).H=oFlux.H(k,:);
    R(n).G=oFlux.G;
    R(n).Rsoil=oFloor.Rsoil;
  
    
    %% Compute and save ensemble-averaged profiles
    
    RH_ref=FORCING.RH; %relative humidity
    Ta_ref=FORCING.Ta; %air temperature
    ustar=FORCING.Ustar; %friction velocity (m/s)
    P=FORCING.Pamb; % Pressure (Pa)
    PrecW=FORCING.Prec/dt; % Precipitation rate (mm/s = kg /m2 /s)
    
    fdayn=121;
    ldayn=240;
    
    PrecIndex=TimeAve(PrecW,48,1); % 0 if no P during last 24h
    j=find( (daynum>fdayn & daynum<ldayn) );% "select periods
    dryc=find(PrecIndex==0 & RH_ref<90 & ustar>0.25); % dry turbulent conditions
    kk=intersect(j,dryc);

    fh=13; lh=16;    % time span of the profile
    ff=find(time(:,4)>=fh & time(:,4)<=lh);% & Fwat(:,zabo)>0 & Fwat(:,zabo)< 400 & Fc(:,zabo)~=0);
    f=intersect(ff,kk);
    clear ff

    fh=1; lh=3;    % time span of the profile
    ff=find(time(:,4)>=fh & time(:,4)<=lh);% & Fwat(:,zabo)>0 & Fwat(:,zabo)< 400 & Fc(:,zabo)~=0);
    g=intersect(ff,kk);
    clear kk ff
    
    %.D = daytime, .D. = nighttime
    
    % scalars
    AProf(n).D.U=nanmean(oMeteo.U(:,f),2);
    AProf(n).N.U=nanmean(oMeteo.U(:,g),2);
    AProf(n).D.Ta=nanmean(oMeteo.T(:,f),2);
    AProf(n).N.Ta=nanmean(oMeteo.T(:,g),2);
    AProf(n).D.CO2=nanmean(oMeteo.CO2(:,f),2);
    AProf(n).N.CO2=nanmean(oMeteo.CO2(:,g),2);
    AProf(n).D.H2O=nanmean(oMeteo.H2O(:,f),2);
    AProf(n).N.H2O=nanmean(oMeteo.H2O(:,g),2);
    
    %radiation
    AProf(n).D.f_sl=nanmean(oRadi.f_sl(:,f),2); 
    AProf(n).D.SWb1=nanmean(oRadi.SWb1(:,f),2);
    AProf(n).D.SWd1=nanmean(oRadi.SWd1(:,f),2);
    AProf(n).D.SWb2=nanmean(oRadi.SWb2(:,f),2);
    AProf(n).D.SWd2=nanmean(oRadi.SWd2(:,f),2);
    AProf(n).D.LW=nanmean(oRadi.LW(:,f),2);
    AProf(n).N.LW=nanmean(oRadi.LW(:,g),2);
    AProf(n).D.q_sl1=nanmean(oRadi.q_sl1(:,f),2);
    AProf(n).D.q_sh1=nanmean(oRadi.q_sh1(:,f),2); 
    AProf(n).D.q_sl2=nanmean(oRadi.q_sl2(:,f),2);
    AProf(n).D.q_sh2=nanmean(oRadi.q_sh2(:,f),2);     
    AProf(n).D.LWleaf=nanmean(oRadi.LWleaf(:,f),2);

    
    %flux profiles
    AProf(n).D.Fc=nanmean(oFlux.Fc(:,f),2); 
    AProf(n).N.Fc=nanmean(oFlux.Fc(:,g),2); 
    AProf(n).D.LE=nanmean(oFlux.LE(:,f),2); 
    AProf(n).N.LE=nanmean(oFlux.LE(:,g),2); 
    AProf(n).D.H=nanmean(oFlux.H(:,f),2); 
    AProf(n).N.H=nanmean(oFlux.H(:,g),2); 
        
    %plantType -properties
    
    %PT1
    AProf(n).Pt1.D.dT_sl=nanmean(oDLF(1).sl.Tleaf(:,f)-oMeteo.T(:,f),2);
    AProf(n).Pt1.D.dT_sh=nanmean(oDLF(1).sh.Tleaf(:,f)-oMeteo.T(:,f),2);
    AProf(n).Pt1.D.dT=nanmean((oDLF(1).sl.Tleaf(:,f)-oMeteo.T(:,f)).*oRadi.f_sl(:,f) + (oDLF(1).sh.Tleaf(:,f)-oMeteo.T(:,f)).*(1-oRadi.f_sl(:,f)),2);
    
    AProf(n).Pt1.N.dT_sl=nanmean(oDLF(1).sl.Tleaf(:,g)-oMeteo.T(:,g),2);
    AProf(n).Pt1.N.dT_sh=nanmean(oDLF(1).sh.Tleaf(:,g)-oMeteo.T(:,g),2);
    AProf(n).Pt1.N.dT=nanmean((oDLF(1).sl.Tleaf(:,g)-oMeteo.T(:,g)).*oRadi.f_sl(:,g) + (oDLF(1).sh.Tleaf(:,g)-oMeteo.T(:,g)).*(1-oRadi.f_sl(:,g)),2);
    
    AProf(n).Pt1.D.An_sl=nanmean(oDLF(1).sl.An(:,f),2);
    AProf(n).Pt1.D.An_sh=nanmean(oDLF(1).sh.An(:,f),2);
    AProf(n).Pt1.D.An=nanmean(oDLF(1).sl.An(:,f).*oRadi.f_sl(:,f) + oDLF(1).sh.An(:,f).*(1-oRadi.f_sl(:,f)),2);
    
    AProf(n).Pt1.D.Rd_sl=nanmean(oDLF(1).sl.Rd(:,f),2);
    AProf(n).Pt1.D.Rd_sh=nanmean(oDLF(1).sh.Rd(:,f),2);   
    AProf(n).Pt1.D.Rd=nanmean(oDLF(1).sl.Rd(:,f).*oRadi.f_sl(:,f) + oDLF(1).sh.Rd(:,f).*(1-oRadi.f_sl(:,f)),2);
    
    AProf(n).Pt1.D.E_sl=nanmean(oDLF(1).sl.E(:,f),2);
    AProf(n).Pt1.D.E_sh=nanmean(oDLF(1).sh.E(:,f),2);
    AProf(n).Pt1.D.E=nanmean(oDLF(1).sl.E(:,f).*oRadi.f_sl(:,f) + oDLF(1).sh.E(:,f).*(1-oRadi.f_sl(:,f)),2);
    
    AProf(n).Pt1.D.H_sl=nanmean(oDLF(1).sl.H(:,f),2);
    AProf(n).Pt1.D.H_sh=nanmean(oDLF(1).sh.H(:,f),2);
    AProf(n).Pt1.D.H=nanmean(oDLF(1).sl.H(:,f).*oRadi.f_sl(:,f) + oDLF(1).sh.H(:,f).*(1-oRadi.f_sl(:,f)),2);
    
    AProf(n).Pt1.N.H_sl=nanmean(oDLF(1).sl.H(:,g),2);
    AProf(n).Pt1.N.H_sh=nanmean(oDLF(1).sh.H(:,g),2);
    AProf(n).Pt1.N.H=nanmean(oDLF(1).sl.H(:,g).*oRadi.f_sl(:,g) + oDLF(1).sh.H(:,g).*(1-oRadi.f_sl(:,g)),2);
    
    %ci/ca
    Ca=oMeteo.CO2;
    Ca(Ca>600)=NaN;
    cica_sl=oDLF(1).sl.Ci./Ca;
    cica_sh=oDLF(1).sl.Ci./Ca;
    AProf(n).Pt1.D.CiCa_sl=nanmean(cica_sl(:,f),2);
    AProf(n).Pt1.D.CiCa_sh=nanmean(cica_sh(:,f),2);
    AProf(n).Pt1.D.CiCa=nanmean(cica_sl(:,f).*oRadi.f_sl(:,f) + cica_sh(:,f).*(1-oRadi.f_sl(:,f)),2);
    clear cica_sl cica_sh;
    
   %gsv
    AProf(n).Pt1.D.gsv_sl=nanmean(oDLF(1).sl.gsv(:,f),2);
    AProf(n).Pt1.D.gsv_sl=nanmean(oDLF(1).sh.gsv(:,f),2);
    AProf(n).Pt1.D.gsv=nanmean(oDLF(1).sl.gsv(:,f).*oRadi.f_sl(:,f) + oDLF(1).sh.gsv(:,f).*(1-oRadi.f_sl(:,f)),2);
    
    %wue
    wue_sl=1e-6*oDLF(1).sl.An./oDLF(1).sl.E;
    wue_sh=1e-6*oDLF(1).sh.An./oDLF(1).sh.E;
    AProf(n).Pt1.D.Wue_sl=nanmean(wue_sl(:,f),2);
    AProf(n).Pt1.D.Wue_sh=nanmean(wue_sh(:,f),2);  
    AProf(n).Pt1.D.Wue=nanmean(wue_sl(:,f).*oRadi.f_sl(:,f) + wue_sh(:,f).*(1-oRadi.f_sl(:,f)),2);
    clear wue_sl wue_sh
    
    %VPD
    p=ones(N,K);
    for j=1:N,
        p(j,:)=P;
    end
    vpd_sl=(PlantType.e_sat(oDLF(1).sl.Tleaf)./p - oMeteo.H2O).*(1e-3*p);
    vpd_sh=(PlantType.e_sat(oDLF(1).sh.Tleaf)./p - oMeteo.H2O).*(1e-3*p);
    
    
    AProf(n).Pt1.D.Vpd_sl=nanmean(vpd_sl(:,f),2);
    AProf(n).Pt1.D.Vpd_sh=nanmean(vpd_sh(:,f),2); 
    AProf(n).Pt1.D.Vpd=nanmean(vpd_sl(:,f).*oRadi.f_sl(:,f) + vpd_sh(:,f).*(1-oRadi.f_sl(:,f)),2);
    
    % PlantType2
    AProf(n).Pt2.D.dT_sl=nanmean(oDLF(2).sl.Tleaf(:,f)-oMeteo.T(:,f),2);
    AProf(n).Pt2.D.dT_sh=nanmean(oDLF(2).sh.Tleaf(:,f)-oMeteo.T(:,f),2);
    AProf(n).Pt2.N.dT_sl=nanmean(oDLF(2).sl.Tleaf(:,g)-oMeteo.T(:,g),2);
    AProf(n).Pt2.N.dT_sh=nanmean(oDLF(2).sh.Tleaf(:,g)-oMeteo.T(:,g),2);

    AProf(n).Pt2.D.An_sl=nanmean(oDLF(2).sl.An(:,f),2);
    AProf(n).Pt2.D.An_sh=nanmean(oDLF(2).sh.An(:,f),2);
    AProf(n).Pt2.D.Rd_sl=nanmean(oDLF(2).sl.Rd(:,f),2);
    AProf(n).Pt2.D.Rd_sh=nanmean(oDLF(2).sh.Rd(:,f),2);   
    
    AProf(n).Pt2.D.E_sl=nanmean(oDLF(2).sl.E(:,f),2);
    AProf(n).Pt2.D.E_sh=nanmean(oDLF(2).sh.E(:,f),2);
    
    AProf(n).Pt2.D.H_sl=nanmean(oDLF(2).sl.H(:,f),2);
    AProf(n).Pt2.D.H_sh=nanmean(oDLF(2).sh.H(:,f),2);    
    AProf(n).Pt2.N.H_sl=nanmean(oDLF(2).sl.H(:,g),2);
    AProf(n).Pt2.N.H_sh=nanmean(oDLF(2).sh.H(:,g),2);
    
    %ci/ca
    Ca=oMeteo.CO2;
    Ca(Ca>600)=NaN;
    cica_sl=oDLF(2).sl.Ci./Ca;
    cica_sh=oDLF(2).sh.Ci./Ca;
    AProf(n).Pt2.D.CiCa_sl=nanmean(cica_sl(:,f),2);
    AProf(n).Pt2.D.CiCa_sh=nanmean(cica_sh(:,f),2);
    clear cica_sl cica_sh;
    
    %gsv
    AProf(n).Pt2.D.gsv_sl=nanmean(oDLF(2).sl.gsv(:,f),2);
    AProf(n).Pt2.D.gsv_sl=nanmean(oDLF(2).sh.gsv(:,f),2);
    
    %wue
    wue_sl=1e-6*oDLF(1).sl.An./oDLF(2).sl.E;
    wue_sh=1e-6*oDLF(1).sh.An./oDLF(2).sh.E;
    AProf(n).Pt2.D.Wue_sl=nanmean(wue_sl(:,f),2);
    AProf(n).Pt2.D.Wue_sh=nanmean(wue_sh(:,f),2);   
    clear wue_sl wue_sh
    
    %VPD
    p=ones(N,K);
    for j=1:N,
        p(j,:)=P;
    end
    vpd_sl=(PlantType.e_sat(oDLF(2).sl.Tleaf)./p - oMeteo.H2O).*(1e-3*p);
    vpd_sh=(PlantType.e_sat(oDLF(2).sh.Tleaf)./p - oMeteo.H2O).*(1e-3*p);
    AProf(n).Pt2.D.Vpd_sl=nanmean(vpd_sl(:,f),2);
    AProf(n).Pt2.D.Vpd_sh=nanmean(vpd_sh(:,f),2);   
    clear vpd_sl vpd_sh
    
end


%%

save([filepath 'LAI_results.mat'],'daynum','FORCING','R','AProf','S');

%save('OMTSpruce_results.mat','daynum','FORCING','R','AProf','S','Watflx','StandStruc')
