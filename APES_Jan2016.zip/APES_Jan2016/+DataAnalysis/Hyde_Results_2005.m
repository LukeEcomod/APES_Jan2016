% Script for analysing APES results vs. data at SMEAR II in 2005. Uses
% additional CanopyCampaign measurements that differ from other years.

close all

import DataAnalysis.*

%% set period and load data from 2005

year = 2005;
fmonth = 6;
lmonth = 6;
fday=1;
lday=2;

disp('Loading APES results...')
resfile=sprintf('R%04d_%02d%02d%02d%02d.mat',year,fmonth,lmonth,fday,lday);
load(resfile)
disp('...done.')

Moss_1=BryoTypes(1);

%------ Hyde dataset ------------

load('M:\Research\MLCM\Hyde\ForcingData\Hy2005APES.mat');
D=Hy05APES;

time=D.time;

fi=find(time(:,2)==fmonth & time(:,3)==fday & time(:,4)==0 & time(:,5)==15); %first index
li=find(time(:,2)==lmonth & time(:,3)==lday & time(:,4)==23 & time(:,5)==45); %last index

daynum=datenum(time(fi:li,1),time(fi:li,2), time(fi:li,3)) - datenum(time(fi:li,1),1,0) + time(fi:li,4)/24 + time(fi:li,5)/(24*60);
fday=fix(min(daynum)); lday=fix(max(daynum));

figtext=sprintf('SMEAR II %04d_%03d-%03d',year,fday,lday);

%% constants

parcf=4.56; % conversion of PAR from Wm-2 to umol m-2 s-1
L_molar=44100; %J/mol latent heat of vaporization at 20 deg C
Mwater=18.0153e-3; % Molecular weight of water kg/mol

%% canopy parameters
dt=60*30;
hc=Stand_1.hc;
z=Stand_1.z; %height
zs=Soil_1.zs; % soil depth

f3m=find(z>3.0, 1 ); %index corresponding to sub-canopy flux height
f1m=find(z>1.0, 1 ); %index corresponding to sub-canopy radiation meas height

SoilDepth=0.6; % depth of soil profile
%% Forcing variables

%---- forcings at uppermost gridpoint
time= FORCING.time; %YYYY MM DD hh mm
Uref= FORCING.U; %measured velocity above canopy
ustar=FORCING.Ustar; %friction velocity (m/s). Has to be >0.02 m/s for numerical stability
Utop=Uref./ustar; %  U/Ustar at reference height
T_ref=FORCING.Ta; %air temperature degC
CO2_ref=FORCING.CO2; %CO2 mixing ratio (mol/mol)
H2O_ref=FORCING.H2O; %H2O mixing ratio (mol/mol)
RH_ref=FORCING.RH; %RH (%)
P=FORCING.Pamb; % Pressure (Pa)

Ib1=FORCING.PARdir; %direct PAR in Wm-2
Id1=FORCING.PARdif; %diffuse PAR in Wm-2
Ib2=FORCING.NIRdir; % direct NIR radiation Wm-2
Id2=FORCING.NIRdif; % diffuse NIR radiation Wm-2
SWtop=Ib1+Id1+Ib2+Id2; % global radiation Wm-2
%ea=FORCING.emi_atm(n); % atmospheric emissivity
%LWdn0=ea*StefBolz*(T_ref+273.15).^4; % downwelling LW (Wm-2)

%precipitation
PrecW=FORCING.Prec; % Precipitation rate (mm/s = kg /m2 /s)

%precipitation index for screening data
PrecIndex=TimeAve(PrecW,24,1); % 0 if no P during last 12h

%% calculate albedo and absorbed radiation above canopy
dz=Stand_1.z(2)-Stand_1.z(1);
Fr=sum(oFlux.Rsource*dz,1);

Rnet=SWtop' - oRadi.SWu1(end,:) - oRadi.SWu2(end,:) + oRadi.LW(end,:); %isothermal net radiation above canopy

% at sub-canopy
Rnetsub=oRadi.SWb1(f1m,:) + oRadi.SWd1(f1m,:) + oRadi.SWb2(f1m,:) + oRadi.SWd2(f1m,:) -oRadi.SWu1(f1m,:)  - oRadi.SWu2(f1m,:) + oRadi.LW(f1m,:);
Parsub= oRadi.SWb1(f1m,:) + oRadi.SWd1(f1m,:);

% Measured PAR and Global albedos

mParalb=D.rPAR(fi:li)./(D.PAR(fi:li)+eps);
mParalb(D.PAR(fi:li)<100)=NaN;

mGlobalb=D.rGlob(fi:li)./(D.Glob(fi:li)+eps);
mGlobalb(D.Glob(fi:li)<100)=NaN;

% Measured Sub-canopy Radiation data
N=length(D.time);

mParsub(:,1)=D.SubRad.ParAve; % average of 4 sensors
Dummy=D.SubRad.Par;
for n=1:N
    mParsub(n,1)=nanmean(Dummy(n,1:4)); % average of 4 sensors
    mParsub(n,2)=nanmin(Dummy(n,1:4));  % min of 4 sensors
    mParsub(n,3)=nanmax(Dummy(n,1:4)); % max of 4 sensors
    mParsub(n,4)=nanstd(Dummy(n,1:4)); % std
end


Dummy=D.SubRad.Rnet;
mRnetSub=ones(N,4)*NaN;
for n=1:N
    mRnetsub(n,1)=nanmean(Dummy(n,1:5)); % average of 5 sensors
    mRnetsub(n,2)=nanmin(Dummy(n,1:5));  % min of 5 sensors
    mRnetsub(n,3)=nanmax(Dummy(n,1:5)); % max of 5 sensors
    mRnetsub(n,4)=nanstd(Dummy(n,1:5)); % std
end
clear Dummy
    
%% ---------- subcanopy EC datasets filtered using std_w

SubFlag=D.FluxFiles.Sub(:,58); %1=ok, 2=intermediate, 3=bad (based on std_w);
NEEs=D.NEEs;
NEEs(SubFlag>=2| NEEs<-5  | NEEs>8)=NaN;
Hs=D.Hs;
Hs(SubFlag>2)=NaN;
LEs=D.LEs;
LEs(SubFlag>2 | LEs<-20 | LEs>150)=NaN;
%------------- Chamber -measured fluxes ---------------------------------

% ------------ chamber-measured forest floor fluxes -----------
% dayn_chL=[];
% Fc_chL=[];
% E_chL=[];

%fluxes in ambient light at each location
ChFLX_plot1=[];
ChFLX_plot2=[];
ChFLX_plot3=[];

%plot1
dummy=D.FloorCh.Plot1.Light(:,2);
hh=fix(dummy/100);
mm=rem(dummy,100);
dummy=D.FloorCh.Plot1.Light(:,1) + hh/24 + mm/24/60;
dayn_chL=dummy; clear dummy
ChFLX_plot1(:,1)=dayn_chL;
dummy=D.FloorCh.Plot2.Light(:,2);
hh=fix(dummy/100);
mm=rem(dummy,100);

Fc_chL=D.FloorCh.Plot1.Light(:,3); %CO2-flux
E_chL=D.FloorCh.Plot1.Light(:,4); %H2O-flux

ChFLX_plot1(:,2:3)=[Fc_chL 1e-3*L_molar*E_chL];

%plot2
dummy=D.FloorCh.Plot2.Light(:,1) + hh/24 + mm/24/60;
f=find(dummy>=214);
dayn_chL=cat(1,dayn_chL,dummy(f));
Fc_chL=cat(1,Fc_chL,D.FloorCh.Plot2.Light(f,3)); %CO2-flux
E_chL=cat(1,E_chL,D.FloorCh.Plot2.Light(f,4)); %H2O-flux

ChFLX_plot2(:,1:3)=[dummy(f) D.FloorCh.Plot2.Light(f,3) 1e-3*L_molar*D.FloorCh.Plot2.Light(f,4)];
clear f dummy
%plot3
dummy=D.FloorCh.Plot3.Light(:,2);
hh=fix(dummy/100);
mm=rem(dummy,100);
dummy=D.FloorCh.Plot3.Light(:,1) + hh/24 + mm/24/60;
dayn_chL=cat(1,dayn_chL,dummy);
Fc_chL=cat(1,Fc_chL,D.FloorCh.Plot3.Light(:,3)); %CO2-flux
E_chL=cat(1,E_chL,D.FloorCh.Plot3.Light(:,4)); %H2O-flux

ChFLX_plot3(:,1:3)=[dummy D.FloorCh.Plot3.Light(:,3) 1e-3*L_molar*D.FloorCh.Plot3.Light(:,4)];
clear dummy

% darkened chamber
%plot1
dummy=D.FloorCh.Plot1.Dark(:,2);
hh=fix(dummy/100);
mm=rem(dummy,100);
dummy=D.FloorCh.Plot1.Dark(:,1) + hh/24 + mm/24/60;
dayn_chD=dummy; clear dummy

Fc_chD=D.FloorCh.Plot1.Dark(:,3); %CO2-flux
E_chD=D.FloorCh.Plot1.Dark(:,4); %H2O-flux
%plot2
dummy=D.FloorCh.Plot2.Dark(:,2);
hh=fix(dummy/100);
mm=rem(dummy,100);
dummy=D.FloorCh.Plot2.Dark(:,1) + hh/24 + mm/24/60;
dayn_chD=cat(1,dayn_chD,dummy); clear dummy
Fc_chD=cat(1,Fc_chD,D.FloorCh.Plot2.Dark(:,3)); %CO2-flux
E_chD=cat(1,E_chD,D.FloorCh.Plot2.Dark(:,4)); %H2O-flux

%plot3
dummy=D.FloorCh.Plot3.Dark(:,2);
hh=fix(dummy/100);
mm=rem(dummy,100);
dummy=D.FloorCh.Plot3.Dark(:,1) + hh/24 + mm/24/60;
dayn_chD=cat(1,dayn_chD,dummy); clear dummy
Fc_chD=cat(1,Fc_chD,D.FloorCh.Plot3.Dark(:,3)); %CO2-flux
E_chD=cat(1,E_chD,D.FloorCh.Plot3.Dark(:,4)); %H2O-flux

LE_chL=1e-3*E_chL*L_molar; % Wm-2
LE_chD=1e-3*E_chD*L_molar; % Wm-2


% permanent soil chambers (soil efflux)
Fc_chA=D.SoilEfflux(fi:li);

% Moss chamber (moss GPP)
Fc_chMoss=D.MossFc.ManualData(:,1:2); % [doy A_moss (umolm-2s-1] NOTE: time vector fishy

%% Stand Net radiation and Sub-canopy radiation
DataCol=[0.5 0.5 0.5];

%***** period *********
f=find(daynum>=193 & daynum<=200); 

%*************

h=figure('Name', [figtext 'Radiation'], 'NumberTitle','on');

% measured and modeled Rnet above canopy
mRnet=D.Rnet(fi:li);
mRnet=mRnet(f);
subplot(2,2,1); 
plot(daynum(f), mRnet,'.-', 'MarkerSize',5,'Color',DataCol); hold on
plot(daynum(f), Rnet(f), 'r-');
ylabel('R_{n,a} (Wm^{-2})'); xlabel('Doy');
axis tight; %ylim([-150 800]); xlim([190 214]);

subplot(2,2,2)
% lin regression during dry periods 
x=D.Rnet(fi:li); 
y=Rnet';
f=find(isnan(x)==0 & isnan(y)==0); 
x=x(f); % measured
y= y(f);  %modeled

disp('Rnet regression')
p=polyfit(x,y,1) 
xvec=[-100 700];
fit=polyval(p,xvec);
R2 = rsquare(x,y)
[ME,MAE,MSE,RMSE, N]=ModelErrorStatistics(x,y)
plot(x,y,'.','Color',DataCol); hold on
plot(xvec,fit,'k-', xvec,xvec,'k--');  
ylabel('R_n mod (Wm^{-2})'); xlabel('R_n meas (Wm^{-2})'); 
title( sprintf('y= %.2f x + %.2f,  R^2=%.2f', p(1), p(2),R2)); axis tight; axis square
text(-90,650,sprintf('ME=%.1f Wm^{-2}\nRMSE=%.1f Wm^{-2}',ME,RMSE))

clear x y f fit xvec p Rs ME MAE RMSE N

%******* Plots measured and modeled PAR and Rnet at sub-canopy

%h=figure('Name', [figtext 'Fig_4'], 'NumberTitle','on');

f=find(daynum>=193 & daynum<=200); 
%f=find(daynum>123 & daynum<300); 
%x-axis
X1=daynum(f)';
X2=fliplr(X1);
Yave=mParsub(fi:li,1);
Yave=Yave(f)';
RangeCol=[0.8 0.8 0.8];

%Sub Par
subplot(2,2,3);

%gray range
% maxi=mParsub(fi:li,1)+mParsub(fi:li,4); %ave + std
% mini=mParsub(fi:li,1)-mParsub(fi:li,4); %ave -std
maxi=mParsub(fi:li,3); %max
mini=mParsub(fi:li,2); %min
maxi=maxi(f)';
mini=mini(f');
%f=find(isnan(maxi)==1);
g=find(isnan(maxi)==0); %good obs
Y1=interp1(X1(g),mini(g),X1);
Y2=interp1(X1(g),maxi(g),X1);
Y2=fliplr(Y2);
%plot range
fill([X1 X2],[Y1 Y2],RangeCol,'EdgeColor','none'); hold on;
plot(X1,Yave,'k-', 'MarkerSize',5); hold on
plot(X1,parcf*Parsub(f),'r-','LineWidth',0.5);
ylabel('PAR_s (\mumolm^{-2}s^{-1})')
ylim([-10 700]); xlim([193 200]);
clear Y1 Y2  g maxi mini

%Sub Rnet
subplot(2,2,4);
Yave=mRnetsub(fi:li,1);
Yave=Yave(f)';
%gray range
%maxi=mRnetsub(fi:li,1)+mRnetsub(fi:li,4); %ave + std
%mini=mRnetsub(fi:li,1)-mRnetsub(fi:li,4); %ave -std
maxi=mRnetsub(fi:li,3); %max
mini=mRnetsub(fi:li,2); %min
maxi=maxi(f)';
mini=mini(f');
%f=find(isnan(maxi)==1);
g=find(isnan(maxi)==0); %good obs
Y1=interp1(X1(g),mini(g),X1);
Y2=interp1(X1(g),maxi(g),X1);
Y2=fliplr(Y2);
%plot range
fill([X1 X2],[Y1 Y2],RangeCol,'EdgeColor','none'); hold on;
plot(X1,Yave,'k-',X1,Rnetsub(f),'r-');
ylabel('R_{n,s} (W m^{-2})'); ylim([-20 300]); xlim([193 200]);
clear Y1 Y2 f g maxi mini

%saveas(h,'Figs\Fig2_Rad05.fig')
%print(h,'Figs\Fig2_Rad05.eps','-dpsc')


%% albedos

h=figure('Name', [figtext ' CanopyAlbedo'], 'NumberTitle','on');
subplot(211);plot(daynum, mParalb,'r.-',daynum, oRadi.alb1, 'k-'); ylim([0 0.25]); title('\lambda_{Par}')
subplot(212);plot(daynum, mGlobalb,'g.-',daynum, oRadi.alb_glob, 'k-') ; title('\lambda_{Rg}')
ylim([0 0.5])

%Canopy-scale energy fluxes
h=figure('Name', [figtext ' Radiation Balance'], 'NumberTitle','on');

plot(daynum,D.Glob(fi:li),'g-'); hold on; plot(daynum,D.Rnet(fi:li),'k-','MarkerFaceColor','k'); hold on; xlabel('doy');
plot(daynum, Rnet, 'r.-',daynum,oFlux.H(end,:)+oFlux.LE(end,:)-oFlux.G,'bo-',daynum,oRadi.LW(end,:),'c.-', ...
    'LineWidth',1); 
ylabel('Wm^{-2}'); xlabel('doy'); xlim([fday lday+1])
legend('R_{g,obs}','R_{n,obs}','R_{n,mod}','H+LE-G','LW')
% 
% % saveas(h,'RadBal.fig')

%% CO2 -fluxes
h=figure('Name', [figtext 'Stand Fc'], 'NumberTitle','on','PaperOrientation','Landscape','PaperUnits','normalized',...
    'PaperPositionMode','manual','PaperPosition', [0.1 0.1 0.8 0.8]);
DataCol=[0.5 0.5 0.5];
%ModCol=[0.2 0.2 0.2];

NEE=D.NEE;
%NEE(D.Flags.NEE==1)=NaN;

subplot(2,3, [1 2]);
plot(daynum, NEE(fi:li), '.','Color',DataCol); hold on
plot(daynum,oFlux.Fc(end,:), 'k-','LineWidth',0.5);  
xlim([fday lday+1]); ylim([-25 10])
ylabel('F_{c,a} (umolm^{-2}s^{-1})'); xlabel('doy');

subplot(2,3, [4 5]);
%Nees=NEEs(fi:li);
%x0=quantile(Nees, [.05 .95]); %remove lowest and highest 2.5% of data to reduce scatter
%Nees(Nees<x0(1) | Nees>x0(2))=NaN;

plot(daynum, NEEs(fi:li), '.','Color',DataCol); hold on
%plot(daynum,Fc_chA,'g-'); hold on
plot(daynum,oFlux.Fc(f3m,:), 'k-','LineWidth',0.5);  hold on
plot(ChFLX_plot1(:,1),ChFLX_plot1(:,2),'r-',ChFLX_plot2(:,1),ChFLX_plot2(:,2),'r-',ChFLX_plot3(:,1),ChFLX_plot3(:,2),'r-')
xlim([fday lday+1]); ylim([-5 10])
ylabel('F_{c,s} (umolm^{-2}s^{-1})'); xlabel('doy');


% scatterplots
subplot(2,3,3);

% use here only measured good-quality NEE
x=NEE(fi:li); %measured
y= oFlux.Fc(end,:)';  %modeled
f=find(D.Flags.NEE(fi:li)==0 & isnan(y)==0); 
x=x(f); % measured
y=y(f);  %modeled

xvec=[-25 max(x) +2];
%p=polyfit(x,y,1); 
p=robustfit(x,y);
p=[p(2) p(1)]
fit=polyval(p,xvec);
R2 = rsquare(x,y)
[ME,MAE,MSE,RMSE, N]=ModelErrorStatistics(x,y)

plot(x, y,'.','Color',DataCol,'MarkerSize',3); hold on;
plot(xvec,fit,'k-', xvec,xvec,'k--');  
ylabel('F_{c,a} mod (\mumol m^{-2}s^{-1})'); xlabel('F_{c,a} meas (\mumol m^{-2}s^{-1})')
title( sprintf('y= %.2f x + %.2f,  R^2=%.2f', p(1), p(2),R2)); axis tight; axis square
ylim([-25 10]); xlim([-25 10]);
text(-22,6,sprintf('ME= %.1f \nRMSE= %.1f \mumolm^{-2}s^{-1}',ME,RMSE))

% linear regression during dry-canopy periods, use here only measured good-quality NEE
x=NEE(fi:li); 
f=find(D.Flags.NEE(fi:li)==0 & PrecIndex==0 & RH_ref<80); 
x=x(f); % measured
y= oFlux.Fc(end,f)';  %modeled

disp('Fc dry-canopy')
%p=polyfit(x,y,1) 
p=robustfit(x,y)
clear p 

subplot(2,3,6);

x=NEEs(fi:li); y= oFlux.Fc(f3m,:)'; xvec=[-5  8];
f=find(isnan(x)==0 & isnan(y)==0 & ustar>0.2);
x=x(f); y=y(f);
%p=polyfit(x,y,1); 
p=robustfit(x,y);
p=[p(2) p(1)]
fit=polyval(p,xvec);
R2 = rsquare(x,y)
[ME,MAE,MSE,RMSE, N]=ModelErrorStatistics(x,y)

plot(x, y,'.','Color',DataCol,'MarkerSize',3); hold on;
plot(xvec,fit,'k-', xvec,xvec,'k--');  
ylabel('F_{c,s} mod (\mumol m^{-2}s^{-1})'); xlabel('F_{c,s} meas (\mumol m^{-2}s^{-1})')
title( sprintf('y= %.2f x + %.2f,  R^2=%.2f', p(1), p(2),R2)); axis tight; axis square
ylim([-3 6]); xlim([-3 6]);
text(-2.5,5,sprintf('ME= %.1f \nRMSE= %.1f \mumolm^{-2}s^{-1}',ME,RMSE))

%saveas(h,'Figs\Fig3_CO2Fluxes05.fig')
%print(h,'Figs\Fig3_CO2Fluxes05.eps','-depsc')

%%% scatplots with point density
% figure(2);
% 
% % scatterplots
% %subplot(2,3,3);
% 
% % use here only measured good-quality NEE
% x=NEE(fi:li); %measured
% y= oFlux.Fc(end,:)';  %modeled
% f=find(D.Flags.NEE(fi:li)==0 & isnan(y)==0); 
% x=double(x(f)); % measured
% y=double(y(f));  %modeled
% 
% xvec=[-25 max(x) +2];
% p=polyfit(x,y,1); fit=polyval(p,xvec);
% R2 = rsquare(x,y)
% [ME,MAE,MSE,RMSE, N]=ModelErrorStatistics(x,y)
% 
% %out = scatplot(x,y,method,radius,N,n,po,ms)
% colormap(flipud(gray))
% hf=scatplot(x,y,'circle',10,10,5,1,6)
% 
% %plot(x, y,'.','Color',DataCol); hold on;
% hold on
% plot(xvec,fit,'r-', xvec,xvec,'r--');  
% ylabel('F_{c,a} mod (\mumol m^{-2}s^{-1})'); xlabel('F_{c,a} meas (\mumol m^{-2}s^{-1})')
% title( sprintf('y= %.2f x + %.2f,  R^2=%.2f', p(1), p(2),R2)); axis tight; axis square
% ylim([-25 10]); xlim([-25 10]);
% text(-22,6,sprintf('ME= %.1f \nRMSE= %.1f \mumolm^{-2}s^{-1}',ME,RMSE))
 

%% H2O -fluxes
h=figure('Name', [figtext ' LE'], 'NumberTitle','on','PaperOrientation','Landscape','PaperUnits','normalized',...
    'PaperPositionMode','manual','PaperPosition', [0.1 0.1 0.8 0.8]);
DataCol=[0.5 0.5 0.5];
ModCol=[0.8 0.8 0.8];

subplot(2,3, [1 2]);
plot(daynum, D.LE(fi:li), '.','Color',DataCol); hold on
plot(daynum,oFlux.LE(end,:), 'k-','LineWidth',0.5);  
xlim([fday lday+1]); ylim([-20 350])
ylabel('LE_a (Wm^{-2})'); xlabel('doy');

subplot(2,3, [4 5]);
plot(daynum, LEs(fi:li), '.','Color',DataCol); hold on
plot(daynum,oFlux.LE(f3m,:), 'k-','LineWidth',0.5);  hold on
plot(ChFLX_plot1(:,1),ChFLX_plot1(:,3),'r-',ChFLX_plot2(:,1),ChFLX_plot2(:,3),'r-',ChFLX_plot3(:,1),ChFLX_plot3(:,3),'r-')
xlim([fday lday+1]); ylim([-10 150])
ylabel('LE_s (Wm^{-2})'); xlabel('doy');

% scatterplots
subplot(2,3,3);

x=D.LE(fi:li); %measured
y= oFlux.LE(end,:)';  %modeled
f=find(isnan(x)==0 & isnan(y)==0); 
fd=find(isnan(x)==0 & isnan(y)==0 & PrecIndex==0 & RH_ref<80); % dry conditions
xdry=x(fd);
ydry=y(fd);
x=x(f); % measured
y=y(f);  %modeled
clear f fd

xvec=[-50 350];
%p=polyfit(x,y,1); 
p=robustfit(x,y);
p=[p(2) p(1)]
fit=polyval(p,xvec);
R2 = rsquare(x,y)
[ME,MAE,MSE,RMSE, N]=ModelErrorStatistics(x,y)

plot(x, y,'.','Color',ModCol,'MarkerSize',4); hold on;
plot(xdry, ydry,'.','Color',DataCol,'MarkerSize',4); hold on;
plot(xvec,fit,'k-', xvec,xvec,'k--');  
ylabel('LE_{a} mod (Wm^{-2})'); xlabel('LE_{a} meas (Wm^{-2})')
title( sprintf('y= %.2f x + %.2f,  R^2=%.2f', p(1), p(2),R2)); axis tight; axis square
ylim([-50 350]); xlim([-50 350]);
text(-40,310,sprintf('ME= %.1f \nRMSE= %.1f \mumolm^{-2}s^{-1}',ME,RMSE))

% x=D.LE(fi:li); y= oFlux.LE(end,:)'; xvec=[min(x)-10 max(x)+10];
% f=find(isnan(x)==0);
% p=polyfit(x(f),y(f),1); fit=polyval(p,xvec);
% plot(D.LE(fi:li), oFlux.LE(end,:),'.','Color',DataCol); hold on;
% %plot only dry-canopy conditions
% f=find(PrecIndex==0 & RH_ref<80 & isnan(x)==0 ); 
% x=D.LE(fi:li); 
% x=x(f); % measured
% y= oFlux.LE(end,f)';  %modeled
% plot(x, y,'.','Color',ModCol); hold on;
% plot(xvec,fit,'k-', xvec,xvec,'k--'); 
% ylabel('LE_{a} mod'); xlabel('LE_{a} meas')
% title( sprintf('y= %.2f x + %.2f', p(1), p(2))); axis tight; axis square
% ylim([-50 400]); xlim([-50 400])

% lin regression during dry periods use here only measured good-quality L

disp('LEdry-canopy above')
%p=polyfit(xdry,ydry,1) 
p=robustfit(xdry,ydry)

subplot(2,3,6);

x=D.LEs(fi:li); %measured
y= oFlux.LE(f3m,:)';  %modeled
f=find(isnan(x)==0 & x >-10 & x<200 & isnan(y)==0); 
fd=find(isnan(x)==0 & isnan(y)==0 & PrecIndex==0 & RH_ref<80); % dry conditions
xdry=x(fd);
ydry=y(fd);
x=x(f); % measured
y=y(f);  %modeled
clear f fd

xvec=[-30 max(x) +20];
p=robustfit(x,y);
p=[p(2) p(1)]
fit=polyval(p,xvec);
R2 = rsquare(x,y)
[ME,MAE,MSE,RMSE, N]=ModelErrorStatistics(x,y)

plot(x, y,'.','Color',ModCol,'MarkerSize',4); hold on;
plot(xdry, ydry,'.','Color',DataCol,'MarkerSize',4); hold on;
plot(xvec,fit,'k-', xvec,xvec,'k--');  
ylabel('LE_{s} mod (Wm^{-2})'); xlabel('LE_{s} meas (Wm^{-2})')
title( sprintf('y= %.2f x + %.2f,  R^2=%.2f', p(1), p(2),R2)); axis tight; axis square
text(-20,120,sprintf('ME= %.1f \nRMSE= %.1f \mumolm^{-2}s^{-1}',ME,RMSE))
ylim([-30 150]); xlim([-30 150])

disp('LEdry-canopy sub')
f=find(xdry>20);
%p=polyfit(xdry(f),ydry(f),1) 
p=robustfit(xdry(f),ydry(f))

% saveas(h,'Figs\Fig4_H2Ofluxes05.fig')
% print(h,'Figs\Fig4_H2Ofluxes05','-depsc')

%% Heat-fluxes
h=figure('Name', [figtext ' HeatFluxes'], 'NumberTitle','on','PaperOrientation','Landscape','PaperUnits','normalized',...
    'PaperPositionMode','manual','PaperPosition', [0.1 0.1 0.8 0.8]);
DataCol=[0.5 0.5 0.5];
ModCol=[0.8 0.8 0.8];

subplot(3,3, [1 2]);
plot(daynum, D.H(fi:li), '.','Color',DataCol); hold on
plot(daynum,oFlux.H(end,:), 'k-','LineWidth',0.5);  
xlim([fday lday+1]); ylim([-100 600])
ylabel('H_a (Wm^{-2})'); xlabel('doy');

subplot(3,3, [4 5]);
plot(daynum, Hs(fi:li), '.','Color',DataCol); hold on
plot(daynum,oFlux.H(f3m,:), 'k-','LineWidth',0.5);  hold on
xlim([fday lday+1]); ylim([-50 150])
ylabel('H_s (Wm^{-2})'); xlabel('doy');

% scatterplots
subplot(3,3,3);

x=D.H(fi:li); %measured
y= oFlux.H(end,:)';  %modeled
f=find(isnan(x)==0 & isnan(y)==0); 
fd=find(isnan(x)==0 & isnan(y)==0 & PrecIndex==0 & RH_ref<80); % dry conditions
xdry=x(fd);
ydry=y(fd);
x=x(f); % measured
y=y(f);  %modeled
clear f fd

xvec=[-100 600];
p=polyfit(x,y,1); 
%p=robustfit(x,y);
%p=[p(2) p(1)]
fit=polyval(p,xvec);
R2 = rsquare(x,y)
[ME,MAE,MSE,RMSE, N]=ModelErrorStatistics(x,y)

plot(x, y,'.','Color',ModCol,'MarkerSize',4); hold on;
plot(xdry, ydry,'.','Color',DataCol,'MarkerSize',4); hold on;
plot(xvec,fit,'k-', xvec,xvec,'k--');  
ylabel('H_{a} mod (Wm^{-2})'); xlabel('H_{a} meas (Wm^{-2})')
title( sprintf('y= %.2f x + %.2f,  R^2=%.2f', p(1), p(2),R2)); axis tight; axis square
ylim([-100 600]); xlim([-100 600]);
text(-60,500,sprintf('ME= %.1f \nRMSE= %.1f \mumolm^{-2}s^{-1}',ME,RMSE))

disp('H dry-canopy')
%p=polyfit(xdry,ydry,1) 
p=robustfit(xdry,ydry)

subplot(3,3,6);

x=D.Hs(fi:li); %measured
y= oFlux.H(f3m,:)';  %modeled
f=find(isnan(x)==0 & isnan(y)==0); 
fd=find(isnan(x)==0 & isnan(y)==0 & PrecIndex==0 & RH_ref<80); % dry conditions
xdry=x(fd);
ydry=y(fd);
x=x(f); % measured
y=y(f);  %modeled
clear f fd

xvec=[-50 150];
p=polyfit(x,y,1); 
%p=robustfit(x,y);
%p=[p(2) p(1)]
fit=polyval(p,xvec);
R2 = rsquare(x,y)
[ME,MAE,MSE,RMSE, N]=ModelErrorStatistics(x,y)

plot(x, y,'.','Color',ModCol,'MarkerSize',4); hold on;
plot(xdry, ydry,'.','Color',DataCol,'MarkerSize',4); hold on;
plot(xvec,fit,'k-', xvec,xvec,'k--');  
ylabel('H_{s} mod (Wm^{-2})'); xlabel('H_{s} meas (Wm^{-2})')
title( sprintf('y= %.2f x + %.2f,  R^2=%.2f', p(1), p(2),R2)); axis tight; axis square
ylim([-50 150]); xlim([-50 150]);
text(-40,120,sprintf('ME= %.1f \nRMSE= %.1f \mumolm^{-2}s^{-1}',ME,RMSE))


%Soil heat flux

f=find(daynum>120 & daynum<330);

Y=oSoil.Fheat((zs<-0.08 & zs>=-0.15),:);
mini=min(Y,[],1);
maxi=max(Y,[],1);
Yave=mean(Y);

mG=D.Gmeas(fi:li,:);
mG(mG>40 | mG<-20) = NaN;

avemG=nanmean(mG,2); %average
%fill mG for plotting range
for k=1:3,
    mGf=InterpFill(mG(:,k),'linear');
end
%RangeCol=[0.8 0.8 0.8];


subplot(3,3,[7 8]);
plot(daynum(f),mG(f,:),'.','Color',DataCol,'MarkerSize',6); hold on
plot(daynum(f),Yave(f),'k-', 'LineWidth',0.5); hold on
ylabel('G (Wm^{-2})'); xlabel('doy')
ylim([-20 40]); axis tight

% this plots ranges but is too messy here
% X1=daynum';
% X2=fliplr(X1);
% 
% % range of measured
% Y1=min(mGf,[],2);
% Y2=fliplr(max(mGf,[],2));
% 
% %range of modeled
% 
% Ym1=min(Y,[],1);
% Ym2=fliplr(max(Y,[],1));
% 
% h2=fill([X1 X2],[Y1' Y2'],RangeCol,'EdgeColor','none'); hold on;
% set(get(get(h2,'Annotation'),'LegendInformation'),...
%     'IconDisplayStyle','off'); % Exclude line h1 from legend
% h3=fill([X1 X2],[Ym1 Ym2],ModCol,'EdgeColor','none'); hold on;
% set(get(get(h3,'Annotation'),'LegendInformation'),...
%     'IconDisplayStyle','off'); % Exclude line h1 from legend
% plot(daynum(f),avemG(f),'r-', 'LineWidth',0.5); hold on
% plot(daynum(f),Yave(f),'k-', 'LineWidth',0.5); hold on
% ylabel('G (Wm^{-2})'); xlabel('doy')
% ylim([-20 40]); axis tight

subplot(3,3,9);

x=nanmean(mG,2); y= Yave'; xvec=[min(x)-10 max(x)+10];
f=find(isnan(x)==0);
p=polyfit(x(f),y(f),1); 
%p=robustfit(x(f),y(f));
%p=[p(2) p(1)]
fit=polyval(p,xvec);
R2 = rsquare(x(f),y(f))
[ME,MAE,MSE,RMSE, N]=ModelErrorStatistics(x(f),y(f))


plot(x(f), y(f),'.','Color',DataCol,'MarkerSize',4); hold on;
plot(xvec,fit,'k-', xvec,xvec,'k--'); 
ylabel('G mod (Wm^{-2})'); xlabel('G meas (Wm^{-2})')
title( sprintf('y= %.2f x + %.2f, R^2= %.2f', p(1), p(2),R2)); axis tight; axis square
ylim([-20 40]); xlim([-20 40]);
text(-18,30,sprintf('ME= %.1f \nRMSE= %.1f \mumolm^{-2}s^{-1}',ME,RMSE))

% saveas(h,'Figs\Fig5_Heatfluxes05.fig')
% print(h,'Figs\Fig5_Heatfluxes05.eps','-dpsc')


%% moss layer processes

h=figure('Name', [figtext ' Moss layer'], 'NumberTitle','on','PaperOrientation','Portrait','PaperUnits','normalized',...
    'PaperPositionMode','manual','PaperPosition', [0.1 0.1 0.8 0.8]);

ModCol1=[0.5 0.5 0.5];
ModCol2=[0.2 0.2 0.2];
%---------------- measured water contents ----------------

WCa=D.MossWaterContent.Auto;
WCm=D.MossWaterContent.Manual;

%Fcmoss=oBryo.Anbryo + oBryo.Rbryo;
%Emoss=oFloor.Evabryo;

subplot(4,1,1); 
plot(daynum,oBryo.T,'r-', daynum, oMeteo.Ta(2,:), 'k-', daynum,oSoil.T(1,:),'g-'); ylabel('^{\circ}C'); hold on
legend('T_{m}','T_{a}','T_{s,1}','Orientation','Horizontal'); xlabel('doy');axis tight; xlim([min(daynum) max(daynum)])

subplot(4,1,2); 
plot(daynum,oBryo.W./Moss_1.Wmax,'-','Color',ModCol2); hold on
plot(WCa.Doy,WCa.MWC./max(WCa.MWC),'rs', WCm.Doy, WCm.MWC(:,5)./max(WCm.MWC(:,5)),'ro','MarkerSize',4);
% hold on
% plot(WCm.Doy,b,'.')
ylabel('w_m^* (-)'); xlabel('doy');axis tight; ylim([-0.05 1.05]); xlim([min(daynum) max(daynum)])

subplot(4,1,3);
plot(daynum,oBryo.LE,'-','Color', ModCol1); hold on
plot(daynum,oBryo.H,'r-'); hold on 
ylabel('W m^{-2}');legend('LE_m','H_m','Orientation','Horizontal'); axis tight; xlim([min(daynum) max(daynum)])

subplot(4,1,4);
plot(daynum,oBryo.GPP' + oBryo.Respi,'-','Color',ModCol2); hold on
%plot(Fc_chMoss(:,1), -Fc_chMoss(:,2),'r-'); hold on % 0.5 and 0.4 corrections to time vector and to account for moss respi
ylabel('F_{c,m} (\mumol m^{-2} s^{-1})'); xlabel('doy');ylim([-1.5 2]); xlim([min(daynum) max(daynum)])

% saveas(h,'Figs\Fig6_moss05.fig')
% print(h,'Figs\Fig6_moss05.eps','-depsc')

figure(1111);

plot(daynum,oBryo.W./Moss_1.Wmax,'-','Color',ModCol2); hold on
plot(WCa.Doy,WCa.MWC./max(WCa.MWC),'rs', WCm.Doy, WCm.MWC(:,5)./max(WCm.MWC(:,5)),'ro', WCm.Doy, WCm.MWC(:,1)./max(WCm.MWC(:,1)),'bo', ...
WCm.Doy, WCm.MWC(:,2)./max(WCm.MWC(:,2)),'co',WCm.Doy, WCm.MWC(:,3)./max(WCm.MWC(:,3)),'go',WCm.Doy, WCm.MWC(:,4)./max(WCm.MWC(:,4)),'bs','MarkerSize',4);
ylabel('w_m^* (-)'); xlabel('doy');axis tight; ylim([-0.05 1.05]); xlim([min(daynum) max(daynum)])

%% Soil temperature & moisture

% --------- measured at each pit / depth --------------

Th=D.Pits.Th(fi:li,:);
Th(:,6)=nanmean(Th,2); % average
for k=1:6,
    Th(:,k)=InterpFill(Th(:,k),'linear'); close
end

Ta=D.Pits.Ta(fi:li,:);
Ta(:,6)=nanmean(Ta,2); % average

for k=1:6,
    Ta(:,k)=InterpFill(Ta(:,k),'linear'); close
end

Tb=D.Pits.Tb(fi:li,:);
Tb(:,6)=nanmean(Tb,2); % average

for k=1:6,
    Tb(:,k)=InterpFill(Tb(:,k),'linear'); close
end

Tc1=D.Pits.Tc1(fi:li,:);
Tc1(:,6)=nanmean(Tc1,2); % average

for k=1:6,
    Tc1(:,k)=InterpFill(Tc1(:,k),'linear'); close
end

% Soil moisture

% --------- measured at each pit / depth --------------

SWCh=1e-2*D.Pits.SWCh(fi:li,:);
SWCh(:,6)=nanmean(SWCh,2); % average
SWCh(:,7)=nanstd(SWCh(:,1:5),[],2); %std
SWCh=TimeAve(SWCh,6,1); % 3hour average to reduce noise
for k=1:7,
    SWCh(:,k)=InterpFill(SWCh(:,k),'linear'); close
end

SWCa=1e-2*D.Pits.SWCa(fi:li,:);
SWCa(:,6)=nanmean(SWCa,2); % average
SWCa(:,7)=nanstd(SWCa(:,1:5),[],2); %std
SWCa=TimeAve(SWCa,6,1); % 3hour average to reduce noise

for k=1:7,
    SWCa(:,k)=InterpFill(SWCa(:,k),'linear'); close
end

SWCb=1e-2*D.Pits.SWCb(fi:li,:);
SWCb(:,6)=nanmean(SWCb,2); % average
SWCb(:,7)=nanstd(SWCb(:,1:5),[],2); %std
SWCb=TimeAve(SWCb,6,1); % 3hour average to reduce noise

for k=1:7,
    SWCb(:,k)=InterpFill(SWCb(:,k),'linear'); close
end

SWCc1=1e-2*D.Pits.SWCc1(fi:li,:);
SWCc1(:,6)=nanmean(SWCc1,2); % average
SWCc1(:,7)=nanstd(SWCc1(:,1:5),[],2); %std
SWCc1=TimeAve(SWCc1,6,1); % 3hour average to reduce noise

for k=1:6,
    SWCc1(:,k)=InterpFill(SWCc1(:,k),'linear'); close
end

%% Plot Fig of Ts and Theta

RangeCol=[0.7 0.7 0.7];
ModCol=[0.5 0.5 0.5];

h=figure('Name', [figtext ' Soil T & \theta'],'NumberTitle','on','PaperOrientation','Landscape','PaperUnits','normalized',...
    'PaperPositionMode','manual','PaperPosition', [0.1 0.1 0.8 0.8]);
% 
% Thm=oSoil.T(zs<=-0.03 & zs>=-0.05,:); %humus temperature
% Tam=oSoil.T((zs<-0.05 & zs>=-0.11),:); %A horizon temperature
% Tbm=oSoil.T(zs<-0.12 & zs>=-0.26,:); %B horizon temperature
% Tcm=oSoil.T(zs<=-0.5,:); %C horizon temperature

Thm=oSoil.T(zs<=-0.02 & zs>=-0.05,:); %humus temperature
Tam=oSoil.T((zs<-0.05 & zs>=-0.10),:); %A horizon temperature
Tbm=oSoil.T(zs<-0.10 & zs>=-0.36,:); %B horizon temperature
Tcm=oSoil.T(zs<=-0.5,:); %C horizon temperature

X1=daynum';
X2=fliplr(X1);

subplot(4,2,1);
% range of modeled
Ym1=min(Thm,[],1);
Ym2=fliplr(max(Thm,[],1));

%range of measured
Y1=min(Th,[],2);
Y2=flipud(max(Th,[],2));

h2=fill([X1 X2],[Y1' Y2'],RangeCol,'EdgeColor','none'); hold on;
set(get(get(h2,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h1 from legend
h3=fill([X1 X2],[Ym1 Ym2],ModCol,'EdgeColor','none'); hold on;
set(get(get(h3,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h1 from legend
plot(daynum,Th(:,6),'-','Color','k'); hold on
plot(daynum,mean(Thm),'r-');
ylabel('T_{s,H} (^\circ C)'); xlabel('doy'); ylim([0 25]); xlim([min(daynum-1) max(daynum +1)]);

subplot(4,2,3);
% range of modeled
Ym1=min(Tam,[],1);
Ym2=fliplr(max(Tam,[],1));
%range of measured
Y1=min(Ta,[],2);
Y2=flipud(max(Ta,[],2));

h2=fill([X1 X2],[Y1' Y2'],RangeCol,'EdgeColor','none'); hold on;
set(get(get(h2,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h1 from legend
h3=fill([X1 X2],[Ym1 Ym2],ModCol,'EdgeColor','none'); hold on;
set(get(get(h3,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h1 from legend
plot(daynum,Ta(:,6),'-','Color','k'); hold on
plot(daynum,mean(Tam),'r-');
ylabel('T_{s,A} (^\circ C)'); xlabel('doy'); ylim([0 20]); xlim([min(daynum-1) max(daynum +1)]);

subplot(4,2,5);
% range of modeled
Ym1=min(Tbm,[],1);
Ym2=fliplr(max(Tbm,[],1));
%range of measured
Y1=min(Tb,[],2);
Y2=flipud(max(Tb,[],2));

h2=fill([X1 X2],[Y1' Y2'],RangeCol,'EdgeColor','none'); hold on;
set(get(get(h2,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h1 from legend
h3=fill([X1 X2],[Ym1 Ym2],ModCol,'EdgeColor','none'); hold on;
set(get(get(h3,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h1 from legend
plot(daynum,Tb(:,6),'-','Color','k'); hold on
plot(daynum,mean(Tbm),'r-');
ylabel('T_{s,B} (^\circ C)'); xlabel('doy');xlim([min(daynum-1) max(daynum +1)]);

subplot(4,2,7);
% range of modeled
Ym1=min(Tcm,[],1);
Ym2=fliplr(max(Tcm,[],1));
%range of measured
Y1=min(Tc1,[],2);
Y2=flipud(max(Tc1,[],2));

h2=fill([X1 X2],[Y1' Y2'],RangeCol,'EdgeColor','none'); hold on;
set(get(get(h2,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h1 from legend
h3=fill([X1 X2],[Ym1 Ym2],ModCol,'EdgeColor','none'); hold on;
set(get(get(h3,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h1 from legend
plot(daynum,Tc1(:,6),'-','Color','k'); hold on
plot(daynum,mean(Tcm),'r-');
ylabel('T_{s,c} (^\circ C)'); xlabel('doy'); xlim([min(daynum-1) max(daynum +1)]);

%legend('Range measured','Range model','mean meas','mean mod')
% saveas(h,'Figs\Fig6_Tsoil05.fig')
% print(h,'Figs\Fig6_Tsoil05.eps','-dpsc')


% -------- Soil moisture----------------------
RangeCol=[0.7 0.7 0.7];
MeasCol=[0.5 0.5 0.5];
% 
% h=figure('Name', [figtext ' Soil Theta'],'NumberTitle','on','PaperOrientation','Landscape','PaperUnits','normalized',...
%     'PaperPositionMode','manual','PaperPosition', [0.1 0.1 0.8 0.8]);

% Mh=oSoil.Wliq(zs<=-0.03 & zs>=-0.05,:); %humus temperature
% Ma=oSoil.Wliq((zs<-0.05 & zs>=-0.11),:)/(1-0.24); %A horizon temperature
% Mb=oSoil.Wliq(zs<-0.12 & zs>=-0.26,:)/(1-0.34); %B horizon temperature
% Mc=oSoil.Wliq(zs<=-0.5,:)/(1-0.4); %C horizon temperature

Mh=oSoil.Wliq(zs<=-0.02 & zs>=-0.05,:); %humus temperature
Ma=oSoil.Wliq((zs<-0.05 & zs>=-0.10),:)/(1-0.26); %A horizon temperature
Mb=oSoil.Wliq(zs<-0.10 & zs>=-0.36,:)/(1-0.3); %B horizon temperature
Mc=oSoil.Wliq(zs<=-0.5,:)/(1-0.4); %C horizon temperature

X1=daynum';
X2=fliplr(X1);

subplot(4,2,2);
%range of modeled
Ym1=min(Mh,[],1);
Ym2=fliplr(max(Mh,[],1));
%range of measured
Y1=min(SWCh(:,1:5),[],2);
Y2=flipud(max(SWCh(:,1:5),[],2));

h2=fill([X1 X2],[Y1' Y2'],RangeCol,'EdgeColor','none'); hold on;
set(get(get(h2,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h1 from legend
h3=fill([X1 X2],[Ym1 Ym2],MeasCol,'EdgeColor','none'); hold on;
set(get(get(h3,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h1 from legend

%plot(daynum,SWCh(:,6),'k-'); hold on
plot(daynum,D.SWC.H(fi:li),'k-'); hold on
plot(daynum,mean(Mh),'r-');
ylabel('\theta_H (^\circ C)'); xlabel('doy'); ylim([0 0.6]); xlim([min(daynum-1) max(daynum +1)]);

subplot(4,2,4);
%range of modeled
Ym1=min(Ma,[],1);
Ym2=fliplr(max(Ma,[],1));
%range of measured
Y1=min(SWCa(:,1:5),[],2);
Y2=flipud(max(SWCa(:,1:5),[],2));

h2=fill([X1 X2],[Y1' Y2'],RangeCol,'EdgeColor','none'); hold on;
set(get(get(h2,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h1 from legend
h3=fill([X1 X2],[Ym1 Ym2],MeasCol,'EdgeColor','none'); hold on;
set(get(get(h3,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h1 from legend

%plot(daynum,SWCa(:,6),'k-'); hold on
plot(daynum,D.SWC.A(fi:li),'k-'); hold on
plot(daynum,mean(Ma),'r-');

ylabel('\theta_A (m^3m^{-3})'); xlabel('doy'); ylim([0 0.6]); xlim([min(daynum-1) max(daynum +1)]);

subplot(4,2,6);
%range of modeled
Ym1=min(Mb,[],1);
Ym2=fliplr(max(Mb,[],1));
%range of measured
Y1=min(SWCb(:,1:5),[],2);
Y2=flipud(max(SWCb(:,1:5),[],2));

h2=fill([X1 X2],[Y1' Y2'],RangeCol,'EdgeColor','none'); hold on;
set(get(get(h2,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h1 from legend
h3=fill([X1 X2],[Ym1 Ym2],MeasCol,'EdgeColor','none'); hold on;
set(get(get(h3,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h1 from legend

plot(daynum,SWCb(:,6),'k-'); hold on
%plot(daynum,D.SWC.B(fi:li),'b-'); hold on
plot(daynum,mean(Mb),'r-');
ylabel('\theta_B (m^3m^{-3})'); xlabel('doy'); ylim([0 0.6]); xlim([min(daynum-1) max(daynum +1)]);


subplot(4,2,8);
%range of modeled
Ym1=min(Mc,[],1);
Ym2=fliplr(max(Mc,[],1));
%range of measured
Y1=min(SWCc1(:,1:5),[],2);
Y2=flipud(max(SWCc1(:,1:5),[],2));

h2=fill([X1 X2],[Y1' Y2'],RangeCol,'EdgeColor','none'); hold on;
set(get(get(h2,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h1 from legend
h3=fill([X1 X2],[Ym1 Ym2],MeasCol,'EdgeColor','none'); hold on;
set(get(get(h3,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h1 from legend

plot(daynum,SWCc1(:,6),'k-'); hold on
%plot(daynum,D.SWC.C(fi:li),'b-'); hold on
plot(daynum,mean(Mc),'r-');
ylabel('\theta_C(m^3m^{-3})'); xlabel('doy'); ylim([0 0.6]); xlim([min(daynum-1) max(daynum +1)]);

% saveas(h,'Figs\Fig7_SoilState05.fig')
% print(h,'Figs\Fig7_SoilState05.eps','-dpsc')

%% water storages in soil

h=figure('Name', [figtext ' Waterstorage'], 'NumberTitle','on');

%compute water storage from averages
Watcont=[D.SWC.H(fi:li) SWCa(:,6) SWCb(:,6) SWCc1(:,6)];
[SWA, dSWA] = SMEAR_II_soilwaterstorage(Watcont,SoilDepth);

Watcontlb=[SWCh(:,6)-SWCh(:,7) SWCa(:,6)-SWCa(:,7) SWCb(:,6)-SWCb(:,7)  SWCc1(:,6)-SWCc1(:,7)];
Watcontlb(Watcontlb<0)=0;
Watcontub=[SWCh(:,6)+SWCh(:,7) SWCa(:,6)+SWCa(:,7) SWCb(:,6)+SWCb(:,7)  SWCc1(:,6)+SWCc1(:,7)];
[SWAlb,~]=SMEAR_II_soilwaterstorage(Watcontlb,SoilDepth);
[SWAub,~]=SMEAR_II_soilwaterstorage(Watcontub,SoilDepth);

dz=Soil_1.zs;
dz(2:end)=-diff(zs); dz(1)=-2*Soil_1.zs(1);

for n=1:length(daynum)
    Wstor(n)=1000*sum(oSoil.Wliq(:,n).*dz);
end

% plot(daynum,SWA(:,5),'.','Color',RangeCol); hold on
% plot(daynum,SWAlb(:,5),'r-', daynum, SWAub(:,5),'r-'); hold on

X1=daynum';
X2=fliplr(X1);
%range of measured
Y1=SWAlb(:,5);
Y2=flipud(SWAub(:,5));

Y1=InterpFill(Y1,'linear');
Y2=InterpFill(Y2,'linear');

h2=fill([X1 X2],[Y1' Y2'],RangeCol,'EdgeColor','none'); hold on;
set(get(get(h2,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h1 from legend
hold on

plot(daynum,SWA(:,5),'-','Color','k','LineWidth',1); hold on%,daynum, SWAub(:,5),'b-',daynum,SWAlb(:,5),'g-',daynum,Wstor,'k-')
plot(daynum, Wstor,'r-','LineWidth',2); ylabel('Water storage (mm)'); xlabel('doy')

clear Y1 Y2 X1 X2 
% saveas(h,'Figs\Fig8_WaterStorage05.fig')
% print(h,'Figs\Fig8_WaterStorage05.eps','-dpsc')

%% ---------- Throughfall comparison ------------------------------
Trfall=dt*oMeteo.Trfall(f1m,:); %modeled trfall mm at 1m
Infiltr=oSoil.Infil; %infiltration, mm

mPrecAcc=cumsum(D.PrecAcc(fi:li)); % cumulative precipitation mm
mTrfall=cumsum(D.Trfallraw(fi:li,:)); % cumulative throughfall mm
cTrfall=cumsum(Trfall); 
mTrfall=mTrfall(:,[1 3 5:7]); % measured throughfall

Y1=mTrfall(:,3)'; %minimum
Y2=mTrfall(:,5)'; %maximum
Yave=nanmean(mTrfall,2);


RangeCol=[0.8 0.8 0.8];
h=figure('Name', [figtext ' Precip & Throughfall'], 'NumberTitle','on');
%plot range
h1=area(daynum,Y2,0,'Clipping','on','EdgeColor','none','FaceColor', RangeCol); hold on
h2=area(daynum,Y1,0,'Clipping','on','EdgeColor','none','FaceColor','w'); hold on
set(get(get(h1,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h1 from legend
set(get(get(h2,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','off'); % Exclude line h2 from legend
plot(daynum,mPrecAcc,'-','LineWidth',2,'Color',DataCol); hold on
plot(daynum, Yave,'k-','LineWidth',1.5); hold on
plot(daynum,cTrfall,'r-','LineWidth',1.5); hold on
%plot(daynum, cumsum(PotInf),'g-',daynum,cumsum(-Infiltr),'b-')
legend('P_0','TF meas','TF mod', 'Location','NorthWest')
ylabel('cumulateive P (mm)'); xlabel('doy');

% saveas(h,'Figs\Fig9_Throughfall05.fig')
% print(h,'Figs\Fig9_Throughfall05.eps','-depsc')
%% Water flux partitioning over simulation period

% all in mm
TotPrec=sum(PrecW*dt)
TotCanEvap=TotPrec-sum(oMeteo.Trfall(1,:)*dt) %evaporation of intercepted water

MossInterception=sum(oMeteo.Trfall(1,:)*dt - oFloor.Trfall_s*dt )
MossEvaporation = sum(oBryo.LE(oBryo.LE>=0)/L_molar*Mwater*dt)
MossCondensation = -sum(oBryo.LE(oBryo.LE<0)/L_molar*Mwater*dt)
%MossWaterStorageChange = oBryo.dW 
MossCapillaryRise=sum(oBryo.Fcapi*dt)

Infiltration = -sum(oSoil.Infil)
Transpiration=0;
for k=1:length(PTypes)
    Transpiration = Transpiration + sum(oPlant(k).Tr*1000*dt);
end

SoilEvaporation = sum(oSoil.Esoil)
SubSurfaceRunoff = sum(oSoil.Drain)
SurfaceRunoff=sum(oSoil.Roff)

StandET=TotCanEvap + Transpiration + MossEvaporation + SoilEvaporation

% plot bar-plots
H2Odown=[Infiltration; MossInterception; TotCanEvap];
H2Oup=[Transpiration; SoilEvaporation; MossEvaporation'; TotCanEvap];

dSWater=Infiltration - Transpiration - SoilEvaporation - MossCapillaryRise -SubSurfaceRunoff;
SSS=[dSWater; Infiltration; Transpiration; SoilEvaporation; MossCapillaryRise; SubSurfaceRunoff]';
%H2Osoil=[Transpiration; SoilEvaporation; MossCapillaryRise; SubSurfaceRunoff];

hh=figure('Name', [figtext 'H2O partitioning'], 'NumberTitle','on');
subplot(121); bar([H2Odown'; [NaN NaN NaN]],'stack'); xlim([0.55 1.45]); 
set(gca,'Xtick',[]); xlabel('Partitioning of precipitation'); ylabel('mm');

legend('Infiltr.','Moss Interc.','Canopy Interc.');
subplot(122); bar([H2Oup'; [NaN NaN NaN NaN]],'stack'); xlim([0.55 1.45]); 
legend('Transpi.','Soil Evap.','Moss Evap.','Evap.');
set(gca,'Xtick',[]); xlabel('Stand ET components'); ylabel('mm');
% subplot(133); 
% bar(1,SSS(1),'r'); hold on
% bar(2,SSS(2),'g'); hold on
% bar(3:6,SSS(3:6));
colormap gray
%subplot(122); bar([H2Oup'; [NaN NaN NaN NaN]],'stack'); xlim([0 1.5]);
% 
% saveas(hh,'Figs\Fig10_H2Opartitioning05.fig')
% print(hh,'Figs\Fig10_H2Opartitioning05.eps','-depsc')


%% comparison between modeled and measured cumulative values

Lambda=1e3.*(3147.5 - 2.37*(T_ref+273.15)); % latent heat of vaporization of water [J/kg]
ETm=D.LE(fi:li)./Lambda*1800;
VPD=(1-D.RH/100).*e_sat(D.Tair); %kPa
fLE=GapFill_ReichsteinFLX(D.LE,D.Glob,D.Tair,VPD);

fETm=fLE(fi:li)./Lambda*1800;
fETm(fETm<0)=0;
ETmod=oFlux.LE(end,:)./Lambda'*1800;
ETmod(ETmod<0)=0;
%%
dryc=find(PrecIndex==0 & RH_ref<80 & D.PAR(fi:li)>50);
wetc=find(PrecIndex~=0);

ratio=sum(fETm)/sum(ETmod)
aa=sum(fETm(dryc))
bb=sum(ETmod(dryc))
ratio_dry=aa/bb
aa=sum(fETm(wetc))
bb=sum(ETmod(wetc))
ratio_wet=aa/bb
%% canopy-air temperature differences

f=find(daynum>121 & daynum<244);

h=figure('Name', [figtext ' Tleaf - Tair'], 'NumberTitle','on');

dT_sl=oDLF(1).sl.Tleaf - oMeteo.T;
dT_sh=oDLF(1).sh.Tleaf - oMeteo.T;
dTave=oRadi.f_sl.*dT_sl + (1-oRadi.f_sl).*dT_sh;
a=PTypes(1).pad;
dTcan=length(length(daynum));
for k=1:length(daynum)
    dTcan(k)=nanmean(a.*dTave(:,k)./sum(a));
end

subplot(311); plot(daynum(f), dT_sl(:,f),'r.'); ylabel('T_l - T_a ^\circ C'); title('sunlit')
subplot(312); plot(daynum(f), dT_sh(:,f),'k.');ylabel('T_l - T_a ^\circ C'); title('shaded')
subplot(313); plot(daynum(f), dTave(:,f),'g.'); ylabel('T_l - T_a ^\circ C'); title('layer ave')
hold on

%saveas(h,'Leaf_Air_deltaT.fig')


%% Stand Water fluxes during rainy period

h=figure('Name', [figtext ' IntEvap'], 'NumberTitle','on','PaperOrientation','Landscape','PaperUnits','normalized',...
    'PaperPositionMode','manual','PaperPosition', [0.1 0.1 0.8 0.8]);
DataCol=[0.5 0.5 0.5];
ModCol=[0.2 0.2 0.2];

f=find(daynum>=200 & daynum<211);
% measured ET

%modeled 
%Interception=sum(oWLF.Interception(1:end,:))

subplot(211);
plot(daynum(f), ETm(f), '.','Color',DataCol); hold on
plot(daynum(f),oFlux.LE(end,f)./Lambda(f)'*1800, 'k-','LineWidth',0.5);  
%ylim([-20 300])
ylabel('ET (mm)'); xlabel('doy'); xlim([200 211]); ylim([-0.01 0.2]); 
ax1=gca;

ax2 = axes('Position',get(ax1,'Position'),...
           'XAxisLocation','top',...
           'YAxisLocation','right',...
           'Color','none',...
           'XColor','k','YColor','k','Ylim',[-0.01 0.2],'Xlim',[200 211],'XtickLabel',[]);

line(daynum(f), 0.2-(1e3*PrecW(f)/20),'Color','r','Parent',ax2,'LineWidth',1); hold on % plotting to same axis
ylabel(ax2,'Acc. precip.(mm)');
set(gca,'Ytick',[0:0.05:0.2],'Yticklabel',['8';'6';'4';'2';'0'])
xlim(ax2,[200 211])

subplot(212);
Esoil=oFlux.Esoil*dt*Mwater;
Emoss=oFloor.Ebryo*dt*Mwater;
Evapo=sum(oWLF.Evap(1:end,:));
ET=1000*oFlux.Tr*dt + Esoil + Emoss + Evapo;
plot(daynum(f),ET(f),'k-', daynum(f),1e3*oFlux.Tr(f)*dt,'g-',daynum(f),Evapo(f),'r-', daynum(f),Esoil(f)+Emoss(f),'b-' ); hold on
xlim([200 211]); ylim([-0.01 0.2]); xlabel('doy'); ylabel('mm')
legend('ET','T_r','E','E_{f}','Orientation','Horizontal','Location','BestOutside')

% saveas(h,'Figs\Fig11_ETrainy05.fig')
% print(h,'Figs\Fig11_ETrainy05.eps','-depsc')


% Hm=D.H(fi:li);
% Hmc=Hm+D.StorageFlux.H(fi:li); %measured storage-corrected flux
% plot(daynum(f), Hm(f), '.','Color',DataCol); hold on
% plot(daynum(f), Hmc(f), '.','Color','g'); hold on
% plot(daynum(f),oFlux.H(end,f), 'k-','LineWidth',0.5);  
% ylim([-100 300])
% ylabel('H_a (Wm^{-2})'); xlabel('doy');

%% Soil water potential profile

h=figure('Name', [figtext 'Soil & Root water potential'], 'NumberTitle','on');

plot(daynum, oSoil.h,'-'); hold on

plot(oPlant(1).Doy,oPlant(1).h_root,'gs'); hold on

plot(D.daynum, D.EQT./10,'o')
ylabel('h (m)'); xlabel('doy'); xlim([min(daynum) max(daynum)])



%% precipitation, throughfall and infiltration

h=figure('Name', [figtext ' Precip & Throughfall'], 'NumberTitle','on');

Trfall=dt*(oMeteo.Trfall(f1m,:)); %modeled trfall mm
PotInf=dt*(oFloor.Trfall_s); 
subplot(321); plot(daynum,D.PrecAcc(fi:li), 'b-');xlim([fday lday+1]); ylabel('mm'); title('Prec'); 
subplot(322); plot(daynum,cumsum(D.PrecAcc(fi:li)), 'rx', daynum, cumsum(D.Trfallraw(fi:li,:)),'-'); hold on;
plot( daynum, cumsum(Trfall), 'gx',daynum, cumsum(PotInf), 'cx'); title('cumulative P, Trfall and PotInf')

subplot(323); plot(daynum,D.PrecAcc(fi:li), 'b-', daynum,Trfall,'r-',daynum, -1e3*oSoil.Infiltr,'g-'); ylabel('mm'); hold on; 
title('Prec & Trfall & Infiltr');ylabel('mm');xlabel('doy'); xlim([fday lday+1]);
legend('Prec','Trfall','Infiltr')
subplot(324); plot(daynum,oSoil.SoilEvap,'k.-'); ylabel('mm'); title('Soil evap');xlabel('doy');  xlim([fday lday+1]);

subplot(325); plot(daynum,nansum(oStand.W), 'bo', daynum,1e3*oSoil.h_pond,'ko'); title('Total canopy water storage; surf. ponding'); ylabel('mm'); hold on; xlabel('doy');

IntEvap=sum(oWLF.Evap(1:end,:));
Interception=sum(oWLF.Inter(1:end,:));
Tf=nansum(D.PrecAcc(fi:li) - dt*(oMeteo(1,:))');
sum(IntEvap)
subplot(326); plot(daynum, cumsum(IntEvap),'r-', daynum, cumsum(Interception),'b-')
legend('IntEvap','Interception')

%saveas(h,'Precip.fig')

figure
plot(daynum, Tf,'r-',daynum, Interception,'b-',daynum,Tf,'g-',daynum,D.PrecAcc(fi:li),'k-')





%%
% 
% Qp=D.Rnet(fi:li); 
% figure()
% for k=1:length(daynum),
%     subplot(2,2,1); plot(Qp(k),'ro');
%     subplot(2,2,2); plot(oClim.U(:,k),z,'b-')
%     subplot(2,2,3); plot(L_molar*oDLF(1).E_sl(:,k),z,'r-',oDLF(1).H_sl(:,k),z,'r:', L_molar*oDLF(1).E_sh(:,k),z,'b-',oDLF(1).H_sh(:,k),z,'b:')
%     subplot(2,2,4);plot(dT_sl(:,k),z,'r-',dT_sh(:,k),z,'b-',dTave(:,k),z,'g-')
%     pause
% end
% %% Plots video of energy & CO2 exchange
% PlotEnergy=0;
% 
% pad_stand=PlantType_1.pad + PlantType_2.pad; % plant area density
% 
% if PlotEnergy==1,
%     
% Hrate1=(oDLF(1).H_sl.*oClim.f_sl + oDLF(1).H_sh.*(1-oClim.f_sl)).*oStand.df +oWLF.Hwet; % H Wm-2 (leaf)
% Hrate2=(oDLF(2).H_sl.*oClim.f_sl + oDLF(2).H_sh.*(1-oClim.f_sl)).*oStand.df; % H Wm-2 (leaf)
% f=find(isnan(Hrate2)==1); Hrate2(f)=0;
% Hrate=Hrate1 + Hrate2;
% 
% LErate1=L_molar*((oDLF(1).E_sl.*oClim.f_sl + oDLF(1).E_sh.*(1-oClim.f_sl)).*oStand.df +oWLF.Ewet); % LE Wm-2 (leaf)
% LErate2=L_molar*(oDLF(2).E_sl.*oClim.f_sl + oDLF(2).E_sh.*(1-oClim.f_sl)).*oStand.df; % LE Wm-2 (leaf)
% f=find(isnan(LErate2)==1); LErate2(f)=0;
% LErate=LErate1 + LErate2;
% 
% Fcrate1=-((oDLF(1).An_sl +oDLF(1).Rd_sl).*oClim.f_sl ...
% -(oDLF(1).An_sh +oDLF(1).Rd_sh).*(1-oClim.f_sl)).*oStand.df; % dry leaf CO2 flux mumolm-2(leaf)s-1
% 
% Fcrate2=-((oDLF(2).An_sl +oDLF(2).Rd_sl).*oClim.f_sl ...
% -(oDLF(2).An_sh +oDLF(2).Rd_sh).*(1-oClim.f_sl)).*oStand.df; % dry leaf CO2 flux mumolm-2(leaf)s-1
% f=find(isnan(Fcrate2)==1); Fcrate2(f)=0;
% Fcrate=Fcrate1 + Fcrate2;
% 
% PARave=oClim.Qb1 + oClim.Qd1;
% NIRave= oClim.Qb2 + oClim.Qd2; % SW rad at leafs
% SW=PARave+NIRave;
% 
% hh=figure(10);
% set(hh,'Units','normalized','PaperOrientation','landscape','Position',[0.05 0.05 0.90 0.90]);
% 
% clear F
% 
% 
% vidObj = VideoWriter('testivideo.avi');
% vidObj.FrameRate=2;
% vidObj.Quality=100;
% open(vidObj);
% 
% 
% findex=min(find(daynum>=154));
% lindex=max(find(daynum<=157));
% 
% zz=z((z/15)<1.2)/15; % height vector dimensionless
% 
% for k=findex
%     
%     
%     subplot(2,4,[1 2]); plot(daynum(k),SWtop(k),'ko','Markersize', 5); hold on; 
%     %title('Hyytiala SMEAR II 2.-4.6.2006: Energy Exchange', 'FontSize', 12','FontWeight', 'bold')
%     ylabel('Wm^{-2}','FontSize',12,'FontWeight', 'bold'); xlim([min(daynum) max(daynum)]); ylim([-100 900])
%     xlabel('DOY','FontSize',12,'FontWeight', 'bold' )
%     set(gca,'FontSize',12,'FontWeight', 'bold')
%     
%     subplot(2,4,[1 2]); plot(daynum(k), Hm(k,1),'ro',daynum(k), Em(k,1),'bo','Markersize', 5); hold on;
%     subplot(2,4,[1 2]); plot(daynum(k), oFlux.H(end,k),'r-', 'LineWidth',2); hold on;
%     subplot(2,4,[1 2]); plot(daynum(k), oFlux.LE(end,k),'b-', 'LineWidth',2); hold on;
%     LL=legend('Global rad.','Sensible heat','Latent heat');
%     set(LL,'Box','off','Fontweight','bold','FontSize',12)
%     
%     subplot(2,4,[3 4]); plot(daynum(k), Fcm(k,1),'ko', 'Markersize', 5); hold on;  xlim([min(daynum) max(daynum)]); ylim([-15 5])
%     %title('Hyytiala SMEAR II 2.-4.6.2006: CO_2 flux', 'FontSize', 12','FontWeight', 'bold')
%     ylabel('CO_2 flux \mumolm^{-2}s^{-1}','FontSize',12,'FontWeight', 'bold' )
%     xlabel('DOY','FontSize',12,'FontWeight', 'bold' )
%     set(gca,'FontSize',12,'FontWeight', 'bold')
%     
%     subplot(2,4,5); plot(SW(:,k),z/15,'k-'); ylim([0 1.1]); xlim([0 1000]);
%     title('Short-wave radiation', 'Fontsize', 12,'FontWeight','Bold');  ylabel('z/h','FontSize',12,'FontWeight', 'bold')
%     xlabel('SW (Wm^{-2})','FontSize',12,'FontWeight', 'bold')
%     
%     S=Create2Dsurface(pad_stand,Hrate(:,k),100); S=S(1:length(zz),:);
%     subplot(2,4,6); surface(1:101,zz,S,'EdgeColor','none'); ylim([0 1.1]); xlim([0 65]); set(gca,'Xtick', NaN); caxis([-50 175]);
%     colorbar('Location','East'); title('Heat source (Wm^{-2} leaf)','FontSize',12,'FontWeight', 'bold');ylabel('z/h','FontSize',12,'FontWeight', 'bold')
%     clear S
%     
%     S=Create2Dsurface(pad_stand,LErate(:,k),100); S=S(1:length(zz),:);
%     subplot(2,4,7); surface(1:101,zz,S,'EdgeColor','none'); ylim([0 1.1]); xlim([0 65]); set(gca,'Xtick', NaN); caxis([0 75]);
%     colorbar('Location','East'); title('Water source (Wm^{-2} leaf)','FontSize',12,'FontWeight', 'bold'); ylabel('z/h','FontSize',12,'FontWeight', 'bold')
%     
%     S=Create2Dsurface(pad_stand,Fcrate(:,k),100); S=S(1:length(zz),:);
%     subplot(2,4,8); surface(1:101,zz,S,'EdgeColor','none'); ylim([0 1.1]); xlim([0 65]); set(gca,'Xtick', NaN); caxis([-6 1]);
%     colorbar('Location','East'); title('CO_2 flux (\mumolm{-2}s^{-1}leaf)','FontSize',12,'FontWeight', 'bold');ylabel('z/h','FontSize',12,'FontWeight', 'bold')
%     
%     %F(k)=getframe(hh);
%     currFrame = getframe(hh);
%     writeVideo(vidObj,currFrame); clear currFrame
% end
% 
% for k=findex+1:lindex
%     
%     subplot(2,4,[1 2]); plot(daynum(k),SWtop(k),'ko','Markersize', 5); hold on; xlim([min(daynum) max(daynum)]); ylim([-100 900])
%     
%     subplot(2,4,[1 2]); plot(daynum(k-1:k), Hm(k-1:k,1),'ro',daynum(k), Em(k,1),'bo','Markersize', 5); hold on;
%     subplot(2,4,[1 2]); plot(daynum(k-1:k), oFlux.H(end,k-1:k),'r-', 'LineWidth',2); hold on;
%     subplot(2,4,[1 2]); plot(daynum(k-1:k), oFlux.LE(end,k-1:k),'b-', 'LineWidth',2); hold on;
%     
%     subplot(2,4,[3 4]); plot(daynum(k), Fcm(k,1),'ko','Markersize', 5); hold on;  xlim([min(daynum) max(daynum)]); ylim([-15 5])
%     subplot(2,4,[3 4]); plot(daynum(k-1:k), oFlux.Fc(end,k-1:k),'k-','Linewidth',2);hold on;
%     
%     subplot(2,4,5); plot(SW(:,k),z/15,'k-', 'LineWidth',2); ylim([0 1.1]); xlim([0 1000]);
%     title('Short-wave radiation', 'Fontsize', 12,'FontWeight','Bold');  ylabel('z/h','FontSize',12,'FontWeight', 'bold')
%     xlabel('SW (Wm^{-2})','FontSize',12,'FontWeight', 'bold')
%     
%     S=Create2Dsurface(pad_stand,Hrate(:,k),100); S=S(1:length(zz),:);
%     subplot(2,4,6); cla; surface(1:101,zz,S,'EdgeColor','none'); ylim([0 1.1]); xlim([0 65]); set(gca,'Xtick', NaN); caxis([-50 175]);
%     
%     clear S
%     
%     S=Create2Dsurface(pad_stand,LErate(:,k),100); S=S(1:length(zz),:);
%     subplot(2,4,7); cla; surface(1:101,zz,S,'EdgeColor','none'); ylim([0 1.1]); xlim([0 65]); set(gca,'Xtick', NaN)
%     clear S
%     
%     S=Create2Dsurface(pad_stand,Fcrate(:,k),100); S=S(1:length(zz),:);
%     subplot(2,4,8); cla; surface(1:101,zz,S,'EdgeColor','none'); ylim([0 1.1]); xlim([0 65]); set(gca,'Xtick', NaN);caxis([-6 1]);
%     clear S
%     
%     
%     %F(k)=getframe(hh);
%     currFrame = getframe(hh);
%     writeVideo(vidObj,currFrame); clear currFrame
% end
% % 
% 
% close(vidObj);
% 
% end
% 
% % %close
% %hh=figure(10);
% %set(h,'Units','normalized','PaperOrientation','landscape','Position',[0.1 0.1 0.8 0.8]);
% %movie(hh,F,1,3)
% % %%
% % 
% % hh=figure();
% % set(hh,'Units','normalized','PaperOrientation','landscape','Position',[0.1 0.1 0.8 0.8]);
% % 
% % subplot('Position',[0.07 0.55 0.4 0.4]);
% % subplot('Position',[0.55 0.55 0.4 0.4]);
% % subplot('Position',[0.07 0.05 0.4 0.4]);
% % subplot('Position',[0.55 0.05 0.4 0.4]);
% 
% %% Plots video of canopy wetness & precipitation partitioning
% findex=min(find(daynum>=154));
% lindex=max(find(daynum<=156));
% 
% PARave=oClim.Qb1 + oClim.Qd1;
% NIRave= oClim.Qb2 + oClim.Qd2; % SW rad at leafs
% SW=PARave+NIRave;
% zz=z((z/15)<1.2)/15;
% 
% % figure(10)
% % for k=findex:lindex-1
% %     
% %     plot(oStand.W(:,k), z, 'b:'); hold on
% %     plot(oStand.W(:,k+1), z, 'b-'); hold on
% %     pause
% % end
% 
% LErate1=L_molar*((oDLF(1).E_sl.*oClim.f_sl + oDLF(1).E_sh.*(1-oClim.f_sl)).*oStand.df);% +...
%  %   oWLF.Ewet.*pad_stand; % LE Wm-2 (leaf)
% LErate2=L_molar*(oDLF(2).E_sl.*oClim.f_sl + oDLF(2).E_sh.*(1-oClim.f_sl)).*oStand.df; % LE Wm-2 (leaf)
% f=find(isnan(LErate2)==1); LErate2(f)=0;
% LErate=LErate1 + LErate2;
% 
% 
% close all; 
% 
% hh=figure(20);
% set(hh,'Units','normalized','PaperOrientation','landscape','Position',[0.05 0.05 0.90 0.90]);
% 
%  vidObj = VideoWriter('Interception.avi');
%  vidObj.FrameRate=2;
%  vidObj.Quality=100;
%  open(vidObj);
% 
% for k=findex
%     
%     subplot(2,4,[1 2]); title('Prec & Trfall'); ylabel ('mm / 30min'); hold on
%     subplot(2,4,[3 4]); title('Evaporation'); ylabel ('mm / 30min'); hold on
%     subplot(2,4,5); plot(SW(:,k),z/15,'k-'); ylim([0 1.1]); xlim([0 1000]);
%     title('Short-wave radiation', 'Fontsize', 12,'FontWeight','Bold');  ylabel('z/h','FontSize',12,'FontWeight', 'bold')
%     xlabel('SW (Wm^{-2})','FontSize',12,'FontWeight', 'bold')
%     
%     
%     subplot(2,4,6); plot(oStand.W(:,k),z/15,'b-'); ylim([0 1.1]); xlim([0 60]); 
%     set(gca,'Xtick', NaN); %caxis([0 1]);
%     title('Water storage (-)','FontSize',12,'FontWeight', 'bold');ylabel('z/h','FontSize',12,'FontWeight', 'bold')
% 
%     
%     S=Create2Dsurface(pad_stand,LErate(:,k),100); S=S(1:length(zz),:);
%     subplot(2,4,7); surface(1:101,zz,S,'EdgeColor','none'); ylim([0 1.1]); xlim([0 65]); set(gca,'Xtick', NaN); %caxis([0 1000]);
%     colorbar('Location','East'); title('Water source (Wm^{-2} leaf)','FontSize',12,'FontWeight', 'bold'); ylabel('z/h','FontSize',12,'FontWeight', 'bold')
%     
%     subplot(2,4,8); plot(oClim.U(:,k),z/15,'k-'); ylim([0 1.1]); xlim([0 10]);
%     title('Wind speed', 'Fontsize', 12,'FontWeight','Bold');  ylabel('z/h','FontSize',12,'FontWeight', 'bold')
%     xlabel('U (ms^{-1})','FontSize',12,'FontWeight', 'bold')  
%     %F(k)=getframe(hh);
%     %currFrame = getframe(hh);
%    % writeVideo(vidObj,currFrame); clear currFrame
% end   
% for k=findex+1:lindex
%     
%     %precipitation & throughfall components
%     AA(1,:)=[PrecW(k-1) oWLF.Trfall_free(k-1)  oWLF.Trfall_crown(10,k-1)]*dt;
%     AA(2,:)=[PrecW(k) oWLF.Trfall_free(k)  oWLF.Trfall_crown(10,k)]*dt;
%     
%     subplot(2,4,[1 2]); bar(daynum(k-1:k),AA,'stacked'); hold on
%     subplot(2,4,[3 4]); plot(daynum(k),oFlux.E(end,k)*Mwater*dt, 'ko'); hold on;
%     
%     subplot(2,4,5); plot(SW(:,k),z/15,'k-'); ylim([0 1.1]); xlim([0 1000]);
%     
%     subplot(2,4,6); plot(oStand.W(:,k),z/15,'b-' ); ylim([0 1.1]); xlim([0 60]); 
%     set(gca,'Xtick', NaN); %caxis([0 1]);
%     title('Water storage (-)','FontSize',12,'FontWeight', 'bold');ylabel('z/h','FontSize',12,'FontWeight', 'bold')
%    
%     S=Create2Dsurface(pad_stand,LErate(:,k),100); S=S(1:length(zz),:);
%     subplot(2,4,7); surface(1:101,zz,S,'EdgeColor','none'); ylim([0 1.1]); xlim([0 65]); set(gca,'Xtick', NaN);%caxis([0 1000]);
%     clear S
%     
%     subplot(2,4,8); plot(oClim.U(:,k),z/15,'k-'); ylim([0 1.1]); xlim([0 5]);
%  
%     %F(k)=getframe(hh);
%     currFrame = getframe(hh);
%     writeVideo(vidObj,currFrame); clear currFrame
% end
%  


