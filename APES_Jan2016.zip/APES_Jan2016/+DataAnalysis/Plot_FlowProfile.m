% APES_Fig_ScalarProfiles.m: Compares measured and modeled CO2 and H2O concentration profiles

%% filter data 

%period
fdayn=182;
ldayn=242;

PrecIndex=TimeAve(PrecW,48,1); % 0 if no P during last 24h

j=find( (daynum>fdayn & daynum<ldayn) );% "select periods
dryc=find(PrecIndex==0 & RH_ref<90 & ustar>0.25); % dry conditions
k=intersect(j,dryc);
length(k)

%% select measured profiles

CO2m=D.Profile.CO2(fi:li,:);
H2Om=D.Profile.H2O(fi:li,:);
Tm=D.Profile.Ta(fi:li,:);

zm=D.Profile.heights;

%interpolate concentration at reference height
[r,c]=size(CO2m);
zp=[max(z) zm(2:end)];
for n=1:r
    CO2m(n,:)=interp1(zm,CO2m(n,:),zp,'linear');
    H2Om(n,:)=interp1(zm,H2Om(n,:),zp,'linear');
    Tm(n,:)=interp1(zm,Tm(n,:),zp,'linear');
end
clear n r c
zp=zp./Stand_1.hc; % normalized meas height
zn=z./Stand_1.hc; % normalized height
%% plot ensemble profiles and save as eps

fh=12; lh=16;    % time span of the profile
ff=find(time(:,4)>=fh & time(:,4)<=lh);% & Fwat(:,zabo)>0 & Fwat(:,zabo)< 400 & Fc(:,zabo)~=0);
f=intersect(ff,k);
clear ff

fh=0; lh=4;    % time span of the profile
ff=find(time(:,4)>=fh & time(:,4)<=lh);% & Fwat(:,zabo)>0 & Fwat(:,zabo)< 400 & Fc(:,zabo)~=0);
g=intersect(ff,k);

%leaf area density profile
N=length (z); % length of the grid in datapoints
LAD=Stand_1.lad; % Leaf-area profile, integrated gives unity

%---------Normalized scalar profiles-------------
%---modeled----
[r,c]=size(oClim.CO2);
nCO2=zeros(r,c).*NaN;
nH2O=nCO2;
nTa=nCO2;

for ff=1:c,
    nCO2(:,ff)=1e6*oClim.CO2(:,ff)./CO2_ref(ff);
    nH2O(:,ff)=oClim.H2O(:,ff)./H2O_ref(ff);
    nTa(:,ff)=oClim.Ta(:,ff)./T_ref(ff);
end
clear rc

%--- measured values
[r,c]=size(CO2m);
nCO2m=zeros(r,c).*NaN;
nH2Om=nCO2m;
nTam=nCO2m;

for ff=1:r,
    nCO2m(ff,:)=CO2m(ff,:)./CO2m(ff,1);
    nH2Om(ff,:)=H2Om(ff,:)./H2Om(ff,1);
    nTam(ff,:)=Tm(ff,:)./Tm(ff,1);
end
clear rc

%%
h=figure(6);
clf
set(gcf, 'PaperOrientation','Portrait','PaperUnits','normalized','PaperPosition', [0.1 0.5 0.8 0.4])

subplot(1,3,1); 
title(['SMEAR II ' num2str(year) '-days ' num2str(fdayn) '-' num2str(ldayn)]);
%daytime
plot(nanmean(nCO2(:,f),2),zn,'-','color','g','Linewidth',2); hold on;
xlabel('\it{CO_2/CO_{ref} (-)}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10)
HorizontalBars(nCO2m(f,:),zp+0.01,2,'g');ylim([0 zp(1)+0.05]); xlim([0.995 1.03]) % mean +/ s.e
hold on
%nighttime
plot(nanmean(nCO2(:,g),2),zn,'--','color','k','Linewidth',2); hold on;
xlabel('\it{CO_2/CO_{ref} (-)}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10)
HorizontalBars(nCO2m(g,:),zp,2,'k');ylim([0 zp(1)+0.05]); xlim([0.995 1.03]) % mean +/ s.e
hold on
%text(0.9955,1.45,'\it{b)}')

subplot(1,3,2); 
plot(nanmean(nH2O(:,f),2),zn,'-','color','b','Linewidth',2); hold on;
xlabel('\it{H_2O/H2O_{ref} (-)}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10)
HorizontalBars(nH2Om(f,:),zp,2,'b');ylim([0 zp(1)+0.05]); xlim([0.99 1.15]) % mean +/ s.e
hold on
%nighttime
plot(nanmean(nH2O(:,g),2),zn,'--','color','k','Linewidth',2); hold on;
xlabel('\it{H_2O/H2O_{ref} (-)}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10)
HorizontalBars(nH2Om(g,:),zp+0.01,2,'k');ylim([0 zp(1)+0.05]); xlim([0.99 1.15]) % mean +/ s.e
hold on

subplot(1,3,3); 
plot(nanmean(nTa(:,f),2),zn,'-','color','r','Linewidth',2); hold on;
xlabel('\it{T_a/T_{a,ref} (-)}','fontweight','bold','fontsize',10); 
ylabel('\it{z/h}','fontweight','bold','fontsize',10)
%plot ([378 381],[1 1],'k--','linewidth',2)
HorizontalBars(nTam(f,:),zp,2,'r'); ylim([0 zp(1)+0.05]); xlim([0.9 1.05]) % mean +/ s.e
hold on
%nighttime
plot(nanmean(nTa(:,g),2),zn,'--','color','k','Linewidth',2); hold on;
HorizontalBars(nTam(g,:),zp+0.01,2,'k');ylim([0 zp(1)+0.05]); xlim([0.9 1.05]) % mean +/ s.e
hold on

subplot(1,3,1); 
title(['SMEAR II ' num2str(year) ' days: ' num2str(fdayn) '-' num2str(ldayn)]);

saveas(h,'Figs\FigS1_ScalarProfiles05.fig')
print(h,'Figs\FigS1_ScalarProfiles05.eps','-depsc')