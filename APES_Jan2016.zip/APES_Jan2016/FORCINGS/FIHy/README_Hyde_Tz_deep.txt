Hyde_Tz_deep.dat

Contains modeled temperature profiles in bedrock layer below mineral soil.

Depths [0.1:0.3:6] m (12 layers)

Data structure:

Columns:

1 doy (1-366)
2 T at 0.1 m
3 T at 0.4 m
...
13 T at 5.6 m

*******************

Calculated by assuming thermal diffusivity equals that of granite, annual damping depth of temperature wave 6m and a homogenous soil layer.
T(z) in bedrock is solved by forcing homogenous heat equation by measured soil temperature from T-horizon (year 2005), looping over two years
and saving daily values at 2nd year. Lower boundary at 6m is assumed fixed temperature = 4.5 degC equaling annual mean air temperature.