% Plots Supplementary Figure to Ecological modeling: Climate time series
% during growing seasons of 2005 & 2006
clear all; close all; clc


load('Hy2005APES.mat')
load('Hy2006APES.mat')

D5=Hy05APES;
D6=Hy06APES;

%%2005

fi=find(D5.time(:,2)==5,1,'first');
li=find(D5.time(:,2)==9,1,'last');

daynum5=D5.daynum(fi:li);
dayn5=TimeAve(daynum5,48,2);
Rg5=D5.Glob(fi:li);
R5=TimeAve(Rg5,48,2);
Ta5=D5.Tair(fi:li);
T5=TimeAve(Ta5,48,2);
RH5=D5.RH(fi:li);
rh5=TimeAve(RH5,48,2);
Prec5=D5.PrecAcc(fi:li);
P5=SumOverTime(Prec5,48);
SWCa5=D5.SWC.A(fi:li);
SWCh5=D5.SWC.H(fi:li);
swca5=TimeAve(SWCa5,48,2);
swch5=TimeAve(SWCh5,48,2);


h=figure(99);
set(h, 'PaperOrientation','Portrait','PaperUnits','normalized','PaperPosition', [0.1 0.1 0.8 0.8])

subplot(5,2,1);
plot(daynum5,Rg5,'k-'); hold on
plot(dayn5,R5,'r-','linewidth',2)
ylabel('R_g (Wm^{-2})')
ylim([0 1000]); xlim([120 274]);
set(gca,'XTick',[121 152 182 213 244 273])
title('2005')

subplot(5,2,3);
plot(daynum5,Ta5,'k-'); hold on
plot(dayn5,T5,'r-','linewidth',2)
ylabel('T_a (^{\circ}C)');
ylim([-2 30]); xlim([120 274]);
set(gca,'XTick',[121 152 182 213 244 273])

subplot(5,2,5);
plot(daynum5,RH5,'k-'); hold on
plot(dayn5,rh5,'r-','linewidth',2)
ylabel('RH (%)');
ylim([0 100]); xlim([120 274]);
set(gca,'XTick',[121 152 182 213 244 273])

subplot(5,2,7);
bar(dayn5,P5,'k'); 
ylabel('Precip (mmd^{-1})');
xlim([120 274]);
set(gca,'XTick',[121 152 182 213 244 273])
a=nansum(P5);
text(125,20, sprintf('P_{tot} = %.1f mm',a))

subplot(5,2,9);
plot(dayn5,swch5,'r-',dayn5,swca5,'k-')
ylabel('\theta (m^3m^{-3})');
xlabel('doy')
legend('H','A','Location','SouthEast')
ylim([0.05 0.4]); xlim([120 274]);
set(gca,'XTick',[121 152 182 213 244 273])

% 2006

fi=find(D6.time(:,2)==5,1,'first');
li=find(D6.time(:,2)==9,1,'last');

daynum6=D6.daynum(fi:li);
dayn6=TimeAve(daynum6,48,2);
Rg6=D6.Glob(fi:li);
R6=TimeAve(Rg6,48,2);
Ta6=D6.Tair(fi:li);
T6=TimeAve(Ta6,48,2);
RH6=D6.RH(fi:li);
rh6=TimeAve(RH6,48,2);
Prec6=D6.PrecAcc(fi:li);
P6=SumOverTime(Prec6,48);
SWCa6=D6.SWC.A(fi:li);
SWCh6=D6.SWC.H(fi:li);
swca6=TimeAve(SWCa6,48,2);
swch6=TimeAve(SWCh6,48,2);

figure(99)

subplot(5,2,2);
plot(daynum6,Rg6,'k-'); hold on
plot(dayn6,R6,'r-','linewidth',2)
ylabel('R_g (Wm^{-2})')
ylim([0 1000]); xlim([120 274]);
set(gca,'XTick',[121 152 182 213 244 273])
title('2006')

subplot(5,2,4);
plot(daynum6,Ta6,'k-'); hold on
plot(dayn6,T6,'r-','linewidth',2)
ylabel('T_a (^{\circ}C)');
ylim([-2 30]); xlim([120 274]);
set(gca,'XTick',[121 152 182 213 244 273])

subplot(5,2,6);
plot(daynum6,RH6,'k-'); hold on
plot(dayn6,rh6,'r-','linewidth',2)
ylabel('RH (%)');
ylim([0 100]); xlim([120 274]);
set(gca,'XTick',[121 152 182 213 244 273])

subplot(5,2,8);
bar(dayn6,P6,'k'); 
a=nansum(P6);
text(125,20, sprintf('P_{tot} = %.1f mm',a))
ylabel('Precip (mmd^{-1})');
xlim([120 274]);
set(gca,'XTick',[121 152 182 213 244 273])

subplot(5,2,10);
plot(dayn6,swch6,'r-',dayn6,swca6,'k-')
ylabel('\theta (m^3m^{-3})');
xlabel('doy')
ylim([0.05 0.4]); xlim([120 274]);
set(gca,'XTick',[121 152 182 213 244 273])

%
saveas(h,'Figs\FigSx_Meteorology.fig')
print(h,'Figs\FigSx_Meteorology.eps','-depsc')